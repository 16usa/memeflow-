# MEMEFLOW Final Chart Data Fix

This patch updates only the isolated `market-chart-final.js`.

It:
- searches the full selected-candidate object recursively for image/logo/icon fields;
- supports common fields such as `image_uri`, `logoURI`, nested metadata and DOM background images;
- converts `ipfs://` images through an HTTP gateway fallback;
- never renders a negative price-axis minimum;
- compacts large histories into readable OHLC candles instead of tiny dots;
- keeps the original candle count in the footer.

## Apply

```bash
unzip -o MEMEFLOW_FINAL_CHART_DATA_FIX.zip
node scripts/install-final-chart-data-fix.mjs
```

Then **Stop → Run** and refresh Safari.

## Rollback

```bash
cp memeflow-app/market-chart-final.js.before-final-data-fix memeflow-app/market-chart-final.js
```
