#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PAYLOAD="$ROOT/payload/memeflow-app"
APP="$PWD/memeflow-app"
if [[ ! -d "$APP" ]]; then
  APP="$PWD"
fi
if [[ ! -f "$APP/character-real-test-v16.html" ]]; then
  echo "Could not find character-real-test-v16.html in: $APP"
  echo "Run this from ~/workspace or ~/workspace/memeflow-app"
  exit 1
fi
mkdir -p "$APP/game-assets/rocket-v34"
cp -R "$PAYLOAD/game-assets/rocket-v34/." "$APP/game-assets/rocket-v34/"
cp -f "$PAYLOAD/pepe-head-controller.js" "$APP/"
cp -f "$PAYLOAD/rocket-ride-v34.js" "$APP/"
cp -f "$PAYLOAD/character-real-test-v16.js" "$APP/"
cp -f "$PAYLOAD/character-real-test-v16.html" "$APP/"
echo 'V34.2 FULL HEAD INSTALLED OK'
