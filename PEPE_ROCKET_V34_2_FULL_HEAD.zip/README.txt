PEPE ROCKET V34.2 FULL HEAD MODE

1) Unzip this package inside ~/workspace.
2) Run: bash install-v34-2-full-head.sh
3) Open /character-real-test-v16.html

This package keeps the V34 rocket scene and swaps the round face cutout for full head PNG assets in the porthole.
