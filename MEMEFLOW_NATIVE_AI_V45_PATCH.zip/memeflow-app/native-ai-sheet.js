(() => {
  'use strict';
  if (window.__MEMEFLOW_NATIVE_AI_V45__) return;
  window.__MEMEFLOW_NATIVE_AI_V45__ = true;

  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const state = { auto: false, busy: false, lastCandidateId: null };

  function removeLegacyAi() {
    const exact = ['sheet-ai-direct-v24', 'ai-direct-v24', 'memeflow-ai-overlay', 'openai-assistant-modal'];
    exact.forEach(id => document.getElementById(id)?.remove());
    $$('[id*="ai-direct-v24"],[data-legacy-openai="true"],[data-mf-ai-runtime="legacy"]').forEach(el => el.remove());
  }

  function css() {
    if ($('#mf-native-ai-v45-style')) return;
    const style = document.createElement('style');
    style.id = 'mf-native-ai-v45-style';
    style.textContent = `
      #sheet-ai{background:#071018;color:var(--text,#f3f7fb);z-index:1001}
      #sheet-ai .mf-ai-shell{width:min(820px,100%);margin:0 auto;display:grid;gap:12px}
      #sheet-ai .mf-ai-hero{border:1px solid var(--line,#1c2a38);border-radius:18px;background:linear-gradient(145deg,rgba(97,223,255,.075),rgba(255,255,255,.018));padding:16px}
      #sheet-ai .mf-ai-kicker{font-size:9px;letter-spacing:.14em;color:var(--muted,#8e9daf);font-weight:850}
      #sheet-ai .mf-ai-title{font-size:24px;line-height:1.05;letter-spacing:-.04em;margin:6px 0 7px}
      #sheet-ai .mf-ai-copy{margin:0;color:var(--muted,#8e9daf);font-size:11px;line-height:1.55}
      #sheet-ai .mf-ai-status{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;margin-top:12px}
      #sheet-ai .mf-ai-stat{border:1px solid var(--line,#1c2a38);border-radius:12px;padding:10px;min-width:0;background:rgba(255,255,255,.018)}
      #sheet-ai .mf-ai-stat small{display:block;color:var(--muted,#8e9daf);font-size:8px;letter-spacing:.08em;text-transform:uppercase}
      #sheet-ai .mf-ai-stat b{display:block;margin-top:4px;font-size:11px;overflow-wrap:anywhere}
      #sheet-ai .mf-ai-actions{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
      #sheet-ai .mf-ai-btn{min-height:44px;border:1px solid var(--line2,#2a3b4b);border-radius:12px;background:rgba(255,255,255,.035);color:var(--text,#f3f7fb);font:inherit;font-size:11px;font-weight:780;cursor:pointer}
      #sheet-ai .mf-ai-btn.primary{background:#eef5f8;color:#071016;border-color:#eef5f8}
      #sheet-ai .mf-ai-btn.active{border-color:rgba(88,228,173,.45);color:var(--green,#58e4ad);background:rgba(88,228,173,.07)}
      #sheet-ai .mf-ai-btn:disabled{opacity:.48;cursor:not-allowed}
      #sheet-ai .mf-ai-card{border:1px solid var(--line,#1c2a38);border-radius:16px;background:rgba(255,255,255,.018);padding:14px}
      #sheet-ai .mf-ai-card h3{font-size:13px;margin:0 0 10px}
      #sheet-ai .mf-ai-input-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px}
      #sheet-ai .mf-ai-input{width:100%;min-height:46px;border:1px solid var(--line2,#2a3b4b);border-radius:12px;background:#0b131d;color:var(--text,#f3f7fb);padding:10px 12px;font:inherit;font-size:16px;outline:none}
      #sheet-ai .mf-ai-input:focus{border-color:rgba(97,223,255,.55);box-shadow:0 0 0 3px rgba(97,223,255,.08)}
      #sheet-ai .mf-ai-result{min-height:160px;white-space:pre-wrap;color:#c4ced9;font-size:12px;line-height:1.6;overflow-wrap:anywhere}
      #sheet-ai .mf-ai-result.empty{display:grid;place-items:center;text-align:center;color:var(--muted,#8e9daf);border:1px dashed var(--line,#1c2a38);border-radius:13px;padding:18px}
      #sheet-ai .mf-ai-meta{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;color:var(--muted,#8e9daf);font-size:9px;margin-bottom:9px}
      .mobile-nav [data-sheet="ai"]{position:relative;font-weight:900;color:var(--cyan,#61dfff)}
      .mobile-nav [data-sheet="ai"] .mf-ai-star{font-size:19px;line-height:1}
      .mobile-nav [data-sheet="ai"] .mf-ai-label{margin-left:3px}
      .mobile-nav [data-sheet="ai"].active{background:rgba(97,223,255,.10);color:#fff}
      @media(max-width:600px){.mobile-nav [data-sheet="ai"] .mf-ai-label{display:none}.mobile-nav [data-sheet="ai"] .mf-ai-star{font-size:23px}}
      @media(min-width:821px){
        #sheet-ai{position:fixed;inset:0;display:none;overflow:auto;padding:22px;z-index:1001;background:rgba(7,16,24,.985)}
        #sheet-ai.open{display:block}
        #sheet-ai .sheet-top{width:min(820px,100%);margin:0 auto 12px}
        .nav .mf-ai-desktop{color:var(--cyan,#61dfff)!important}
      }
      @media(max-width:620px){
        #sheet-ai .mf-ai-status{grid-template-columns:1fr 1fr}
        #sheet-ai .mf-ai-status .mf-ai-stat:last-child{grid-column:1/-1}
        #sheet-ai .mf-ai-actions{grid-template-columns:1fr 1fr}
        #sheet-ai .mf-ai-input-row{grid-template-columns:1fr}
        #sheet-ai .mf-ai-input-row .mf-ai-btn{width:100%}
      }
    `;
    document.head.appendChild(style);
  }

  function ensureSheet() {
    let sheet = $('#sheet-ai');
    if (sheet) return sheet;
    sheet = document.createElement('div');
    sheet.className = 'mobile-sheet';
    sheet.id = 'sheet-ai';
    sheet.setAttribute('role', 'dialog');
    sheet.setAttribute('aria-modal', 'true');
    sheet.setAttribute('aria-label', 'MEMEFLOW OpenAI');
    sheet.innerHTML = `
      <div class="sheet-top"><h2>MEMEFLOW OpenAI</h2><button class="close-sheet" type="button" aria-label="Close MEMEFLOW OpenAI">×</button></div>
      <div class="mf-ai-shell">
        <section class="mf-ai-hero">
          <div class="mf-ai-kicker">READ-ONLY AI ANALYSIS</div>
          <div class="mf-ai-title">MEMEFLOW OpenAI</div>
          <p class="mf-ai-copy">Analyze the selected candidate, explain the active strategy and ask questions without changing trading settings or bypassing execution gates.</p>
          <div class="mf-ai-status">
            <div class="mf-ai-stat"><small>OpenAI</small><b id="mfAiApiStatus">CHECKING</b></div>
            <div class="mf-ai-stat"><small>Selected token</small><b id="mfAiToken">NO CANDIDATE</b></div>
            <div class="mf-ai-stat"><small>Mode</small><b id="mfAiMode">MANUAL</b></div>
          </div>
        </section>
        <div class="mf-ai-actions">
          <button class="mf-ai-btn" id="mfAiStatusBtn" type="button">Status</button>
          <button class="mf-ai-btn primary" id="mfAiAnalyzeBtn" type="button">Analyze token</button>
          <button class="mf-ai-btn" id="mfAiAutoBtn" type="button" aria-pressed="false">AUTO AI</button>
          <button class="mf-ai-btn" id="mfAiStrategyBtn" type="button">Strategy</button>
        </div>
        <section class="mf-ai-card">
          <h3>Ask MEMEFLOW AI</h3>
          <div class="mf-ai-input-row">
            <input class="mf-ai-input" id="mfAiPrompt" type="text" autocomplete="off" placeholder="Ask about the selected token, risk, holders, market data or strategy…" />
            <button class="mf-ai-btn primary" id="mfAiAskBtn" type="button">Ask AI</button>
          </div>
        </section>
        <section class="mf-ai-card">
          <div class="mf-ai-meta"><b>AI Analysis &amp; Market Data</b><span id="mfAiResponseMeta">Ready</span></div>
          <div class="mf-ai-result empty" id="mfAiResult">Select a candidate, then tap Analyze token — or ask MEMEFLOW AI a question.</div>
        </section>
      </div>`;
    const anchor = $('#sheet-more') || $$('.mobile-sheet').at(-1);
    if (anchor?.parentNode) anchor.parentNode.insertBefore(sheet, anchor);
    else document.body.appendChild(sheet);
    return sheet;
  }

  function ensureNav() {
    const nav = $('.mobile-nav');
    if (!nav) return;
    const more = $('[data-sheet="more"]', nav);
    if (more) more.hidden = true;
    let ai = $('[data-sheet="ai"]', nav);
    if (!ai) {
      ai = document.createElement('button');
      ai.type = 'button';
      ai.dataset.sheet = 'ai';
      ai.setAttribute('aria-label', 'MEMEFLOW OpenAI');
      ai.innerHTML = '<span class="mf-ai-star">✦</span><span class="mf-ai-label">AI</span>';
      const positions = $('[data-sheet="positions"]', nav);
      nav.insertBefore(ai, positions || more || null);
    }
    nav.style.gridTemplateColumns = 'repeat(5,minmax(0,1fr))';
  }

  function ensureDesktopNav() {
    const navs = $$('.sidebar .nav');
    const nav = navs[0];
    if (!nav || $('.mf-ai-desktop', nav)) return;
    const link = document.createElement('a');
    link.href = '#sheet-ai';
    link.className = 'mf-ai-desktop';
    link.textContent = '✦ AI';
    const decision = [...nav.children].find(el => /Decision Studio/i.test(el.textContent || ''));
    if (decision?.nextSibling) nav.insertBefore(link, decision.nextSibling); else nav.appendChild(link);
    link.addEventListener('click', event => { event.preventDefault(); openSheet('ai'); });
  }

  function setBodyLocked(locked) {
    document.body.style.overflow = locked ? 'hidden' : '';
  }

  function openSheet(name) {
    $$('.mobile-sheet.open').forEach(el => el.classList.remove('open'));
    $$('.mobile-nav [data-sheet]').forEach(btn => btn.classList.toggle('active', btn.dataset.sheet === name));
    if (name === 'home') {
      setBodyLocked(false);
      return;
    }
    const sheet = $(`#sheet-${CSS.escape(name)}`);
    if (!sheet) return;
    sheet.classList.add('open');
    setBodyLocked(true);
    if (name === 'ai') {
      syncCandidate();
      refreshStatus();
      requestAnimationFrame(() => $('#mfAiPrompt')?.focus({ preventScroll: true }));
    }
  }

  function closeSheets() {
    $$('.mobile-sheet.open').forEach(el => el.classList.remove('open'));
    $$('.mobile-nav [data-sheet]').forEach(btn => btn.classList.toggle('active', btn.dataset.sheet === 'home'));
    setBodyLocked(false);
  }

  function candidate() {
    try { return window.MEMEFLOW_CORE?.getSelected?.() || null; } catch { return null; }
  }

  async function settings() {
    try {
      const r = await fetch('/api/settings', { credentials: 'include', headers: { accept: 'application/json' } });
      if (!r.ok) return null;
      const data = await r.json();
      return data.settings || null;
    } catch { return null; }
  }

  function syncCandidate() {
    const c = candidate();
    const token = $('#mfAiToken');
    if (token) token.textContent = c?.symbol || c?.name || (c?.mint ? `${c.mint.slice(0, 6)}…${c.mint.slice(-4)}` : 'NO CANDIDATE');
    return c;
  }

  function setBusy(busy, label = '') {
    state.busy = busy;
    ['mfAiAnalyzeBtn', 'mfAiAskBtn', 'mfAiStrategyBtn'].forEach(id => { const el = $('#' + id); if (el) el.disabled = busy; });
    const meta = $('#mfAiResponseMeta');
    if (meta) meta.textContent = label || (busy ? 'Thinking…' : 'Ready');
  }

  function showResult(text, meta = '') {
    const result = $('#mfAiResult');
    if (!result) return;
    result.classList.remove('empty');
    result.textContent = text;
    if (meta) $('#mfAiResponseMeta').textContent = meta;
  }

  function showError(message) {
    showResult(message || 'MEMEFLOW OpenAI request failed.', 'Action required');
  }

  async function refreshStatus() {
    const api = $('#mfAiApiStatus');
    if (api) api.textContent = 'CHECKING';
    try {
      const r = await fetch('/api/openai/status', { credentials: 'include', cache: 'no-store' });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.message || `HTTP ${r.status}`);
      if (api) api.textContent = data.configured ? `${data.model} · READY` : 'KEY NOT CONFIGURED';
      return data;
    } catch (error) {
      if (api) api.textContent = 'UNAVAILABLE';
      return { configured: false, error: error.message };
    }
  }

  async function buildContext() {
    const c = syncCandidate();
    return {
      candidate: c,
      settings: await settings(),
      product: { mode: document.body.dataset.productMode || 'execution', autoAi: state.auto, liveExecutionChanged: false },
    };
  }

  async function post(path, payload) {
    const r = await fetch(path, {
      method: 'POST', credentials: 'include',
      headers: { 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data.message || data.error || `HTTP ${r.status}`);
    return data;
  }

  async function analyzeToken(source = 'manual') {
    if (state.busy) return;
    const c = syncCandidate();
    if (!c?.id && !c?.mint) return showError('No candidate is selected. Open Candidates, choose a token, then return to MEMEFLOW OpenAI.');
    setBusy(true, source === 'auto' ? 'AUTO AI analyzing…' : 'Analyzing token…');
    try {
      const data = await post('/api/openai/analyze', { context: await buildContext() });
      showResult(data.text, `${data.model || 'OpenAI'} · token analysis`);
      state.lastCandidateId = c.id || c.mint;
    } catch (error) { showError(error.message); }
    finally { setBusy(false); }
  }

  async function askAi() {
    if (state.busy) return;
    const input = $('#mfAiPrompt');
    const prompt = input?.value?.trim() || '';
    if (!prompt) return;
    setBusy(true, 'Thinking…');
    try {
      const data = await post('/api/openai/ask', { prompt, context: await buildContext() });
      showResult(data.text, `${data.model || 'OpenAI'} · answer`);
    } catch (error) { showError(error.message); }
    finally { setBusy(false); }
  }

  async function explainStrategy() {
    if (state.busy) return;
    setBusy(true, 'Reading strategy…');
    try {
      const ctx = await buildContext();
      const data = await post('/api/openai/ask', {
        prompt: 'Explain the currently active MEMEFLOW strategy in plain language. Focus on entry gates, capital limits, exit protection and what AI is allowed or not allowed to change.',
        context: ctx,
      });
      showResult(data.text, `${data.model || 'OpenAI'} · strategy`);
    } catch (error) { showError(error.message); }
    finally { setBusy(false); }
  }

  function bind() {
    document.addEventListener('click', event => {
      const navButton = event.target.closest?.('.mobile-nav [data-sheet]');
      if (navButton) {
        const name = navButton.dataset.sheet;
        if (name === 'more' && navButton.hidden) return;
        event.preventDefault();
        openSheet(name);
        return;
      }
      const close = event.target.closest?.('.mobile-sheet .close-sheet');
      if (close) { event.preventDefault(); closeSheets(); }
    }, true);

    $('#mfAiStatusBtn')?.addEventListener('click', async () => {
      const s = await refreshStatus();
      showResult(s.configured ? `OpenAI is configured and ready. Model: ${s.model}. MEMEFLOW OpenAI is read-only and cannot execute trades or change trading settings.` : 'OPENAI_API_KEY is not configured on the MEMEFLOW server. Add it to Replit Secrets, then tap Status again.', 'OpenAI status');
    });
    $('#mfAiAnalyzeBtn')?.addEventListener('click', () => analyzeToken('manual'));
    $('#mfAiStrategyBtn')?.addEventListener('click', explainStrategy);
    $('#mfAiAskBtn')?.addEventListener('click', askAi);
    $('#mfAiPrompt')?.addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); askAi(); } });
    $('#mfAiAutoBtn')?.addEventListener('click', event => {
      state.auto = !state.auto;
      event.currentTarget.classList.toggle('active', state.auto);
      event.currentTarget.setAttribute('aria-pressed', String(state.auto));
      $('#mfAiMode').textContent = state.auto ? 'AUTO ANALYSIS' : 'MANUAL';
      if (state.auto) analyzeToken('auto');
    });
    window.addEventListener('memeflow:candidatechange', () => {
      const c = syncCandidate();
      const id = c?.id || c?.mint || null;
      if (state.auto && id && id !== state.lastCandidateId) analyzeToken('auto');
    });
    document.addEventListener('keydown', event => { if (event.key === 'Escape' && $('#sheet-ai')?.classList.contains('open')) closeSheets(); });
  }

  removeLegacyAi();
  css();
  ensureSheet();
  ensureNav();
  ensureDesktopNav();
  bind();
  syncCandidate();
  refreshStatus();
  window.MEMEFLOW_NATIVE_AI = { open: () => openSheet('ai'), close: closeSheets, analyze: () => analyzeToken('manual'), status: refreshStatus };
})();
