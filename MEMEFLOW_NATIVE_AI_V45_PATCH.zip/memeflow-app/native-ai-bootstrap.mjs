import http from 'node:http';
import fs from 'node:fs';
import { Readable } from 'node:stream';
import { syncBuiltinESMExports } from 'node:module';

const SCRIPT_TAG = '<script src="/native-ai-sheet.js" defer></script>';
const OPENAI_ENDPOINT = 'https://api.openai.com/v1/responses';
const OPENAI_MODEL = process.env.OPENAI_MODEL || 'gpt-5';

function json(res, status, payload) {
  if (res.headersSent) return false;
  res.statusCode = status;
  res.setHeader('content-type', 'application/json; charset=utf-8');
  res.setHeader('cache-control', 'no-store');
  res.end(JSON.stringify(payload));
  return true;
}

async function readJson(req, limit = 64 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw Object.assign(new Error('Request body too large'), { status: 413 });
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw Object.assign(new Error('Invalid JSON body'), { status: 400 });
  }
}

function hasSession(req) {
  return /(?:^|;\s*)mf_session=/.test(req.headers.cookie || '');
}

function compactContext(value) {
  const raw = JSON.stringify(value ?? {});
  return raw.length <= 18000 ? raw : raw.slice(0, 18000) + '…';
}

function outputText(data) {
  if (typeof data?.output_text === 'string' && data.output_text.trim()) return data.output_text.trim();
  const parts = [];
  for (const item of data?.output || []) {
    for (const part of item?.content || []) {
      if ((part?.type === 'output_text' || part?.type === 'text') && typeof part.text === 'string') parts.push(part.text);
    }
  }
  return parts.join('\n').trim();
}

async function callOpenAI({ prompt, context, mode }) {
  const key = process.env.OPENAI_API_KEY || '';
  if (!key) throw Object.assign(new Error('OPENAI_API_KEY is not configured on the server.'), { status: 503, code: 'OPENAI_NOT_CONFIGURED' });
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 30000);
  const instructions = [
    'You are MEMEFLOW OpenAI, a read-only analysis assistant inside a non-custodial Solana memecoin trading interface.',
    'Use only the supplied MEMEFLOW context. Never claim to have executed a trade, changed settings, bypassed a risk gate, or accessed secrets.',
    'Keep the answer compact and operational: decision, strongest evidence, blockers/risks, and next safe action.',
    mode === 'analyze' ? 'For token analysis, explicitly state BUY READY, WATCH, BLOCKED, or INSUFFICIENT DATA only when supported by the supplied context.' : '',
  ].filter(Boolean).join(' ');
  const input = `${prompt}\n\nMEMEFLOW CONTEXT:\n${compactContext(context)}`;
  try {
    const response = await fetch(OPENAI_ENDPOINT, {
      method: 'POST',
      headers: {
        authorization: `Bearer ${key}`,
        'content-type': 'application/json',
      },
      body: JSON.stringify({ model: OPENAI_MODEL, instructions, input }),
      signal: controller.signal,
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = data?.error?.message || `OpenAI request failed with HTTP ${response.status}`;
      throw Object.assign(new Error(message), { status: response.status, code: 'OPENAI_REQUEST_FAILED' });
    }
    const text = outputText(data);
    if (!text) throw Object.assign(new Error('OpenAI returned no text output.'), { status: 502, code: 'OPENAI_EMPTY_RESPONSE' });
    return { text, model: data?.model || OPENAI_MODEL, responseId: data?.id || null };
  } catch (error) {
    if (error?.name === 'AbortError') throw Object.assign(new Error('OpenAI request timed out.'), { status: 504, code: 'OPENAI_TIMEOUT' });
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function handleNativeAi(req, res) {
  const url = new URL(req.url || '/', 'http://memeflow.local');
  if (!url.pathname.startsWith('/api/openai/')) return false;
  if (url.pathname === '/api/openai/status' && req.method === 'GET') {
    return json(res, 200, {
      ok: true,
      configured: Boolean(process.env.OPENAI_API_KEY),
      model: OPENAI_MODEL,
      mode: 'read-only',
      autoTrading: false,
    });
  }
  if (!hasSession(req)) return json(res, 401, { error: 'AUTH_REQUIRED', message: 'Open MEMEFLOW first to establish the server session.' });
  if (req.method !== 'POST') return json(res, 405, { error: 'METHOD_NOT_ALLOWED' });
  if (url.pathname !== '/api/openai/analyze' && url.pathname !== '/api/openai/ask') return json(res, 404, { error: 'NOT_FOUND' });
  try {
    const body = await readJson(req);
    const context = body.context || {};
    const prompt = url.pathname.endsWith('/analyze')
      ? `Analyze the currently selected token ${context?.candidate?.symbol || context?.candidate?.name || context?.candidate?.mint || ''}. Explain whether its current MEMEFLOW decision is justified and what still blocks execution.`
      : String(body.prompt || '').trim();
    if (!prompt) return json(res, 400, { error: 'PROMPT_REQUIRED' });
    const answer = await callOpenAI({ prompt, context, mode: url.pathname.endsWith('/analyze') ? 'analyze' : 'ask' });
    return json(res, 200, { ok: true, ...answer });
  } catch (error) {
    return json(res, Number(error?.status) || 500, { error: error?.code || 'OPENAI_ERROR', message: error?.message || 'OpenAI request failed.' });
  }
}

const originalCreateReadStream = fs.createReadStream.bind(fs);
fs.createReadStream = function patchedCreateReadStream(file, options) {
  try {
    const name = String(file || '');
    if (/(^|[\\/])index\.html$/i.test(name)) {
      let html = fs.readFileSync(file, 'utf8');
      if (!html.includes('/native-ai-sheet.js')) {
        html = html.includes('</body>') ? html.replace('</body>', `${SCRIPT_TAG}</body>`) : `${html}\n${SCRIPT_TAG}\n`;
      }
      return Readable.from([html]);
    }
  } catch {
  }
  return originalCreateReadStream(file, options);
};

const originalCreateServer = http.createServer.bind(http);
http.createServer = function patchedCreateServer(...args) {
  const listenerIndex = args.findLastIndex?.(value => typeof value === 'function') ?? -1;
  if (listenerIndex < 0) return originalCreateServer(...args);
  const applicationListener = args[listenerIndex];
  args[listenerIndex] = async function nativeAiFirst(req, res) {
    try {
      const handled = await handleNativeAi(req, res);
      if (handled) return;
    } catch (error) {
      if (!res.headersSent) return json(res, 500, { error: 'NATIVE_AI_BOOTSTRAP_ERROR', message: error?.message || 'Native AI bootstrap failed.' });
      return;
    }
    return applicationListener(req, res);
  };
  return originalCreateServer(...args);
};

syncBuiltinESMExports();
