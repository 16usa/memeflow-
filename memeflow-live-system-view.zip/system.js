import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.185.1/build/three.module.js';
import { OrbitControls } from 'https://cdn.jsdelivr.net/npm/three@0.185.1/examples/jsm/controls/OrbitControls.js';

const $ = (id) => document.getElementById(id);
const clamp = (n,a,b) => Math.max(a,Math.min(b,n));
const finite = (v) => v !== null && v !== undefined && Number.isFinite(Number(v));
const fmt = (v,d=2) => finite(v) ? Number(v).toLocaleString(undefined,{maximumFractionDigits:d}) : '—';
const shortMint = (m='') => m ? `${m.slice(0,5)}…${m.slice(-4)}` : '—';
const ago = (ts) => {
  if(!finite(ts) || Number(ts)<=0) return '—';
  const ms=Math.max(0,Date.now()-Number(ts));
  if(ms<1000)return 'now'; if(ms<60000)return `${Math.floor(ms/1000)}s ago`; if(ms<3600000)return `${Math.floor(ms/60000)}m ago`; return `${Math.floor(ms/3600000)}h ago`;
};
const stateKey = (state='') => {
  const s=String(state).toUpperCase();
  if(s.includes('BUY'))return 'ready';
  if(s.includes('BLOCK'))return 'blocked';
  if(s.includes('WATCH'))return 'watch';
  return 'waiting';
};
const COLORS={neutral:0x6e8494,cyan:0x55d9ff,blue:0x5c8dff,green:0x4de6a1,yellow:0xefc66a,red:0xff6679,purple:0xa98bff,waiting:0x91a3af,watch:0x5c8dff,blocked:0xff6679,ready:0x4de6a1};

const app={
  scene:null,camera:null,renderer:null,controls:null,clock:new THREE.Clock(),
  nodes:new Map(),edges:[],particles:[],tokenMeshes:new Map(),pickables:[],labels:[],
  selected:null,telemetry:null,autoRotate:true,lastTokenSignature:'',
  pointer:new THREE.Vector2(),raycaster:new THREE.Raycaster(),
  cameraHome:new THREE.Vector3(0,9.2,22)
};

function makeMaterial(color,emissive=.18,opacity=1){
  return new THREE.MeshStandardMaterial({color,roughness:.48,metalness:.58,emissive:color,emissiveIntensity:emissive,transparent:opacity<1,opacity});
}
function addEdges(mesh,color=0x2f4655){
  const line=new THREE.LineSegments(new THREE.EdgesGeometry(mesh.geometry),new THREE.LineBasicMaterial({color,transparent:true,opacity:.58}));
  mesh.add(line);return line;
}
function moduleMesh({id,title,subtitle,pos,size=[3.2,1.1,2.0],color=COLORS.cyan,core=false}){
  const group=new THREE.Group();group.position.set(...pos);group.userData={kind:'module',id,title,subtitle};
  const body=new THREE.Mesh(new THREE.BoxGeometry(...size),makeMaterial(core?0x0c171d:0x0a1117,.03));addEdges(body,color);group.add(body);
  const accent=new THREE.Mesh(new THREE.BoxGeometry(size[0]*.78,.055,size[2]*.76),makeMaterial(color,.75));accent.position.y=size[1]/2+.035;group.add(accent);
  const glow=new THREE.PointLight(color,core?1.25:.45,core?8:4,2);glow.position.y=.7;group.add(glow);
  if(core){
    const ring1=new THREE.Mesh(new THREE.TorusGeometry(1.05,.055,12,80),makeMaterial(COLORS.green,1));ring1.rotation.x=Math.PI/2;ring1.position.y=.78;group.add(ring1);
    const ring2=new THREE.Mesh(new THREE.TorusGeometry(.72,.035,10,64),makeMaterial(COLORS.cyan,.9));ring2.rotation.set(Math.PI/2,.2,.2);ring2.position.y=.78;group.add(ring2);
  }
  const hit=new THREE.Mesh(new THREE.BoxGeometry(size[0]*1.05,size[1]*1.3,size[2]*1.05),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}));hit.userData=group.userData;group.add(hit);app.pickables.push(hit);
  app.scene.add(group);app.nodes.set(id,group);makeLabel(group,title,subtitle,core);return group;
}
function makeLabel(object,title,subtitle,core=false){
  const el=document.createElement('div');el.className=`node-label${core?' core':''}`;el.innerHTML=`<strong>${title}</strong><small>${subtitle}</small>`;$('labels').appendChild(el);app.labels.push({object,el});
}
function curveBetween(a,b,lift=1.2){
  const start=a.position.clone(),end=b.position.clone();
  const mid=start.clone().lerp(end,.5);mid.y+=lift;
  return new THREE.CatmullRomCurve3([start,start.clone().lerp(mid,.5),mid,end.clone().lerp(mid,.5),end]);
}
function connect(from,to,color=COLORS.cyan,speed=.11,count=2){
  const a=app.nodes.get(from),b=app.nodes.get(to);if(!a||!b)return;
  const curve=curveBetween(a,b,Math.abs(a.position.x-b.position.x)*.06+.7);
  const tube=new THREE.Mesh(new THREE.TubeGeometry(curve,48,.025,6,false),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.26}));app.scene.add(tube);
  app.edges.push({curve,tube,color});
  for(let i=0;i<count;i++){
    const p=new THREE.Mesh(new THREE.SphereGeometry(.06,10,10),new THREE.MeshBasicMaterial({color}));p.userData={curve,t:(i/count),speed};app.scene.add(p);app.particles.push(p);
  }
}
function buildScene(){
  const canvas=$('systemCanvas');
  app.scene=new THREE.Scene();app.scene.fog=new THREE.FogExp2(0x020507,.026);
  app.camera=new THREE.PerspectiveCamera(43,canvas.clientWidth/canvas.clientHeight,.1,100);app.camera.position.copy(app.cameraHome);
  app.renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'high-performance'});app.renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,1.8));app.renderer.setSize(canvas.clientWidth,canvas.clientHeight,false);app.renderer.outputColorSpace=THREE.SRGBColorSpace;app.renderer.toneMapping=THREE.ACESFilmicToneMapping;app.renderer.toneMappingExposure=1.05;
  app.controls=new OrbitControls(app.camera,canvas);app.controls.enableDamping=true;app.controls.dampingFactor=.055;app.controls.minDistance=10;app.controls.maxDistance=34;app.controls.maxPolarAngle=Math.PI*.49;app.controls.minPolarAngle=Math.PI*.20;app.controls.target.set(0,.3,0);app.controls.autoRotate=true;app.controls.autoRotateSpeed=.32;
  app.scene.add(new THREE.HemisphereLight(0x7bbad6,0x040609,.95));const key=new THREE.DirectionalLight(0xd4efff,1.2);key.position.set(8,14,10);app.scene.add(key);
  const grid=new THREE.GridHelper(52,52,0x173140,0x0a171e);grid.position.y=-1.45;grid.material.transparent=true;grid.material.opacity=.28;app.scene.add(grid);
  const floor=new THREE.Mesh(new THREE.PlaneGeometry(60,42),new THREE.MeshStandardMaterial({color:0x03070a,roughness:.82,metalness:.25,transparent:true,opacity:.72}));floor.rotation.x=-Math.PI/2;floor.position.y=-1.47;app.scene.add(floor);
  const starGeo=new THREE.BufferGeometry();const stars=[];for(let i=0;i<460;i++)stars.push((Math.random()-.5)*45,Math.random()*18-1,(Math.random()-.5)*36);starGeo.setAttribute('position',new THREE.Float32BufferAttribute(stars,3));const starMat=new THREE.PointsMaterial({color:0x477184,size:.025,transparent:true,opacity:.42});app.scene.add(new THREE.Points(starGeo,starMat));

  moduleMesh({id:'discovery',title:'DISCOVERY',subtitle:'Pump create · Solana WS',pos:[-9,2.8,-1.6],color:COLORS.cyan});
  moduleMesh({id:'bootstrap',title:'FAST BOOTSTRAP',subtitle:'price · holder · initial eval',pos:[-5,5.0,-2.6],color:COLORS.blue});
  moduleMesh({id:'core',title:'MEMEFLOW CORE',subtitle:'real-time event orchestration',pos:[0,.6,0],size:[4.2,1.45,2.7],color:COLORS.green,core:true});
  moduleMesh({id:'holders',title:'HOLDER LEDGER',subtitle:'user-only live balances',pos:[-5,-3.2,1.1],color:COLORS.cyan});
  moduleMesh({id:'market',title:'MARKET LEDGER',subtitle:'price · liquidity · pressure',pos:[0,-4.1,-1.8],color:COLORS.blue});
  moduleMesh({id:'risk',title:'RISK ENGINE',subtitle:'user-specific deterministic gates',pos:[6,4.5,-2.2],color:COLORS.green});
  moduleMesh({id:'decision',title:'DECISION',subtitle:'WAIT · WATCH · BLOCK · READY',pos:[8,.7,.4],color:COLORS.purple});
  moduleMesh({id:'paper',title:'PAPER ENGINE',subtitle:'observe · assist · automate',pos:[5,-3.4,2],color:COLORS.purple});
  moduleMesh({id:'openai',title:'OPENAI ASSISTANT',subtitle:'advisory · read-only context',pos:[9,4.9,3.2],color:COLORS.purple});
  moduleMesh({id:'execution',title:'LIVE EXECUTION',subtitle:'adapter not verified',pos:[9,-3.4,-3.4],color:COLORS.yellow});

  connect('discovery','bootstrap',COLORS.cyan,.10,2);connect('bootstrap','core',COLORS.blue,.12,3);connect('core','holders',COLORS.cyan,.095,2);connect('core','market',COLORS.blue,.105,2);connect('holders','risk',COLORS.cyan,.09,2);connect('market','risk',COLORS.blue,.1,2);connect('risk','decision',COLORS.green,.12,3);connect('decision','paper',COLORS.purple,.09,2);connect('decision','execution',COLORS.yellow,.075,1);connect('risk','openai',COLORS.purple,.07,1);

  canvas.addEventListener('pointerup',pick);window.addEventListener('resize',resize);animate();
}
function resize(){const c=$('systemCanvas');if(!app.renderer)return;const w=c.clientWidth,h=c.clientHeight;app.camera.aspect=w/h;app.camera.updateProjectionMatrix();app.renderer.setSize(w,h,false)}
function animate(){requestAnimationFrame(animate);const dt=Math.min(app.clock.getDelta(),.05),t=performance.now()*.001;app.controls.update();
  for(const p of app.particles){p.userData.t=(p.userData.t+dt*p.userData.speed)%1;p.position.copy(p.userData.curve.getPointAt(p.userData.t));const pulse=.75+Math.sin((p.userData.t*8+t*2)*Math.PI)*.2;p.scale.setScalar(pulse)}
  const core=app.nodes.get('core');if(core){core.children.forEach((c,i)=>{if(c.geometry?.type==='TorusGeometry')c.rotation.z+=dt*(i%2?-.25:.2)})}
  for(const [mint,row] of app.tokenMeshes){row.mesh.position.y=row.baseY+Math.sin(t*1.5+row.phase)*.08;row.mesh.rotation.y+=dt*.35}
  updateLabels();app.renderer.render(app.scene,app.camera);
}
function updateLabels(){const w=$('systemCanvas').clientWidth,h=$('systemCanvas').clientHeight;for(const l of app.labels){const v=new THREE.Vector3();l.object.getWorldPosition(v);v.project(app.camera);const visible=v.z<1&&v.z>-1;const x=(v.x*.5+.5)*w,y=(-v.y*.5+.5)*h;l.el.style.opacity=visible?'1':'0';l.el.style.transform=`translate(-50%,-50%) translate(${x}px,${y-34}px)`}}
function pick(ev){if(!app.renderer)return;const rect=$('systemCanvas').getBoundingClientRect();app.pointer.x=((ev.clientX-rect.left)/rect.width)*2-1;app.pointer.y=-((ev.clientY-rect.top)/rect.height)*2+1;app.raycaster.setFromCamera(app.pointer,app.camera);const hits=app.raycaster.intersectObjects(app.pickables,false);if(!hits.length)return;select(hits[0].object.userData)}
function focusObject(obj){if(!obj||!app.controls)return;const pos=new THREE.Vector3();obj.getWorldPosition(pos);const direction=new THREE.Vector3().subVectors(app.camera.position,app.controls.target).normalize();app.controls.target.copy(pos);app.camera.position.copy(pos).add(direction.multiplyScalar(11));app.controls.update()}

function select(data){app.selected=data;document.querySelectorAll('.token-card').forEach(x=>x.classList.toggle('active',data.kind==='token'&&x.dataset.mint===data.mint));if(data.kind==='token')renderTokenInspector(data.row);else renderModuleInspector(data.id);}
function metric(label,value){return `<div class="metric-card"><span>${label}</span><strong>${value}</strong></div>`}
function renderModuleInspector(id){const titles={discovery:['Discovery','Pump create events enter through Solana WebSocket.'],bootstrap:['Fast Bootstrap','Price lifecycle, holder admission and initial evaluation are started before slow enrichment.'],core:['MEMEFLOW Core','Coordinates discovery, enrichment, evaluation, publication and engine updates.'],holders:['Holder Ledger','Tracks user-only Pump trade balances and produces fresh holder concentration snapshots.'],market:['Market Ledger','Updates price, liquidity and buy pressure from live trade events and curve snapshots.'],risk:['Risk Engine','Independent quality score plus user-specific deterministic gates.'],decision:['Decision','Current deterministic state: WAITING, WATCH, BLOCKED or BUY READY.'],paper:['Paper Engine','Receives BUY READY decisions and applies paper execution safety gates.'],openai:['OpenAI Assistant','Optional advisory layer. Deterministic risk engine remains authoritative.'],execution:['Live Execution','Production signing / live execution adapter is not verified in this build.']};const x=titles[id]||titles.core;$('inspectorTitle').textContent=x[0];$('inspectorSummary').textContent=x[1];$('inspectorState').textContent=id==='execution'?'NOT VERIFIED':'SYSTEM';$('inspectorState').className=`state-pill ${id==='execution'?'waiting':'neutral'}`;
  const d=app.telemetry?.diag||{},disc=app.telemetry?.discovery||{};const maps={discovery:[['Events',disc.eventsReceived],['Connected',disc.connected?'Yes':'No'],['Queue',disc.queueDepth],['Last event',ago(disc.lastEventAt)]],bootstrap:[['Starts',d.fastPhase?.starts],['Holder queued',d.fastPhase?.holderQueued],['Eval started',d.fastPhase?.initialEvaluationStarted],['Errors',d.fastPhase?.bootstrapErrors]],holders:[['Queue',disc.holderQueueDepth],['Processing',disc.holderProcessing],['Snapshots',d.liveTradeFeed?.holderSnapshots],['Ledger mints',d.eventHolderLedger?.trackedMints]],market:[['Snapshots',d.liveTradeFeed?.marketSnapshots],['Trade events',d.liveTradeFeed?.tradeEventsDecoded],['WS direct',d.liveTradeFeed?.connected?'Live':'Offline'],['HTTP hot path',d.liveTradeFeed?.httpRpcCalls??0]],risk:[['Active users',disc.activeEvaluationUsers],['Evaluations',disc.liveEvaluationsPerformed],['Tokens',disc.liveEvaluationTokensProcessed],['Batch errors',disc.liveEvaluationBatchErrors]],decision:[['Tokens',d.counts?.returned],['Fresh backlog',d.bridge?.currentFreshBacklog],['SLA misses',d.bridge?.slaMissesCurrent],['Eval calls',d.liveTradeFeed?.evaluationCalls]],paper:[['Environment','Paper'],['Source','BUY READY'],['Safety','Enabled'],['Live funds','No']],openai:[['Configured',app.telemetry?.openai?.configured?'Yes':'No'],['Mode',app.telemetry?.openai?.mode||'read-only'],['Model',app.telemetry?.openai?.model||'—'],['Authority','Advisory']],execution:[['Adapter','Not verified'],['Signing','Unavailable'],['Paper engine','Available'],['Risk authority','Enabled']],core:[['Tokens',d.counts?.tokensInThisInstance],['Pump tokens',d.counts?.pumpTokensInThisInstance],['Fresh backlog',d.bridge?.currentFreshBacklog],['PID',d.instance?.pid]]};
  $('metricGrid').innerHTML=(maps[id]||maps.core).map(([a,b])=>metric(a,b??'—')).join('');$('primaryReason').textContent=x[1];$('gateList').innerHTML='';$('inspectorMint').textContent='Architecture module';
}
function renderTokenInspector(row){const d=row.decision||{},h=row.holder||{},m=row.market||{};const state=d.state||'WAITING',key=stateKey(state);$('inspectorTitle').textContent=shortMint(row.mint);$('inspectorSummary').textContent=`Pump token · ${row.schedulerLane||'pipeline'} · age ${fmt(row.ageMinutes,1)} min`;$('inspectorState').textContent=state;$('inspectorState').className=`state-pill ${key}`;$('metricGrid').innerHTML=[['AI score',d.score??'—'],['Holders',h.count??'—'],['Top 10',finite(h.top10Pct)?`${fmt(h.top10Pct,2)}%`:'—'],['Developer',finite(h.developerPct)?`${fmt(h.developerPct,2)}%`:'—'],['Buy pressure',finite(m.buyPressure)?`${fmt(m.buyPressure,2)}×`:'—'],['Price SOL',finite(m.priceSol)?fmt(m.priceSol,9):'—']].map(([a,b])=>metric(a,b)).join('');$('primaryReason').textContent=d.primaryReason||(Array.isArray(d.reasons)&&d.reasons[0])||'Waiting for deterministic evaluation.';
  const gates=row.gates||null;let list=[];if(gates){list=Object.entries(gates).map(([name,g])=>({name,status:g?.pass===true?'PASS':g?.pass===false?'FAIL':'WAIT'}))}else if(Array.isArray(d.reasons)&&d.reasons.length){list=d.reasons.slice(0,4).map((r,i)=>({name:r,status:i===0&&key==='blocked'?'FAIL':'INFO'}))}
  $('gateList').innerHTML=list.map(g=>`<div class="gate ${g.status==='PASS'?'pass':g.status==='FAIL'?'fail':'wait'}"><span>${escapeHtml(g.name)}</span><b>${g.status}</b></div>`).join('');$('inspectorMint').textContent=row.mint||'—';
}
function escapeHtml(s){return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}

function syncTokenMeshes(sample=[]){const keep=new Set();sample.slice(0,12).forEach((row,i)=>{if(!row?.mint)return;keep.add(row.mint);const key=stateKey(row.decision?.state);const color=COLORS[key];let item=app.tokenMeshes.get(row.mint);if(!item){const mesh=new THREE.Mesh(new THREE.IcosahedronGeometry(.19,2),makeMaterial(color,.85));const halo=new THREE.Mesh(new THREE.TorusGeometry(.29,.018,8,36),new THREE.MeshBasicMaterial({color,transparent:true,opacity:.55}));halo.rotation.x=Math.PI/2;mesh.add(halo);mesh.userData={kind:'token',mint:row.mint,row};app.scene.add(mesh);app.pickables.push(mesh);item={mesh,phase:Math.random()*Math.PI*2,baseY:1.55};app.tokenMeshes.set(row.mint,item)}item.mesh.userData.row=row;item.mesh.material.color.setHex(color);item.mesh.material.emissive.setHex(color);const state=destinationFor(row);const dest=app.nodes.get(state)?.position||new THREE.Vector3();const angle=(i/(Math.max(sample.length,1)))*Math.PI*2;item.mesh.position.set(dest.x+Math.cos(angle)*(1.3+(i%3)*.18),item.baseY,dest.z+Math.sin(angle)*(1.3+(i%2)*.24));item.baseY=dest.y+.7+(i%3)*.18});
  for(const [mint,item] of app.tokenMeshes){if(!keep.has(mint)){app.scene.remove(item.mesh);app.pickables=app.pickables.filter(x=>x!==item.mesh);app.tokenMeshes.delete(mint)}}
}
function destinationFor(row){const key=stateKey(row.decision?.state);if(key==='ready'||key==='watch'||key==='blocked')return 'decision';if(row.holder?.fresh||row.market?.priceSol!=null)return 'risk';return row.pipelineStarted?'bootstrap':'discovery'}

function renderRail(sample=[]){$('tokenRail').innerHTML=sample.length?sample.map(row=>{const key=stateKey(row.decision?.state),state=row.decision?.state||'WAITING';return `<button class="token-card" type="button" data-mint="${escapeHtml(row.mint)}"><div class="token-card-top"><span class="token-symbol">${escapeHtml(shortMint(row.mint))}</span><span class="token-state ${key}">${escapeHtml(state)}</span></div><div class="token-card-meta"><span>Holders<b>${row.holder?.count??'—'}</b></span><span>Buy pressure<b>${finite(row.market?.buyPressure)?fmt(row.market.buyPressure,2)+'×':'—'}</b></span><span>Top 10<b>${finite(row.holder?.top10Pct)?fmt(row.holder.top10Pct,1)+'%':'—'}</b></span><span>Age<b>${fmt(row.ageMinutes,1)}m</b></span></div></button>`}).join(''):'<div class="token-card"><div class="token-symbol">No token telemetry yet</div><div class="token-card-meta"><span>Pipeline<b>waiting</b></span></div></div>';
  document.querySelectorAll('.token-card[data-mint]').forEach(btn=>btn.addEventListener('click',()=>{const row=app.telemetry?.diag?.sample?.find(x=>x.mint===btn.dataset.mint);if(row)select({kind:'token',mint:row.mint,row})}))
}
function setStatus(dot,status,text,kind){dot.className=`dot ${kind}`;status.textContent=text}
async function getJson(url){const r=await fetch(url,{cache:'no-store',credentials:'same-origin'});if(!r.ok)throw new Error(`${url} HTTP ${r.status}`);return r.json()}
async function refreshTelemetry(){const results=await Promise.allSettled([getJson('/api/debug/filter-pipeline-lifecycle?limit=12'),getJson('/api/discovery/status'),getJson('/api/market/status'),getJson('/api/openai/status')]);const [diagR,discR,marketR,aiR]=results;const diag=diagR.status==='fulfilled'?diagR.value:null,discovery=discR.status==='fulfilled'?discR.value:null,market=marketR.status==='fulfilled'?marketR.value:null,openai=aiR.status==='fulfilled'?aiR.value:null;app.telemetry={diag,discovery,market,openai};
  if(discovery?.connected)setStatus($('wsDot'),$('wsStatus'),'Live','ok');else if(discovery)setStatus($('wsDot'),$('wsStatus'),'Connecting','warning');else setStatus($('wsDot'),$('wsStatus'),'Unavailable','bad');
  const rpcOK=market?.rpc==='online'||market?.solana?.ok===true||discovery?.rpcLastHttpStatus===200;if(rpcOK)setStatus($('rpcDot'),$('rpcStatus'),'Online','ok');else if(market)setStatus($('rpcDot'),$('rpcStatus'),market.rpc||'Degraded','warning');else setStatus($('rpcDot'),$('rpcStatus'),'Unavailable','bad');
  if(openai?.configured)setStatus($('aiDot'),$('aiStatus'),'Configured','ok');else if(openai)setStatus($('aiDot'),$('aiStatus'),'Optional','warning');else setStatus($('aiDot'),$('aiStatus'),'Unavailable','bad');
  $('eventCount').textContent=discovery?.eventsReceived??'—';$('tradeCount').textContent=diag?.liveTradeFeed?.tradeEventsDecoded??discovery?.liveTradeFeed?.tradeEventsDecoded??'—';$('holderQueue').textContent=discovery?.holderQueueDepth??'—';$('activeUsers').textContent=discovery?.activeEvaluationUsers??'—';$('freshBacklog').textContent=diag?.bridge?.currentFreshBacklog??'—';$('lastEvent').textContent=ago(discovery?.lastEventAt);$('lastSync').textContent=`updated ${new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
  const sample=diag?.sample||[];syncTokenMeshes(sample);renderRail(sample);$('telemetryMode').classList.toggle('offline',!diag&&!discovery);$('telemetryMode').lastChild.textContent=(diag||discovery)?'LIVE':'DEGRADED';
  if(app.selected?.kind==='token'){const latest=sample.find(x=>x.mint===app.selected.mint);if(latest){app.selected.row=latest;renderTokenInspector(latest)}}else renderModuleInspector(app.selected?.id||'core');
}

$('autoRotateBtn').addEventListener('click',()=>{app.autoRotate=!app.autoRotate;app.controls.autoRotate=app.autoRotate;$('autoRotateBtn').classList.toggle('active',app.autoRotate)});
$('resetViewBtn').addEventListener('click',()=>{app.camera.position.copy(app.cameraHome);app.controls.target.set(0,.3,0);app.controls.update()});
$('focusBtn').addEventListener('click',()=>{if(app.selected?.kind==='token'){const x=app.tokenMeshes.get(app.selected.mint);if(x)focusObject(x.mesh)}else focusObject(app.nodes.get(app.selected?.id||'core'))});

try{buildScene();app.selected={kind:'module',id:'core'};renderModuleInspector('core');refreshTelemetry().finally(()=>setTimeout(()=>$('boot').classList.add('hidden'),420));setInterval(refreshTelemetry,2500)}catch(err){console.error('[MEMEFLOW SYSTEM VIEW]',err);$('fatal').hidden=false;$('boot').classList.add('hidden')}
