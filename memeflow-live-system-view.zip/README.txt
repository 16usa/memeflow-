MEMEFLOW Live System View

Files:
- system.html
- system.css
- system.js

Install:
1. Copy these 3 files into memeflow-app/
2. Restart the app if needed.
3. Open /system.html

The page reads existing MEMEFLOW endpoints:
- /api/debug/filter-pipeline-lifecycle?limit=12
- /api/discovery/status
- /api/market/status
- /api/openai/status

No trading logic is changed.
Live execution is deliberately displayed as NOT VERIFIED because the current production signing/execution adapter is not ready.

Three.js is loaded as an ES module from jsDelivr.
