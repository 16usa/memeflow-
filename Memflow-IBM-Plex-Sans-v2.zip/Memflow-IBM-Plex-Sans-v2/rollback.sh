#!/usr/bin/env bash
set -Eeuo pipefail

STATE_DIR=".memeflow-backups"
LATEST_FILE="$STATE_DIR/ibm-plex-sans-v1-LATEST"
FORCE=0

if [ "${1:-}" = "--force" ]; then
  FORCE=1
elif [ -n "${1:-}" ]; then
  echo "Usage: $0 [--force]"
  exit 1
fi

if [ ! -f "$LATEST_FILE" ]; then
  echo "ERROR: no IBM Plex Sans rollback state found."
  echo "The patch may not have been installed yet."
  exit 1
fi

BACKUP="$(cat "$LATEST_FILE")"
MANIFEST="$BACKUP/manifest.json"

if [ ! -f "$MANIFEST" ]; then
  echo "ERROR: rollback manifest missing: $MANIFEST"
  exit 1
fi

export BACKUP_DIR="$BACKUP"
export FORCE_ROLLBACK="$FORCE"

python3 - <<'PY'
from pathlib import Path
import hashlib, json, os, shutil, sys

backup = Path(os.environ["BACKUP_DIR"])
force = os.environ.get("FORCE_ROLLBACK") == "1"
manifest = json.loads((backup / "manifest.json").read_text(encoding="utf-8"))

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

conflicts = []

for entry in manifest["files"]:
    if not entry.get("changed"):
        continue
    path = Path(entry["path"])
    expected = entry.get("after_sha256")
    if not path.exists():
        conflicts.append(f"{path}: missing after install")
        continue
    current = sha256(path)
    if expected and current != expected:
        conflicts.append(f"{path}: changed after IBM Plex Sans install")

css_info = manifest["css"]
css_path = Path(css_info["path"])
if css_path.exists():
    expected = css_info.get("after_sha256")
    if expected and sha256(css_path) != expected:
        conflicts.append(f"{css_path}: changed after IBM Plex Sans install")

if conflicts and not force:
    print("ROLLBACK STOPPED SAFELY.")
    print("These files changed after the font patch:")
    for c in conflicts:
        print("  -", c)
    print()
    print("Nothing was restored.")
    print("Review the changes first, or run rollback with --force if you intentionally want the backup restored.")
    sys.exit(2)

for entry in manifest["files"]:
    if not entry.get("changed"):
        continue
    path = Path(entry["path"])
    src = backup / path
    if not src.exists():
        raise SystemExit(f"ERROR: backup file missing: {src}")
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, path)
    print("RESTORED", path)

if css_info.get("existed_before"):
    src = backup / css_path
    if not src.exists():
        raise SystemExit(f"ERROR: prior CSS backup missing: {src}")
    css_path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, css_path)
    print("RESTORED", css_path)
else:
    if css_path.exists():
        css_path.unlink()
        print("REMOVED ", css_path)

print()
print("IBM Plex Sans rollback complete.")
print("Text colors/sizes/layout remain exactly as they were before this font patch.")
PY

rm -f "$LATEST_FILE"

echo
echo "=========================================="
echo "ROLLBACK COMPLETE"
echo "=========================================="
echo "Restart     : NOT performed"
echo "Git commit  : NOT performed"
echo "Git push    : NOT performed"
echo "=========================================="
