#!/usr/bin/env bash
set -Eeuo pipefail

APP="memeflow-app"
CSS_NAME="memeflow-ibm-plex-sans-v1.css"
CSS="$APP/$CSS_NAME"
STATE_DIR=".memeflow-backups"
LATEST_FILE="$STATE_DIR/ibm-plex-sans-v1-LATEST"

if [ ! -d "$APP" ]; then
  echo "ERROR: $APP not found."
  echo "Run this from the existing Memflow Replit workspace."
  exit 1
fi

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
[ -f "$SCRIPT_DIR/$CSS_NAME" ] || {
  echo "ERROR: patch CSS missing: $SCRIPT_DIR/$CSS_NAME"
  exit 1
}

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$STATE_DIR/ibm-plex-sans-v1-$STAMP"
mkdir -p "$BACKUP/$APP"
mkdir -p "$STATE_DIR"

export BACKUP_DIR="$BACKUP"
export APP_DIR="$APP"
export CSS_NAME

python3 - "$SCRIPT_DIR/$CSS_NAME" <<'PY'
from pathlib import Path
import re, sys

p = Path(sys.argv[1])
s = p.read_text(encoding="utf-8")

no_comments = re.sub(r"/\*.*?\*/", "", s, flags=re.S)

for forbidden in (
    "font-size:", "font-weight:", "line-height:", "letter-spacing:",
    "text-transform:", "margin:", "padding:"
):
    if forbidden in no_comments:
        raise SystemExit(f"ERROR: forbidden typography/layout property: {forbidden}")

if re.search(r"(?m)^\s*color\s*:", no_comments):
    raise SystemExit("ERROR: patch unexpectedly owns text color")

if '"IBM Plex Sans"' not in s or "font-family:" not in s:
    raise SystemExit("ERROR: IBM Plex Sans family rule missing")

print("CSS audit OK: font-family only.")
PY

python3 - <<'PY'
from pathlib import Path
import hashlib, json, os, re, shutil

app = Path(os.environ["APP_DIR"])
css_name = os.environ["CSS_NAME"]
css_path = app / css_name
backup = Path(os.environ["BACKUP_DIR"])

pages = sorted(app.glob("*.html"))
if not pages:
    raise SystemExit("ERROR: no HTML pages found in memeflow-app")

manifest = {
    "patch": "Memflow IBM Plex Sans v1",
    "app": str(app),
    "css_name": css_name,
    "files": [],
}

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

# Backup pre-existing CSS if present.
css_existed = css_path.exists()
if css_existed:
    dst = backup / css_path
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(css_path, dst)

manifest["css"] = {
    "path": str(css_path),
    "existed_before": css_existed,
    "before_sha256": sha256(css_path) if css_existed else None,
}

changed = []
already = []

for page in pages:
    html = page.read_text(encoding="utf-8", errors="ignore")

    entry = {
        "path": str(page),
        "changed": False,
        "before_sha256": sha256(page),
    }

    if css_name in html:
        already.append(page.name)
        entry["after_sha256"] = entry["before_sha256"]
        manifest["files"].append(entry)
        continue

    if not re.search(r"</head>", html, flags=re.I):
        print(f"SKIP {page.name}: no </head>")
        entry["after_sha256"] = entry["before_sha256"]
        manifest["files"].append(entry)
        continue

    dst = backup / page
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(page, dst)

    link = f'<link rel="stylesheet" href="{css_name}">'
    html = re.sub(r"</head>", link + "\n</head>", html, count=1, flags=re.I)
    page.write_text(html, encoding="utf-8")

    entry["changed"] = True
    entry["after_sha256"] = sha256(page)
    manifest["files"].append(entry)
    changed.append(page.name)

(backup / "manifest.json").write_text(
    json.dumps(manifest, indent=2),
    encoding="utf-8",
)

print(f"Prepared backup: {backup}")
print(f"HTML pages to link: {len(changed)}")
for name in changed:
    print("  +", name)
for name in already:
    print("  =", name, "(already linked)")
PY

cp "$SCRIPT_DIR/$CSS_NAME" "$CSS"

python3 - <<'PY'
from pathlib import Path
import hashlib, json, os

backup = Path(os.environ["BACKUP_DIR"])
manifest_path = backup / "manifest.json"
manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
css = Path(manifest["css"]["path"])

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

manifest["css"]["after_sha256"] = sha256(css)
manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
PY

printf '%s\n' "$BACKUP" > "$LATEST_FILE"

echo
echo "=========================================="
echo "MEMFLOW IBM PLEX SANS INSTALLED"
echo "=========================================="
echo "Font family : IBM Plex Sans"
echo "Colors      : untouched"
echo "Font sizes  : untouched"
echo "Weights     : untouched"
echo "Line height : untouched"
echo "Layout      : untouched"
echo "JS/backend  : untouched"
echo "Restart     : NOT performed"
echo "Rollback    : available"
echo "Backup      : $BACKUP"
echo "=========================================="
