MEMFLOW — IBM Plex Sans typography patch v2
============================================

PURPOSE
-------
Change only the Memflow font family to IBM Plex Sans.
Keep the current Memflow text colors exactly as they are.

UNCHANGED
---------
- text colors
- font sizes
- font weights
- line heights
- spacing/layout
- semantic trading/status colors
- JS/backend
- server/process state

INSTALL
-------
unzip -o Memflow-IBM-Plex-Sans-v2.zip -d /tmp/mf-ibm-plex-v2
bash /tmp/mf-ibm-plex-v2/Memflow-IBM-Plex-Sans-v2/install.sh

ROLLBACK
--------
If you do not like IBM Plex Sans:

bash /tmp/mf-ibm-plex-v2/Memflow-IBM-Plex-Sans-v2/rollback.sh

The installer records its latest backup under:
.memeflow-backups/ibm-plex-sans-v1-LATEST

SAFE ROLLBACK
-------------
rollback.sh verifies that patched files were not changed after installation.
If they were changed, it stops instead of overwriting newer work.

To intentionally restore the backup anyway:
bash /tmp/mf-ibm-plex-v2/Memflow-IBM-Plex-Sans-v2/rollback.sh --force

NO RESTART
----------
Neither install.sh nor rollback.sh starts, stops, restarts, reloads,
or kills the application/server.

GIT
---
Install and rollback do not commit or push automatically.
