#!/usr/bin/env bash
set -Eeuo pipefail

APP="memeflow-app"
CSS_NAME="memeflow-ibm-plex-sans-v1.css"
CSS="$APP/$CSS_NAME"

if [ ! -d "$APP" ]; then
  echo "ERROR: $APP not found."
  echo "Run this from the existing Memflow Replit workspace."
  exit 1
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP=".memeflow-backups/ibm-plex-sans-v1-$STAMP"
mkdir -p "$BACKUP/$APP"

# Copy the CSS shipped with this patch into Memflow.
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cp "$SCRIPT_DIR/$CSS_NAME" "$CSS"

# This patch intentionally changes only font-family.
python3 - "$CSS" <<'PY'
from pathlib import Path
import re, sys

p = Path(sys.argv[1])
s = p.read_text(encoding="utf-8")

for forbidden in (
    "font-size:", "font-weight:", "line-height:", "letter-spacing:",
    "text-transform:", "margin:", "padding:"
):
    if forbidden in s:
        raise SystemExit(f"ERROR: forbidden typography/layout property in patch: {forbidden}")

# Ignore comments and make sure no text color is owned by this layer.
no_comments = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
if re.search(r"(?m)^\s*color\s*:", no_comments):
    raise SystemExit("ERROR: patch unexpectedly owns text color")

if '"IBM Plex Sans"' not in s or "font-family:" not in s:
    raise SystemExit("ERROR: IBM Plex Sans family rule missing")

print("CSS audit OK: font-family only.")
PY

export BACKUP_DIR="$BACKUP"

python3 - <<'PY'
from pathlib import Path
import shutil, os, re

app = Path("memeflow-app")
css_name = "memeflow-ibm-plex-sans-v1.css"
backup = Path(os.environ["BACKUP_DIR"])

pages = sorted(app.glob("*.html"))
if not pages:
    raise SystemExit("ERROR: no HTML pages found in memeflow-app")

changed = []
already = []

for page in pages:
    html = page.read_text(encoding="utf-8", errors="ignore")

    if css_name in html:
        already.append(page.name)
        continue

    if "</head>" not in html.lower():
        print(f"SKIP {page.name}: no </head>")
        continue

    # Backup only files we actually modify.
    dst = backup / page
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(page, dst)

    link = f'<link rel="stylesheet" href="{css_name}">'
    # Insert as the final stylesheet layer immediately before </head>.
    html = re.sub(
        r"</head>",
        link + "\n</head>",
        html,
        count=1,
        flags=re.I,
    )
    page.write_text(html, encoding="utf-8")
    changed.append(page.name)

print(f"Changed HTML pages: {len(changed)}")
for name in changed:
    print("  +", name)
for name in already:
    print("  =", name, "(already linked)")
PY

echo
echo "=========================================="
echo "MEMFLOW IBM PLEX SANS v1 INSTALLED"
echo "=========================================="
echo "Font family : IBM Plex Sans"
echo "Colors      : untouched"
echo "Font sizes  : untouched"
echo "Weights     : untouched"
echo "Line height : untouched"
echo "Layout      : untouched"
echo "JS/backend  : untouched"
echo "Restart     : NOT performed"
echo "Backup      : $BACKUP"
echo "=========================================="
