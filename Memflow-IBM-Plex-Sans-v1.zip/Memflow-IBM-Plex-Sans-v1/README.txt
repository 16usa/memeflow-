MEMFLOW — IBM Plex Sans typography patch v1
============================================

What it changes
---------------
- Sets IBM Plex Sans as the site-wide font family.
- Loads the family from Google Fonts.
- Adds a final stylesheet layer to Memflow HTML pages.

What it DOES NOT change
-----------------------
- Existing text colors
- Existing font sizes
- Existing font weights
- Existing line heights
- Existing spacing/layout
- Trading/status semantic colors
- JavaScript/backend logic
- Server/process state

The previous KRYPHOS typography patch is NOT required.

Install from the existing Replit workspace
------------------------------------------
unzip -o Memflow-IBM-Plex-Sans-v1.zip -d /tmp/mf-ibm-plex && bash /tmp/mf-ibm-plex/Memflow-IBM-Plex-Sans-v1/install.sh

No restart is performed by the installer.
