(() => {
  "use strict";

  const ROOT_CLASS = "mf-modern-ui";
  const MOBILE_QUERY = "(max-width: 820px)";
  const MOVABLE_IDS = ["system", "billing", "settings"];
  const anchors = new Map();
  const originalWallet = new WeakMap();

  const params = new URLSearchParams(location.search);
  const classicByUrl = params.get("mfui") === "classic";
  const modernByUrl = params.get("mfui") === "modern";

  function shouldEnable() {
    if (classicByUrl) return false;
    if (modernByUrl) return true;
    return localStorage.getItem("memeflow-ui-2026") !== "classic";
  }

  function setEnabled(enabled) {
    document.documentElement.classList.toggle(ROOT_CLASS, enabled);
    document.documentElement.dataset.mfUi = enabled ? "modern-2026" : "classic";
  }

  function makeWalletIcon() {
    const button = document.getElementById("walletConnectTop");
    if (!button || button.classList.contains("mf-wallet-icon")) return;

    originalWallet.set(button, {
      html: button.innerHTML,
      ariaLabel: button.getAttribute("aria-label")
    });

    const visibleLabel = button.textContent.trim() || "Wallet";
    button.setAttribute("aria-label", visibleLabel);
    button.setAttribute("title", visibleLabel);
    button.classList.add("mf-wallet-icon");
    button.innerHTML = `
      <svg viewBox="0 0 24 24" aria-hidden="true" fill="none"
           stroke="currentColor" stroke-width="1.8" stroke-linecap="round"
           stroke-linejoin="round">
        <path d="M4.25 6.75A2.75 2.75 0 0 1 7 4h10.25A2.75 2.75 0 0 1 20 6.75v10.5A2.75 2.75 0 0 1 17.25 20H7a2.75 2.75 0 0 1-2.75-2.75V6.75Z"/>
        <path d="M4.5 8h12.75A2.75 2.75 0 0 1 20 10.75v4.5A2.75 2.75 0 0 1 17.25 18H4.5"/>
        <path d="M15.25 11.25h4.5v3.5h-4.5a1.75 1.75 0 1 1 0-3.5Z"/>
        <circle cx="15.5" cy="13" r=".55" fill="currentColor" stroke="none"/>
      </svg>`;
  }

  function restoreWalletButton() {
    const button = document.getElementById("walletConnectTop");
    if (!button || !originalWallet.has(button)) return;
    const saved = originalWallet.get(button);
    button.innerHTML = saved.html;
    if (saved.ariaLabel === null) button.removeAttribute("aria-label");
    else button.setAttribute("aria-label", saved.ariaLabel);
    button.removeAttribute("title");
    button.classList.remove("mf-wallet-icon");
  }

  function isPlaceholder(value) {
    const v = String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
    return !v || v === "—" || v === "-" || v === "n/a" || v === "na" ||
      v === "pending" || v === "waiting" || v === "unknown";
  }

  function updatePrimaryMetricVisibility() {
    const card = document.querySelector(".primary-card");
    if (!card) return;

    const ids = ["primaryConfidence", "primaryRisk", "primaryRR"];
    const metrics = ids.map(id => document.getElementById(id)).filter(Boolean);

    if (!metrics.length) return;

    let emptyCount = 0;
    for (const valueNode of metrics) {
      const metric = valueNode.closest(".metric");
      if (!metric) continue;
      const empty = isPlaceholder(valueNode.textContent);
      metric.classList.toggle("mf-empty", empty);
      if (empty) emptyCount += 1;
    }

    card.classList.toggle("mf-metrics-empty", emptyCount === metrics.length);
  }

  function ensureAnchor(node) {
    if (!node || anchors.has(node.id)) return;
    const marker = document.createComment(`mf-modern-ui-anchor:${node.id}`);
    node.parentNode?.insertBefore(marker, node);
    anchors.set(node.id, marker);
  }

  function restoreMovedSections() {
    for (const id of MOVABLE_IDS) {
      const node = document.getElementById(id);
      const marker = anchors.get(id);
      if (node && marker && marker.parentNode) {
        marker.parentNode.insertBefore(node, marker.nextSibling);
      }
    }

    document.querySelector(".mf-more-sections")?.remove();
    document.querySelector(".mf-more-jumpbar")?.remove();
  }

  function ensureMoreJumpbar(sheet, container) {
    if (sheet.querySelector(".mf-more-jumpbar")) return;

    const bar = document.createElement("div");
    bar.className = "mf-more-jumpbar";

    const items = [
      ["system", "System"],
      ["billing", "Plan"],
      ["settings", "Settings"]
    ];

    for (const [id, label] of items) {
      if (!document.getElementById(id)) continue;
      const button = document.createElement("button");
      button.type = "button";
      button.textContent = label;
      button.addEventListener("click", () => {
        document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
      bar.appendChild(button);
    }

    container.parentNode?.insertBefore(bar, container);
  }

  function relocateMobileSections() {
    const enabled = document.documentElement.classList.contains(ROOT_CLASS);
    const mobile = matchMedia(MOBILE_QUERY).matches;

    if (!enabled || !mobile) {
      restoreMovedSections();
      return;
    }

    const sheet = document.getElementById("sheet-more");
    if (!sheet) return;

    let container = sheet.querySelector(".mf-more-sections");
    if (!container) {
      container = document.createElement("div");
      container.className = "mf-more-sections";
      sheet.appendChild(container);
    }

    for (const id of MOVABLE_IDS) {
      const node = document.getElementById(id);
      if (!node) continue;
      ensureAnchor(node);
      if (node.parentNode !== container) container.appendChild(node);
    }

    ensureMoreJumpbar(sheet, container);
  }

  function observeDynamicValues() {
    const targets = ["primaryConfidence", "primaryRisk", "primaryRR"]
      .map(id => document.getElementById(id))
      .filter(Boolean);

    if (!targets.length) return;

    const observer = new MutationObserver(updatePrimaryMetricVisibility);
    targets.forEach(target => {
      observer.observe(target, { childList: true, characterData: true, subtree: true });
    });
    updatePrimaryMetricVisibility();
  }

  function applyEnhancements() {
    const enabled = shouldEnable();
    setEnabled(enabled);

    if (enabled) {
      makeWalletIcon();
      updatePrimaryMetricVisibility();
      relocateMobileSections();
    } else {
      restoreWalletButton();
      restoreMovedSections();
    }
  }

  const media = matchMedia(MOBILE_QUERY);
  if (typeof media.addEventListener === "function") {
    media.addEventListener("change", relocateMobileSections);
  } else if (typeof media.addListener === "function") {
    media.addListener(relocateMobileSections);
  }

  window.MEMEFLOW_UI_PATCH = Object.freeze({
    enable() {
      localStorage.setItem("memeflow-ui-2026", "modern");
      setEnabled(true);
      makeWalletIcon();
      updatePrimaryMetricVisibility();
      relocateMobileSections();
    },
    disable() {
      localStorage.setItem("memeflow-ui-2026", "classic");
      setEnabled(false);
      restoreWalletButton();
      restoreMovedSections();
    },
    reset() {
      localStorage.removeItem("memeflow-ui-2026");
      location.reload();
    },
    status() {
      return document.documentElement.classList.contains(ROOT_CLASS) ? "modern-2026" : "classic";
    }
  });

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      applyEnhancements();
      observeDynamicValues();
    }, { once: true });
  } else {
    applyEnhancements();
    observeDynamicValues();
  }
})();
