#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const cwd = process.cwd();

function exists(p) {
  try { return fs.existsSync(p); } catch { return false; }
}

function detectAppDir() {
  const candidates = [
    cwd,
    path.join(cwd, "memeflow-app"),
    path.resolve(here, ".."),
    path.resolve(here, "../memeflow-app"),
    path.resolve(here, "../../memeflow-app")
  ];

  for (const dir of candidates) {
    if (exists(path.join(dir, "index.html")) && exists(path.join(dir, "app-server.mjs"))) {
      return dir;
    }
  }

  throw new Error(
    "MEMEFLOW app was not found. Run this installer from the repository root " +
    "or from the memeflow-app directory."
  );
}

function sha256(text) {
  return crypto.createHash("sha256").update(text).digest("hex");
}

const appDir = detectAppDir();
const indexPath = path.join(appDir, "index.html");
const destDir = path.join(appDir, "ui-patches");
const stateDir = path.join(appDir, ".memeflow-patches", "modern-ui-2026");
const backupPath = path.join(stateDir, "index.before-modern-ui-2026.html");
const manifestPath = path.join(stateDir, "manifest.json");

const cssSource = path.join(here, "modern-ui.css");
const jsSource = path.join(here, "modern-ui.js");
const cssDest = path.join(destDir, "modern-ui-2026.css");
const jsDest = path.join(destDir, "modern-ui-2026.js");

if (!exists(cssSource) || !exists(jsSource)) {
  throw new Error("Patch files modern-ui.css / modern-ui.js are missing.");
}

let html = fs.readFileSync(indexPath, "utf8");

if (!html.includes("</head>") || !html.includes("</body>")) {
  throw new Error("index.html has an unexpected structure; no files were changed.");
}

const HEAD_BEGIN = "<!-- MEMEFLOW_MODERN_UI_2026_HEAD:BEGIN -->";
const HEAD_END = "<!-- MEMEFLOW_MODERN_UI_2026_HEAD:END -->";
const BODY_BEGIN = "<!-- MEMEFLOW_MODERN_UI_2026_BODY:BEGIN -->";
const BODY_END = "<!-- MEMEFLOW_MODERN_UI_2026_BODY:END -->";

const headBlock = `${HEAD_BEGIN}
<link id="memeflow-modern-ui-2026" rel="stylesheet" href="./ui-patches/modern-ui-2026.css">
${HEAD_END}`;

const bodyBlock = `${BODY_BEGIN}
<script id="memeflow-modern-ui-2026-script" src="./ui-patches/modern-ui-2026.js" defer></script>
${BODY_END}`;

fs.mkdirSync(destDir, { recursive: true });
fs.mkdirSync(stateDir, { recursive: true });

if (!exists(backupPath)) {
  fs.copyFileSync(indexPath, backupPath);
}

fs.copyFileSync(cssSource, cssDest);
fs.copyFileSync(jsSource, jsDest);

const beforeHash = sha256(html);

const headRegex = /<!-- MEMEFLOW_MODERN_UI_2026_HEAD:BEGIN -->[\s\S]*?<!-- MEMEFLOW_MODERN_UI_2026_HEAD:END -->\s*/g;
const bodyRegex = /<!-- MEMEFLOW_MODERN_UI_2026_BODY:BEGIN -->[\s\S]*?<!-- MEMEFLOW_MODERN_UI_2026_BODY:END -->\s*/g;

html = html.replace(headRegex, "").replace(bodyRegex, "");
html = html.replace("</head>", `${headBlock}\n</head>`);
html = html.replace("</body>", `${bodyBlock}\n</body>`);

fs.writeFileSync(indexPath, html, "utf8");

const manifest = {
  patch: "MEMEFLOW Modern UI 2026",
  installedAt: new Date().toISOString(),
  appDir,
  indexPath,
  originalIndexBackup: backupPath,
  indexShaBeforeInstall: beforeHash,
  indexShaAfterInstall: sha256(html),
  files: [cssDest, jsDest],
  disableWithoutUninstall: "?mfui=classic",
  forceModern: "?mfui=modern"
};

fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + "\n", "utf8");

console.log("");
console.log("✓ MEMEFLOW Modern UI 2026 installed.");
console.log(`✓ Target: ${indexPath}`);
console.log("✓ Trading / wallet / AI / billing / server logic was not edited.");
console.log("✓ Backup saved before the first installation.");
console.log("");
console.log("Preview classic UI without uninstalling: add ?mfui=classic to the URL.");
console.log("Re-enable modern UI: add ?mfui=modern or remove the classic preference.");
console.log(`Rollback: node "${path.join(here, "revert.mjs")}"`);
console.log("");
