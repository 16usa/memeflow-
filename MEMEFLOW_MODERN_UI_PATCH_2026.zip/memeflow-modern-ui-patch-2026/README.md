# MEMEFLOW Modern UI 2026 — reversible patch

This patch modernizes the presentation layer without changing trading, AI, wallet,
billing, API, server or risk logic.

## What changes visually

- Calmer graphite surfaces and fewer visible borders.
- More current Apple/Linear-like typography and spacing.
- Compact header.
- Header wallet control becomes icon-only while keeping its accessible label.
- Primary Candidate gets stronger visual priority.
- Empty Confidence / Risk / Expected RR cells are hidden until real values exist.
- LOCKED execution state is visually neutral instead of looking like an error.
- Settings become a compact single-list system instead of cards-inside-cards.
- On mobile, System / Plans & Billing / AI & Trading Settings are moved into More.
  Existing DOM nodes are moved at runtime, so their IDs and event handlers are preserved.
- Bottom navigation uses a cleaner active indicator rather than a large active rectangle.

## Install in Replit

Upload this entire folder to the repository root, then open Shell and run:

```bash
node memeflow-modern-ui-patch-2026/install.mjs
```

If you uploaded the files directly into `memeflow-app`, run:

```bash
node install.mjs
```

Restart the app after installation if Replit does not auto-reload.

## Instant A/B check

You do not have to uninstall the patch to compare it with the old design.

Classic preview:

```text
?mfui=classic
```

Force modern preview:

```text
?mfui=modern
```

The browser console also exposes:

```js
MEMEFLOW_UI_PATCH.disable()
MEMEFLOW_UI_PATCH.enable()
MEMEFLOW_UI_PATCH.reset()
MEMEFLOW_UI_PATCH.status()
```

## Roll back

From the repository root:

```bash
node memeflow-modern-ui-patch-2026/revert.mjs
```

The rollback removes only the injected CSS/JS tags and patch files. It does not replace
the whole `index.html`, so unrelated edits made after installation are preserved.

A copy of the original `index.html` from the first installation is also kept at:

```text
memeflow-app/.memeflow-patches/modern-ui-2026/index.before-modern-ui-2026.html
```

## Safety behavior

The installer:

1. Detects the MEMEFLOW app directory.
2. Refuses to run if `index.html` does not contain normal `</head>` and `</body>` anchors.
3. Creates a backup before the first installation.
4. Installs one scoped CSS file and one scoped JS file.
5. Is idempotent: running it again updates the same patch instead of stacking duplicates.

All patch CSS is scoped under `html.mf-modern-ui`.
