#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const cwd = process.cwd();

function exists(p) {
  try { return fs.existsSync(p); } catch { return false; }
}

function detectAppDir() {
  const candidates = [
    cwd,
    path.join(cwd, "memeflow-app"),
    path.resolve(here, ".."),
    path.resolve(here, "../memeflow-app"),
    path.resolve(here, "../../memeflow-app")
  ];

  for (const dir of candidates) {
    if (exists(path.join(dir, "index.html")) && exists(path.join(dir, "app-server.mjs"))) {
      return dir;
    }
  }

  throw new Error(
    "MEMEFLOW app was not found. Run this rollback script from the repository root " +
    "or from the memeflow-app directory."
  );
}

const appDir = detectAppDir();
const indexPath = path.join(appDir, "index.html");
const cssDest = path.join(appDir, "ui-patches", "modern-ui-2026.css");
const jsDest = path.join(appDir, "ui-patches", "modern-ui-2026.js");
const stateDir = path.join(appDir, ".memeflow-patches", "modern-ui-2026");
const backupPath = path.join(stateDir, "index.before-modern-ui-2026.html");

let html = fs.readFileSync(indexPath, "utf8");

const headRegex = /\s*<!-- MEMEFLOW_MODERN_UI_2026_HEAD:BEGIN -->[\s\S]*?<!-- MEMEFLOW_MODERN_UI_2026_HEAD:END -->/g;
const bodyRegex = /\s*<!-- MEMEFLOW_MODERN_UI_2026_BODY:BEGIN -->[\s\S]*?<!-- MEMEFLOW_MODERN_UI_2026_BODY:END -->/g;

const cleaned = html.replace(headRegex, "").replace(bodyRegex, "");
fs.writeFileSync(indexPath, cleaned, "utf8");

for (const file of [cssDest, jsDest]) {
  if (exists(file)) fs.rmSync(file, { force: true });
}

console.log("");
console.log("✓ MEMEFLOW Modern UI 2026 removed.");
console.log("✓ The injected CSS/JS links were removed.");
console.log("✓ The original backup was kept for safety:");
console.log(`  ${backupPath}`);
console.log("");
console.log("No backend, trading, wallet, AI or billing logic was touched by the rollback.");
console.log("");
