# MEMEFLOW Safe Candlestick Repair

This replaces the broken premium chart patch with a safer implementation.

It first restores `index.html.before-premium-candlestick-chart` when the broken patch is detected, then installs:

- token image and token summary;
- large live price;
- green/red candlesticks generated from the existing price series;
- timeframe controls already present in MEMEFLOW;
- current-price guide;
- responsive mobile layout.

It does not add a global document observer and does not create new market-data polling.

## Replit steps

Upload this ZIP into the project root and run:

```bash
unzip -o MEMEFLOW_SAFE_CANDLESTICK_REPAIR.zip
node scripts/safe-candlestick-repair.mjs
```

After `SUCCESS`, press **Stop → Run**.

## Rollback

```bash
cp memeflow-app/index.html.before-safe-candlestick-chart memeflow-app/index.html
```
