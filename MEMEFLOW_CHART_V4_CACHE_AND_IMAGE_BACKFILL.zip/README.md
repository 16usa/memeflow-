# MEMEFLOW Chart v4 + Existing Token Image Backfill

This fixes two issues visible in Safari:

1. Safari/Replit can continue serving an older `market-chart-final.js`.
   The patch installs a uniquely named `market-chart-final-v4.js` and updates
   `index.html`, forcing the browser to load the corrected renderer.

2. Existing tokens were discovered before backend metadata-image support existed.
   The backfill reads each stored token's Pump.fun metadata URI and stores `imageUrl`.

## Apply

```bash
unzip -o MEMEFLOW_CHART_V4_CACHE_AND_IMAGE_BACKFILL.zip
node scripts/install-chart-v4-cache-bust.mjs
node scripts/backfill-token-images.mjs
```

Then press **Stop → Run** and refresh Safari.

The backfill result reports how many stored tokens received images.

## Rollback

```bash
cp memeflow-app/index.html.before-chart-v4-cache-bust memeflow-app/index.html
cp memeflow-app/data/state.json.before-token-image-backfill memeflow-app/data/state.json
```
