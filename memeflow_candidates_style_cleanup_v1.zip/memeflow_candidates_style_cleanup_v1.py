#!/usr/bin/env python3
from __future__ import annotations

import shutil
import subprocess
from datetime import datetime
from pathlib import Path

ROOT = Path.cwd()
APP = ROOT / "memeflow-app"

FILES = [
    APP / "trading.html",
    APP / "trading.css",
    APP / "trading-light-polish-v61.css",
    APP / "trading-visual-hierarchy-v67.css",
    APP / "memeflow-dark-x-surface-v131.css",
    APP / "memeflow-trading-white-surfaces-v154.css",
    APP / "memeflow-candidate-state-filters-v119.css",
    APP / "memeflow-candidate-edit-fill-v121.css",
]

for path in FILES:
    if not path.exists():
        raise SystemExit(f"ABORT: expected file not found: {path}")

stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
backup = ROOT / ".memeflow-backups" / f"candidates-style-cleanup-{stamp}"
backup.mkdir(parents=True, exist_ok=False)

for path in FILES:
    dest = backup / path.relative_to(ROOT)
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, dest)


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8")


def replace_once(path: Path, old: str, new: str, label: str) -> None:
    text = read(path)
    count = text.count(old)
    if count != 1:
        raise RuntimeError(
            f"[{label}] expected exactly 1 match in {path}, found {count}"
        )
    write(path, text.replace(old, new, 1))


def remove_once(path: Path, old: str, label: str) -> None:
    replace_once(path, old, "", label)


def remove_between(path: Path, start: str, end: str, label: str) -> None:
    text = read(path)
    a = text.find(start)
    b = text.find(end, a + len(start)) if a >= 0 else -1
    if a < 0 or b < 0:
        raise RuntimeError(f"[{label}] marker not found in {path}")
    write(path, text[:a] + text[b:])


def restore_backup() -> None:
    for original in FILES:
        saved = backup / original.relative_to(ROOT)
        if saved.exists():
            original.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(saved, original)


def main() -> None:
    trading_css = APP / "trading.css"

    replace_once(
        trading_css,
        '.candidate-filter {\n  padding: 7px 8px;\n  display: flex;\n  gap: 5px;\n  border-bottom: 1px solid rgba(111, 154, 172, .055);\n}\n',
        '.candidate-filter {\n  display: grid;\n  grid-template-columns: repeat(5, minmax(0, 1fr));\n  align-items: stretch;\n  gap: 0;\n  padding: 0;\n  border-top: 0;\n  border-left: 0;\n  border-right: 0;\n  border-bottom: var(--mf-structure-hairline, 1px) solid var(--mf-structure-divider, rgba(111, 154, 172, .055));\n  background: transparent;\n}\n',
        "canonical candidate filter container",
    )

    replace_once(
        trading_css,
        ".candidate-filter button, .timeframes button {\n",
        ".timeframes button {\n",
        "detach Candidate buttons from legacy timeframe rule",
    )

    remove_once(
        trading_css,
        '.candidate-filter button {\n  min-height: 27px;\n  padding: 0 8px;\n}\n\n',
        "remove legacy Candidate button geometry",
    )

    replace_once(
        trading_css,
        ".candidate-filter button.active, .timeframes button.active {\n",
        ".timeframes button.active {\n",
        "detach Candidate active state from legacy timeframe rule",
    )

    canonical = r'''

/* ==========================================================================
   MEMEFLOW CANDIDATES — CANONICAL PRESENTATION CONTRACT
   Single page-level owner for Candidates presentation.

   Preserves the approved current result:
   - five equal filter segments
   - 48px segment height
   - no segment fill / no colored frames
   - tertiary inactive text / primary active text
   - selected-row left stripe remains visually absent
   - dark selected/hover row keeps the existing restrained tint
   - light Candidates module/rows stay true white
   - empty state remains frameless 8px tertiary system text
   ========================================================================== */

body.mf-page-trading.mf-trading-terminal
.candidates-panel .candidate-filter {
  display: grid !important;
  grid-template-columns: repeat(5, minmax(0, 1fr)) !important;
  align-items: stretch !important;
  gap: 0 !important;
  row-gap: 0 !important;
  column-gap: 0 !important;
  padding: 0 !important;
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  border-top: 0 !important;
  border-left: 0 !important;
  border-right: 0 !important;
  border-bottom-width: var(--mf-structure-hairline, 1px) !important;
  border-bottom-style: solid !important;
  border-bottom-color: var(--mf-structure-divider, rgba(111, 154, 172, .055)) !important;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel .candidate-filter > button[data-filter] {
  box-sizing: border-box !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  width: 100% !important;
  min-width: 0 !important;
  height: 48px !important;
  min-height: 48px !important;
  margin: 0 !important;
  padding: 0 4px !important;
  border: 0 !important;
  border-radius: 0 !important;
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  box-shadow: none !important;
  color: var(--mf-text-tertiary, #818c99) !important;
  font-size: 9px !important;
  line-height: 1 !important;
  font-weight: 650 !important;
  letter-spacing: .025em !important;
  text-transform: uppercase !important;
  white-space: nowrap !important;
  -webkit-text-size-adjust: none !important;
  text-size-adjust: none !important;
  touch-action: manipulation;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel .candidate-filter > button[data-filter].active {
  color: var(--mf-text-primary, #e7e9ea) !important;
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  box-shadow: none !important;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel .candidate-filter > button[data-filter]:focus-visible {
  outline: 1px solid rgba(161, 170, 181, .55) !important;
  outline-offset: 2px !important;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel > .panel-head {
  border-bottom: 0 !important;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel #candidateList > .candidate {
  border-left: 2px solid transparent !important;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel #candidateList > .candidate:hover,
body.mf-page-trading.mf-trading-terminal
.candidates-panel #candidateList > .candidate.selected {
  background: rgba(85, 217, 255, .035);
  background-image: none;
}

body.mf-page-trading.mf-trading-terminal
.candidates-panel .candidate-list > .empty {
  background: transparent !important;
  background-color: transparent !important;
  background-image: none !important;
  border: 0 !important;
  border-color: transparent !important;
  border-radius: 0 !important;
  box-shadow: none !important;
  color: var(--mf-text-tertiary, #818c99) !important;
  font-size: var(--mf-type-system, 8px) !important;
  line-height: 1.2 !important;
  font-weight: 500 !important;
}

html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel,
html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel > .panel-head,
html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel > .candidate-filter,
html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel > #candidateList,
html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel #candidateList > .candidate,
html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel #candidateList > .candidate.selected,
html[data-theme="light"]
body.mf-page-trading.mf-trading-terminal
.candidates-panel #candidateList > .candidate:hover {
  background: #ffffff !important;
  background-color: #ffffff !important;
  background-image: none !important;
}

@media (max-width: 820px) {
  body.mf-page-trading.mf-trading-terminal
  .candidates-panel #candidateList > .candidate.selected {
    padding-left: 7px !important;
  }
}

/* MEMEFLOW_CANDIDATES_CANONICAL_PRESENTATION_END */
'''

    text = read(trading_css)
    if "MEMEFLOW_CANDIDATES_CANONICAL_PRESENTATION_END" in text:
        raise RuntimeError("canonical Candidates block already exists")
    write(trading_css, (text.rstrip() + canonical).rstrip() + "\n")

    # V61: remove obsolete Candidates-specific surface/interaction ownership.
    v61 = APP / "trading-light-polish-v61.css"
    replace_once(
        v61,
        'html[data-theme="light"] body.mf-trading-terminal .terminal > .panel,\nhtml[data-theme="light"] body.mf-trading-terminal .center-stack > .panel {\n',
        'html[data-theme="light"] body.mf-trading-terminal .terminal > .panel:not(.candidates-panel),\nhtml[data-theme="light"] body.mf-trading-terminal .center-stack > .panel {\n',
        "exclude Candidates from V61 panel surface",
    )
    replace_once(
        v61,
        'html[data-theme="light"] body.mf-trading-terminal .candidate,\nhtml[data-theme="light"] body.mf-trading-terminal .position-row,\nhtml[data-theme="light"] body.mf-trading-terminal .trade-row.trade-log-row {\n',
        'html[data-theme="light"] body.mf-trading-terminal .position-row,\nhtml[data-theme="light"] body.mf-trading-terminal .trade-row.trade-log-row {\n',
        "exclude Candidate rows from V61",
    )
    remove_once(
        v61,
        'html[data-theme="light"] body.mf-trading-terminal .candidate:hover,\nhtml[data-theme="light"] body.mf-trading-terminal .candidate.selected {\n  background: var(--mf-trading-v61-inset) !important;\n}\n\n',
        "remove V61 Candidate selected fill",
    )
    replace_once(
        v61,
        'html[data-theme="light"] body.mf-trading-terminal\n.candidate-filter button:not(.active),\nhtml[data-theme="light"] body.mf-trading-terminal\n.timeframes button:not(.active),\n',
        'html[data-theme="light"] body.mf-trading-terminal\n.timeframes button:not(.active),\n',
        "remove Candidate filter from V61 inactive controls",
    )
    replace_once(
        v61,
        '  html[data-theme="light"] body.mf-trading-terminal\n  .candidate-filter button:not(.active):hover,\n  html[data-theme="light"] body.mf-trading-terminal\n  .timeframes button:not(.active):hover,\n',
        '  html[data-theme="light"] body.mf-trading-terminal\n  .timeframes button:not(.active):hover,\n',
        "remove Candidate filter from V61 hover controls",
    )
    replace_once(
        v61,
        '  .chart-panel,\n  .strategy-summary-panel,\n  .positions-panel,\n  .candidates-panel,\n  .bottom-history-panel\n',
        '  .chart-panel,\n  .strategy-summary-panel,\n  .positions-panel,\n  .bottom-history-panel\n',
        "remove Candidates from V153 group",
    )
    remove_once(
        v61,
        'html[data-theme="light"] body.mf-trading-terminal .terminal > .panel.candidates-panel,\n',
        "remove Candidates from V153.1 group",
    )

    # V67: old colored selection stripe is no longer an owner.
    v67 = APP / "trading-visual-hierarchy-v67.css"
    remove_once(
        v67,
        '/* Selected candidate: keep one restrained accent instead of stacked effects. */\nbody.mf-page-trading.mf-trading-terminal .candidate.selected {\n  border-left: 2px solid var(--mf-v67-selected-accent) !important;\n  box-shadow: none !important;\n}\n\nbody.mf-page-trading.mf-trading-terminal .candidate:not(.selected) {\n  border-left: 2px solid transparent !important;\n}\n\n',
        "remove V67 Candidate selection stripe",
    )
    remove_once(
        v67,
        '  body.mf-page-trading.mf-trading-terminal .candidate.selected {\n    padding-left: 7px !important;\n  }\n',
        "move mobile selected padding to canonical owner",
    )

    # V131/V152: remove late Candidates-specific exceptions; shared system rules stay.
    v131 = APP / "memeflow-dark-x-surface-v131.css"
    remove_between(
        v131,
        '/* --------------------------------------------------------------------------\n   THIRD / LIGHTEST DARK TONE\n',
        '/* --------------------------------------------------------------------------\n   X-STYLE SEPARATORS\n',
        "remove V131 Candidate dark-fill exception",
    )
    remove_between(
        v131,
        '/* --------------------------------------------------------------------------\n   CANDIDATES FILTER\n   -------------------------------------------------------------------------- */\n',
        '/* --------------------------------------------------------------------------\n   SELECTED ROW LEFT ACCENT\n',
        "remove V152 Candidate filter override",
    )
    remove_once(
        v131,
        '/* Candidate V67 uses a 2px border-left accent.\n   Make only the accent color transparent so row geometry does not move. */\nhtml[data-theme]\nbody.mf-page-trading.mf-trading-terminal\n.candidates-panel\n.candidate.selected {\n  border-left-color: transparent !important;\n}\n\n',
        "remove V152 Candidate stripe override",
    )

    # V154: other modules remain; Candidates white surface moves to canonical owner.
    v154 = APP / "memeflow-trading-white-surfaces-v154.css"
    remove_once(
        v154,
        'html[data-theme="light"]\nbody.mf-page-trading.mf-trading-terminal\n.terminal > .panel.candidates-panel,\n\n',
        "remove Candidate panel from V154 outer group",
    )
    remove_between(
        v154,
        '/* Candidates: title, strip container, list, all rows and selected/hover rows. */\n',
        '/* Recent trades: header, list and every trade row. */\n',
        "remove V154 Candidates surface section",
    )
    replace_once(
        v154,
        '  .chart-panel,\n  .strategy-summary-panel,\n  .positions-panel,\n  .candidates-panel,\n  .bottom-history-panel\n',
        '  .chart-panel,\n  .strategy-summary-panel,\n  .positions-panel,\n  .bottom-history-panel\n',
        "remove Candidates from V154 empty group",
    )

    # Remove obsolete V119/V121 links and files.
    html = APP / "trading.html"
    remove_once(
        html,
        '<!-- MEMEFLOW_CANDIDATE_STATE_FILTERS_V119_ASSET -->\n<link rel="stylesheet" href="/memeflow-candidate-state-filters-v119.css?v=candidate-state-filters-v119-20260907">\n<!-- /MEMEFLOW_CANDIDATE_STATE_FILTERS_V119_ASSET -->\n',
        "remove V119 asset",
    )
    remove_once(
        html,
        '<!-- MEMEFLOW_CANDIDATE_EDIT_FILL_V121_ASSET -->\n<link rel="stylesheet" href="/memeflow-candidate-edit-fill-v121.css?v=candidate-empty-system-v123-1-20260907">\n<!-- /MEMEFLOW_CANDIDATE_EDIT_FILL_V121_ASSET -->\n',
        "remove V121 asset",
    )

    for old, new, label in [
        (
            '<link rel="stylesheet" href="/trading.css?v=chart-header-geometry-v95-1-20260909">',
            '<link rel="stylesheet" href="/trading.css?v=candidates-canonical-cleanup-v1-20260909">',
            "cache-bust trading.css",
        ),
        (
            '<link rel="stylesheet" href="/trading-light-polish-v61.css?v=trading-light-white-modules-v153-1-20260909">',
            '<link rel="stylesheet" href="/trading-light-polish-v61.css?v=candidates-cleanup-v1-20260909">',
            "cache-bust V61",
        ),
        (
            '<link rel="stylesheet" href="/trading-visual-hierarchy-v67.css?v=chart-header-geometry-v95-1-20260909">',
            '<link rel="stylesheet" href="/trading-visual-hierarchy-v67.css?v=candidates-cleanup-v1-20260909">',
            "cache-bust V67",
        ),
        (
            '<link rel="stylesheet" href="/memeflow-dark-x-surface-v131.css?v=candidate-filter-stripe-cleanup-v152-20260908">',
            '<link rel="stylesheet" href="/memeflow-dark-x-surface-v131.css?v=candidates-cleanup-v1-20260909">',
            "cache-bust V131",
        ),
        (
            '<link rel="stylesheet" href="/memeflow-trading-white-surfaces-v154.css?v=white-modules-v155-residual-final-20260909">',
            '<link rel="stylesheet" href="/memeflow-trading-white-surfaces-v154.css?v=candidates-cleanup-v1-20260909">',
            "cache-bust V154",
        ),
    ]:
        replace_once(html, old, new, label)

    (APP / "memeflow-candidate-state-filters-v119.css").unlink()
    (APP / "memeflow-candidate-edit-fill-v121.css").unlink()

    # Verification.
    html_text = read(html)
    if "memeflow-candidate-state-filters-v119.css" in html_text:
        raise RuntimeError("V119 is still referenced")
    if "memeflow-candidate-edit-fill-v121.css" in html_text:
        raise RuntimeError("V121 is still referenced")

    css_text = read(trading_css)
    for token in (
        "MEMEFLOW CANDIDATES — CANONICAL PRESENTATION CONTRACT",
        "grid-template-columns: repeat(5, minmax(0, 1fr))",
        "height: 48px !important",
        "color: var(--mf-text-tertiary",
        "color: var(--mf-text-primary",
    ):
        if token not in css_text:
            raise RuntimeError(f"canonical verification failed: {token}")

    subprocess.run(["git", "diff", "--check"], cwd=ROOT, check=True)


try:
    main()
except BaseException as exc:
    restore_backup()
    print(f"ABORT: {exc}")
    print("All touched files were restored automatically.")
    print(f"Backup retained at: {backup}")
    raise SystemExit(1)

rollback = backup / "ROLLBACK.sh"
rollback.write_text(
    '''#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BACKUP="$(cd "$(dirname "$0")" && pwd)"
for f in \
  memeflow-app/trading.html \
  memeflow-app/trading.css \
  memeflow-app/trading-light-polish-v61.css \
  memeflow-app/trading-visual-hierarchy-v67.css \
  memeflow-app/memeflow-dark-x-surface-v131.css \
  memeflow-app/memeflow-trading-white-surfaces-v154.css \
  memeflow-app/memeflow-candidate-state-filters-v119.css \
  memeflow-app/memeflow-candidate-edit-fill-v121.css
do
  mkdir -p "$ROOT/$(dirname "$f")"
  cp "$BACKUP/$f" "$ROOT/$f"
done
echo "Rollback complete."
git -C "$ROOT" status --short
''',
    encoding="utf-8",
)
rollback.chmod(0o755)

print("CANDIDATES STYLE CLEANUP APPLIED")
print(f"Backup:   {backup}")
print(f"Rollback: {rollback}")
print()
subprocess.run(["git", "status", "--short"], cwd=ROOT, check=False)
print()
print("Review:")
print("  git diff -- memeflow-app/trading.html memeflow-app/trading.css \\")
print("    memeflow-app/trading-light-polish-v61.css \\")
print("    memeflow-app/trading-visual-hierarchy-v67.css \\")
print("    memeflow-app/memeflow-dark-x-surface-v131.css \\")
print("    memeflow-app/memeflow-trading-white-surfaces-v154.css")
print()
print("Commit after visual QA:")
print('  git add memeflow-app/trading.html memeflow-app/trading.css memeflow-app/trading-light-polish-v61.css memeflow-app/trading-visual-hierarchy-v67.css memeflow-app/memeflow-dark-x-surface-v131.css memeflow-app/memeflow-trading-white-surfaces-v154.css memeflow-app/memeflow-candidate-state-filters-v119.css memeflow-app/memeflow-candidate-edit-fill-v121.css')
print('  git commit -m "refactor(trading): canonicalize Candidates styles"')
