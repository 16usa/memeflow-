MEMEFLOW — Candidates style cleanup v1

Run from the repository root in Replit (the directory that contains memeflow-app/):

  python memeflow_candidates_style_cleanup_v1.py

The installer:
- creates .memeflow-backups/candidates-style-cleanup-<timestamp>/
- moves the final Candidates presentation contract into trading.css
- removes obsolete V119 and V121 Candidates CSS assets from trading.html
- deletes the obsolete V119/V121 CSS files after backup
- removes stale Candidates-specific overrides from V61, V67, V131/V152 and V154
- keeps shared global theme/contrast/structural contracts intact
- updates CSS cache-busting query strings
- runs git diff --check
- automatically restores every touched file if any expected source block does not match
- creates ROLLBACK.sh in the backup folder

After it succeeds:

  git status --short
  git diff --check

Then visually verify Trading Terminal > Candidates in:
- Light theme
- Dark theme
- Desktop
- Mobile
- filter active/inactive states
- selected candidate
- empty state

If correct, commit only the touched files shown by git status.

Rollback at any time:

  bash .memeflow-backups/candidates-style-cleanup-<timestamp>/ROLLBACK.sh
