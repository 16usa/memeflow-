#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="${1:-$(pwd)}"

if [ -d "$ROOT/memeflow-app" ]; then
  TARGET="$ROOT/memeflow-app"
elif [ "$(basename "$ROOT")" = "memeflow-app" ] && [ -d "$ROOT" ]; then
  TARGET="$ROOT"
else
  echo "ERROR: memeflow-app not found in: $ROOT" >&2
  echo "Open the project Shell and run this installer from the repository root." >&2
  exit 1
fi

install -m 0644 "$SCRIPT_DIR/x100.html" "$TARGET/x100.html"
install -m 0644 "$SCRIPT_DIR/x100.css" "$TARGET/x100.css"

python3 - "$TARGET/x100.html" <<'PY'
from pathlib import Path
import re
import sys

p = Path(sys.argv[1])
html = p.read_text(encoding="utf-8")
required = [
    "X100 Network", "TRACE", "VECTOR", "NEXUS", "FORGE", "VAULT",
    "$40", "$25", "$20", "$10", "$5", "not a promise of returns"
]
missing = [item for item in required if item.lower() not in html.lower()]
assert not missing, f"missing required content: {missing}"
assert sum(map(int, re.findall(r'data-allocation="(\d+)"', html))) == 100
print("X100 page installation verification: PASS")
PY
