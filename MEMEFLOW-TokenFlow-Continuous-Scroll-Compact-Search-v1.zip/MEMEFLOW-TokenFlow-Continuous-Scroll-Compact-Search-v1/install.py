#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

PATCH = 'MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1'
HERE = Path(__file__).resolve().parent


def app_root() -> Path:
    candidates = [
        Path.cwd() / 'memeflow-app',
        Path('/home/runner/workspace/memeflow-app'),
        Path.cwd(),
    ]
    for p in candidates:
        if (p / 'system-tokens.js').exists() and (p / 'system-tokens.html').exists():
            return p.resolve()
    raise SystemExit('ERROR: could not find memeflow-app (system-tokens.js/system-tokens.html).')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    n = text.count(old)
    if n != 1:
        raise RuntimeError(f'{label}: expected exactly 1 match, found {n}')
    return text.replace(old, new, 1)


def check(cmd, cwd):
    print('+', ' '.join(cmd))
    subprocess.run(cmd, cwd=cwd, check=True)


def main():
    root = app_root()
    print('MEMEFLOW app:', root)

    js_path = root / 'system-tokens.js'
    html_path = root / 'system-tokens.html'
    css_path = root / 'memeflow-token-flow-continuous-v1.css'

    # Idempotent install.
    current_js = js_path.read_text(encoding='utf-8')
    current_html = html_path.read_text(encoding='utf-8')
    if PATCH in current_js and 'memeflow-token-flow-continuous-v1.css' in current_html:
        print('Patch already installed; verifying only.')
        check(['node', '--check', 'system-tokens.js'], root)
        print('INSTALLATION VERIFICATION: PASS')
        return

    stamp = dt.datetime.now().strftime('%Y%m%d-%H%M%S')
    backup = root / '.memeflow-backups' / f'token-flow-continuous-v1-{stamp}'
    backup.mkdir(parents=True, exist_ok=False)

    shutil.copy2(js_path, backup / 'system-tokens.js')
    shutil.copy2(html_path, backup / 'system-tokens.html')
    if css_path.exists():
        shutil.copy2(css_path, backup / 'memeflow-token-flow-continuous-v1.css')
    (backup / '.css_preexisted').write_text('1' if css_path.exists() else '0', encoding='utf-8')
    print('Backup:', backup)

    try:
        js = current_js

        # render(): page number becomes progressive visible chunk count.
        old_spaced = """  const start =\n    (state.page - 1) *\n    PAGE_SIZE;\n\n  const pageRows =\n    rows.slice(\n      start,\n      start + PAGE_SIZE\n    );"""
        new_spaced = """  // MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1\n  // state.page is now the number of progressively revealed PAGE_SIZE chunks.\n  // The first chunk renders immediately; more chunks are appended by scroll.\n  const start = 0;\n\n  const pageRows =\n    rows.slice(\n      0,\n      Math.min(rows.length, state.page * PAGE_SIZE)\n    );"""
        js = replace_once(js, old_spaced, new_spaced, 'render pagination block')

        # Keyed one-second reconcile must use exactly the same visible prefix.
        old_compact = """  const start=\n    (state.page-1)*PAGE_SIZE;\n\n  const pageRows=\n    rows.slice(\n      start,\n      start+PAGE_SIZE\n    );"""
        new_compact = """  // MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1_RECONCILE\n  const start=0;\n\n  const pageRows=\n    rows.slice(\n      0,\n      Math.min(rows.length,state.page*PAGE_SIZE)\n    );"""
        js = replace_once(js, old_compact, new_compact, 'keyed reconcile pagination block')

        infinite_code = r'''

/* ===== MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1 =====
 * Pagination UI is intentionally removed. state.page is retained as a
 * backwards-compatible chunk counter so every existing filter/sort/search
 * reset (state.page = 1) keeps working exactly as before.
 *
 * When the user approaches the bottom of the document, reveal one more
 * PAGE_SIZE chunk and re-render in place. No network request, trading state,
 * scoring rule, holder logic or market data source is changed here.
 */
let __mfContinuousScrollRafV1 = 0;
let __mfContinuousScrollBusyV1 = false;

function __mfContinuousScrollCheckV1(){
  if (__mfContinuousScrollBusyV1) return;

  const rows = filteredRows();
  const totalChunks = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));

  if (state.page >= totalChunks) return;

  const root = document.documentElement;
  const scrollBottom = window.scrollY + window.innerHeight;
  const triggerAt = Math.max(0, root.scrollHeight - Math.max(640, window.innerHeight * 0.75));

  if (scrollBottom < triggerAt) return;

  __mfContinuousScrollBusyV1 = true;
  state.page += 1;

  try {
    render();
    if (typeof __mfKickCardClockV19 === 'function') {
      __mfKickCardClockV19();
    }
  } finally {
    __mfContinuousScrollBusyV1 = false;
  }

  // If the newly revealed chunk still does not fill the viewport, continue.
  requestAnimationFrame(__mfContinuousScrollCheckV1);
}

function __mfContinuousScrollScheduleV1(){
  if (__mfContinuousScrollRafV1) return;
  __mfContinuousScrollRafV1 = requestAnimationFrame(() => {
    __mfContinuousScrollRafV1 = 0;
    __mfContinuousScrollCheckV1();
  });
}

window.addEventListener('scroll', __mfContinuousScrollScheduleV1, {passive:true});
window.addEventListener('resize', __mfContinuousScrollScheduleV1, {passive:true});
requestAnimationFrame(__mfContinuousScrollCheckV1);
/* ===== /MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1 ===== */
'''
        if PATCH not in js:
            js += infinite_code
        else:
            # render marker exists after the first replacement; append runtime block
            # only when the terminal marker is not present.
            if 'let __mfContinuousScrollRafV1' not in js:
                js += infinite_code

        html = current_html
        css_link = '<link rel="stylesheet" href="/memeflow-token-flow-continuous-v1.css?v=continuous-compact-v1-20260913">'
        if 'memeflow-token-flow-continuous-v1.css' not in html:
            # Put this after all existing page styles so it is the final owner of
            # toolbar/pagination geometry, including V62 mobile one-column rules.
            marker = '</head>'
            html = replace_once(html, marker, css_link + '\n' + marker, 'HTML head close')

        js_path.write_text(js, encoding='utf-8')
        html_path.write_text(html, encoding='utf-8')
        shutil.copy2(HERE / 'files' / 'memeflow-token-flow-continuous-v1.css', css_path)

        # Syntax + structural guards.
        check(['node', '--check', 'system-tokens.js'], root)

        verify = (HERE / 'verify.py')
        subprocess.run([sys.executable, str(verify), str(root)], check=True)

        # Record latest backup for simple rollback command.
        (root / '.memeflow-backups' / 'token-flow-continuous-v1.latest').write_text(str(backup), encoding='utf-8')

        print('INSTALLATION VERIFICATION: PASS')
        print('Backup:', backup)
        print('No restart is required for static UI files; refresh the Token Flow page.')
    except Exception as exc:
        print('INSTALL FAILED:', exc)
        print('Rolling back...')
        shutil.copy2(backup / 'system-tokens.js', js_path)
        shutil.copy2(backup / 'system-tokens.html', html_path)
        pre = (backup / '.css_preexisted').read_text(encoding='utf-8').strip() == '1'
        if pre and (backup / 'memeflow-token-flow-continuous-v1.css').exists():
            shutil.copy2(backup / 'memeflow-token-flow-continuous-v1.css', css_path)
        elif css_path.exists():
            css_path.unlink()
        raise


if __name__ == '__main__':
    main()
