MEMEFLOW Token Flow — Continuous Scroll + Compact Sticky Search V1

WHAT CHANGES
- Removes the visible Previous / Page X of Y / Next control.
- Keeps PAGE_SIZE=20 for performance but uses state.page as a progressive chunk counter.
- Automatically reveals the next 20 rows as the user nears the bottom.
- Makes Paste Pump.fun URL or mint + Analyze one compact sticky row on mobile.
- Existing mf-stuck behavior still supplies a shadow only while the toolbar is pinned.
- Does not change Score, sorting, P&L, holders, trading, market data, InsightX or token identity logic.

INSTALL
cd ~/workspace && rm -rf /tmp/mf-tokenflow-continuous-v1 && mkdir -p /tmp/mf-tokenflow-continuous-v1 && unzip -o MEMEFLOW-TokenFlow-Continuous-Scroll-Compact-Search-v1.zip -d /tmp/mf-tokenflow-continuous-v1 && bash /tmp/mf-tokenflow-continuous-v1/MEMEFLOW-TokenFlow-Continuous-Scroll-Compact-Search-v1/install.sh

EXPECTED
INSTALLATION VERIFICATION: PASS

Then refresh Token Flow. No server restart is required because this patch changes only static JS/CSS/HTML.

ROLLBACK
bash /tmp/mf-tokenflow-continuous-v1/MEMEFLOW-TokenFlow-Continuous-Scroll-Compact-Search-v1/rollback.sh
