#!/usr/bin/env python3
from pathlib import Path
import shutil
import sys

candidates = [Path.cwd()/'memeflow-app', Path('/home/runner/workspace/memeflow-app'), Path.cwd()]
root = next((p.resolve() for p in candidates if (p/'system-tokens.js').exists()), None)
if root is None:
    raise SystemExit('ERROR: memeflow-app not found')
marker = root/'.memeflow-backups'/'token-flow-continuous-v1.latest'
if not marker.exists():
    raise SystemExit('ERROR: no Token Flow continuous v1 backup marker found')
backup = Path(marker.read_text(encoding='utf-8').strip())
if not backup.exists():
    raise SystemExit(f'ERROR: backup missing: {backup}')
shutil.copy2(backup/'system-tokens.js', root/'system-tokens.js')
shutil.copy2(backup/'system-tokens.html', root/'system-tokens.html')
css = root/'memeflow-token-flow-continuous-v1.css'
pre = (backup/'.css_preexisted').read_text(encoding='utf-8').strip() == '1'
if pre and (backup/'memeflow-token-flow-continuous-v1.css').exists():
    shutil.copy2(backup/'memeflow-token-flow-continuous-v1.css', css)
elif css.exists():
    css.unlink()
print('ROLLBACK: PASS')
print('Restored:', backup)
