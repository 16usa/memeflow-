#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1]) if len(sys.argv) > 1 else Path.cwd()
js = (root / 'system-tokens.js').read_text(encoding='utf-8')
html = (root / 'system-tokens.html').read_text(encoding='utf-8')
css = (root / 'memeflow-token-flow-continuous-v1.css').read_text(encoding='utf-8')

checks = {
    'continuous JS marker': 'MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1' in js,
    'reconcile marker': 'MEMEFLOW_TOKEN_FLOW_CONTINUOUS_COMPACT_V1_RECONCILE' in js,
    'scroll runtime': 'let __mfContinuousScrollRafV1' in js,
    'progressive visible prefix': 'Math.min(rows.length, state.page * PAGE_SIZE)' in js,
    'compact reconcile prefix': 'Math.min(rows.length,state.page*PAGE_SIZE)' in js,
    'CSS asset linked': 'memeflow-token-flow-continuous-v1.css' in html,
    'pagination hidden': 'body.mf-page-system-tokens .pagination' in css and 'display: none !important' in css,
    'toolbar two columns': 'grid-template-columns: minmax(0, 1fr) auto !important' in css,
    'toolbar sticky': 'position: sticky !important' in css,
    'analyze compact': '#refreshButton' in css and 'height: 36px !important' in css,
}

failed = [name for name, ok in checks.items() if not ok]
for name, ok in checks.items():
    print(('PASS' if ok else 'FAIL') + ': ' + name)
if failed:
    raise SystemExit('Verification failed: ' + ', '.join(failed))
print('Token Flow continuous scroll + compact sticky search v1 ok')
