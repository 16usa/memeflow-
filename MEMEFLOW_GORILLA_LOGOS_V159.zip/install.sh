#!/usr/bin/env bash
set -euo pipefail

APP="memeflow-app"
PATCH_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ ! -d "$APP" ]; then
  echo "ERROR: memeflow-app not found. Run this from the existing Replit project root."
  exit 1
fi

for file in \
  "$PATCH_DIR/assets/memeflow-gorilla-dark.png" \
  "$PATCH_DIR/assets/memeflow-gorilla-light.png"
do
  if [ ! -f "$file" ]; then
    echo "ERROR: missing patch asset: $file"
    exit 1
  fi
done

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$APP/.v159-gorilla-logo-backup-$STAMP"
mkdir -p "$BACKUP"

for file in \
  memeflow-brand.css \
  system.html \
  system-tokens.html \
  trading.html \
  smart-vault.html \
  settings.html \
  how-it-works.html \
  agent-performance.html
do
  if [ -f "$APP/$file" ]; then
    cp "$APP/$file" "$BACKUP/$file"
  fi
done

mkdir -p "$APP/brand"

if [ -f "$APP/brand/memeflow-gorilla-dark.png" ]; then
  cp "$APP/brand/memeflow-gorilla-dark.png" "$BACKUP/memeflow-gorilla-dark.png"
fi

if [ -f "$APP/brand/memeflow-gorilla-light.png" ]; then
  cp "$APP/brand/memeflow-gorilla-light.png" "$BACKUP/memeflow-gorilla-light.png"
fi

cp "$PATCH_DIR/assets/memeflow-gorilla-dark.png" \
   "$APP/brand/memeflow-gorilla-dark.png"

cp "$PATCH_DIR/assets/memeflow-gorilla-light.png" \
   "$APP/brand/memeflow-gorilla-light.png"

python3 - <<'PY'
from pathlib import Path
import re

app = Path("memeflow-app")
brand = app / "memeflow-brand.css"

if not brand.exists():
    raise SystemExit("ERROR: memeflow-brand.css not found")

css = brand.read_text(encoding="utf-8")

css, n_dark = re.subn(
    r'--mf-logo-dark\s*:\s*url\("[^"]+"\)\s*;',
    '--mf-logo-dark:url("/brand/memeflow-gorilla-dark.png?v=gorilla-pair-v159");',
    css,
    count=1
)

css, n_light = re.subn(
    r'--mf-logo-light\s*:\s*url\("[^"]+"\)\s*;',
    '--mf-logo-light:url("/brand/memeflow-gorilla-light.png?v=gorilla-pair-v159");',
    css,
    count=1
)

if n_dark != 1 or n_light != 1:
    raise SystemExit(
        f"ERROR: canonical logo tokens not found correctly "
        f"(dark={n_dark}, light={n_light})"
    )

css = re.sub(
    r'/\*\s*MEMEFLOW_DARK_GORILLA_LOGO_V158\s*\*/.*?'
    r'/\*\s*/MEMEFLOW_DARK_GORILLA_LOGO_V158\s*\*/\s*',
    '',
    css,
    flags=re.S
)

start = "/* MEMEFLOW_THEME_GORILLA_LOGOS_V159 */"
end = "/* /MEMEFLOW_THEME_GORILLA_LOGOS_V159 */"

block = r"""
/* MEMEFLOW_THEME_GORILLA_LOGOS_V159
   Dark theme  -> supplied white gorilla.
   Light theme -> supplied dark gorilla.
   Header geometry/layout is unchanged.
*/
html[data-theme="dark"] .logo {
  background-image: url("/brand/memeflow-gorilla-dark.png?v=gorilla-pair-v159") !important;
}

html[data-theme="light"] .logo {
  background-image: url("/brand/memeflow-gorilla-light.png?v=gorilla-pair-v159") !important;
}

html[data-theme="dark"] .mf-brand-img,
html[data-theme="dark"] .mf-site-header :is(
  .brand-mark img,
  .mf-settings-page-brand-mark img,
  .mf-vault-brand-mark img,
  .mf-hiw-brand-mark img
) {
  content: url("/brand/memeflow-gorilla-dark.png?v=gorilla-pair-v159") !important;
  object-fit: contain !important;
  filter: none !important;
}

html[data-theme="light"] .mf-brand-img,
html[data-theme="light"] .mf-site-header :is(
  .brand-mark img,
  .mf-settings-page-brand-mark img,
  .mf-vault-brand-mark img,
  .mf-hiw-brand-mark img
) {
  content: url("/brand/memeflow-gorilla-light.png?v=gorilla-pair-v159") !important;
  object-fit: contain !important;
  filter: none !important;
}
/* /MEMEFLOW_THEME_GORILLA_LOGOS_V159 */
""".strip()

if start in css and end in css:
    css = re.sub(
        re.escape(start) + r".*?" + re.escape(end),
        block,
        css,
        flags=re.S
    )
else:
    css = css.rstrip() + "\n\n" + block + "\n"

brand.write_text(css, encoding="utf-8")

pages = [
    "system.html",
    "system-tokens.html",
    "trading.html",
    "smart-vault.html",
    "settings.html",
    "how-it-works.html",
    "agent-performance.html",
]

patched = []

for name in pages:
    p = app / name
    if not p.exists():
        continue

    html = p.read_text(encoding="utf-8")
    before = html

    html = re.sub(
        r'/brand/(?:memeflow-dragonfly-dark|memeflow-gorilla-dark)\.png\?v=[^"]+',
        '/brand/memeflow-gorilla-dark.png?v=gorilla-pair-v159',
        html
    )

    html = re.sub(
        r'/memeflow-brand\.css\?v=[^"]+',
        '/memeflow-brand.css?v=gorilla-pair-v159-20260919',
        html
    )

    if html != before:
        p.write_text(html, encoding="utf-8")
        patched.append(name)

dark = app / "brand" / "memeflow-gorilla-dark.png"
light = app / "brand" / "memeflow-gorilla-light.png"
final_css = brand.read_text(encoding="utf-8")

checks = {
    "dark gorilla asset installed":
        dark.exists() and dark.stat().st_size > 1000,
    "light gorilla asset installed":
        light.exists() and light.stat().st_size > 1000,
    "dark theme points to white gorilla":
        '/brand/memeflow-gorilla-dark.png?v=gorilla-pair-v159' in final_css,
    "light theme points to dark gorilla":
        '/brand/memeflow-gorilla-light.png?v=gorilla-pair-v159' in final_css,
    "V159 theme override installed":
        "MEMEFLOW_THEME_GORILLA_LOGOS_V159" in final_css,
    "old V158 override removed":
        "MEMEFLOW_DARK_GORILLA_LOGO_V158" not in final_css,
    "main pages updated":
        len(patched) >= 7,
}

failed = [name for name, ok in checks.items() if not ok]

for name, ok in checks.items():
    print(("PASS" if ok else "FAIL") + ": " + name)

if failed:
    raise SystemExit("FAILED: " + ", ".join(failed))

print("")
print("V159 READY")
print("Dark background -> white gorilla")
print("Light background -> dark gorilla")
print("Header geometry unchanged")
print("No server restart performed")
print("Patched pages:", ", ".join(patched))
PY

echo ""
echo "PASS: MEMEFLOW Gorilla Logo Pair V159 installed"
echo "PASS: no server restart performed"
echo "Backup directory: $BACKUP"
