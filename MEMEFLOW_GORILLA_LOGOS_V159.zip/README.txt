MEMEFLOW Gorilla Logo Pair V159

Dark theme:
- supplied white gorilla logo

Light theme:
- supplied dark gorilla logo

Also:
- preserves header geometry/layout
- updates all main MEMEFLOW pages
- removes the older V158 one-sided override if present
- performs no server restart
