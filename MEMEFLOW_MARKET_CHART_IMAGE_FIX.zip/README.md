# MEMEFLOW Market Chart — Image & Render Fix

This update:
- reads the token image from the selected candidate object and DOM fallbacks;
- shows initials only when no image exists;
- makes candles more visible;
- prevents negative price-axis values;
- separates LIVE/current-price labels from the axis;
- gives the token title more usable width.

Apply in Replit:

```bash
unzip -o MEMEFLOW_MARKET_CHART_IMAGE_FIX.zip
node scripts/install-market-chart-image-fix.mjs
```

Then use **Stop → Run**.

Rollback:

```bash
cp memeflow-app/market-chart-final.js.before-image-render-fix memeflow-app/market-chart-final.js
```
