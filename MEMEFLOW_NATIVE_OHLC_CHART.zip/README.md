# MEMEFLOW Native OHLC Candlestick Chart

This is the clean replacement for the experimental chart patches.

It uses the existing live price already rendered by MEMEFLOW, samples it once per second, stores token-specific history in the browser, and creates real OHLC candles for:

- 1 second
- 1 minute
- 5 minutes
- 15 minutes
- 1 hour
- All history

No extra backend market request is added.

## Apply in Replit

Upload the ZIP to the repository root and run:

```bash
unzip -o MEMEFLOW_NATIVE_OHLC_CHART.zip
node scripts/native-ohlc-chart.mjs
```

Then press **Stop → Run**.

## Important

The first candle appears immediately after the first valid price sample. Meaningful candle bodies appear as the live price changes. Longer intervals need time to accumulate their own history.

## Rollback

```bash
cp memeflow-app/index.html.before-native-ohlc-chart memeflow-app/index.html
```
