MEMEFLOW_WS_FIRST_PREOPEN_RPC_V1

1. Upload install_memeflow_ws_first_preopen_rpc_v1.sh into the root of your Replit project.
2. Open Shell.
3. Run:

chmod +x install_memeflow_ws_first_preopen_rpc_v1.sh
./install_memeflow_ws_first_preopen_rpc_v1.sh

The installer checks the expected files, refuses to overwrite dirty target files, applies the patch, runs syntax/tests, commits, and pushes the current branch.

After successful installation, restart the backend/deployment.
