#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const cwd = process.cwd();
const BS = "<!-- MEMEFLOW_VISION_2026_V2_STYLE_BEGIN -->";
const ES = "<!-- MEMEFLOW_VISION_2026_V2_STYLE_END -->";
const BJ = "<!-- MEMEFLOW_VISION_2026_V2_SCRIPT_BEGIN -->";
const EJ = "<!-- MEMEFLOW_VISION_2026_V2_SCRIPT_END -->";

function exists(p){try{return fs.existsSync(p)}catch{return false}}
function esc(x){return x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}

function locateTarget(){
  const c=[
    path.join(cwd,"memeflow-app","index.html"),
    path.join(cwd,"index.html"),
    path.resolve(here,"..","memeflow-app","index.html"),
    path.resolve(here,"..","index.html")
  ];
  for(const p of [...new Set(c)]) if(exists(p)){
    const s=fs.readFileSync(p,"utf8");
    if(s.includes(BS)||s.includes(BJ)||(
      s.includes('id="contextBanner"')&&s.includes('id="primaryState"')
    )) return p;
  }
  throw new Error("MEMEFLOW index.html was not found.");
}

const target=locateTarget();
let html=fs.readFileSync(target,"utf8");
html=html
  .replace(new RegExp("\\s*"+esc(BS)+"[\\s\\S]*?"+esc(ES),"g"),"")
  .replace(new RegExp("\\s*"+esc(BJ)+"[\\s\\S]*?"+esc(EJ),"g"),"");

fs.writeFileSync(target,html,"utf8");

console.log("");
console.log("✓ MEMEFLOW VISION 2026 V2 removed from:",target);
console.log("✓ Only this patch's inline STYLE and SCRIPT blocks were removed.");
console.log("✓ Restart Replit Run and refresh the browser.");
console.log("");