#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const cwd = process.cwd();

const BEGIN_STYLE = "<!-- MEMEFLOW_VISION_2026_V2_STYLE_BEGIN -->";
const END_STYLE   = "<!-- MEMEFLOW_VISION_2026_V2_STYLE_END -->";
const BEGIN_SCRIPT= "<!-- MEMEFLOW_VISION_2026_V2_SCRIPT_BEGIN -->";
const END_SCRIPT  = "<!-- MEMEFLOW_VISION_2026_V2_SCRIPT_END -->";

const css = fs.readFileSync(path.join(here, "vision-2026.css"), "utf8");
const js  = fs.readFileSync(path.join(here, "vision-2026.js"), "utf8");

function sha(s){ return crypto.createHash("sha256").update(s).digest("hex"); }
function exists(p){ try{return fs.existsSync(p)}catch{return false} }

function locateTarget(){
  const candidates = [
    path.join(cwd, "memeflow-app", "index.html"),
    path.join(cwd, "index.html"),
    path.resolve(here, "..", "memeflow-app", "index.html"),
    path.resolve(here, "..", "index.html")
  ];
  for(const p of [...new Set(candidates)]){
    if(!exists(p)) continue;
    const s = fs.readFileSync(p,"utf8");
    if(
      s.includes('id="contextBanner"') &&
      s.includes('id="primaryState"') &&
      s.includes('id="executionPreview"') &&
      s.includes('class="mobile-nav"')
    ) return p;
  }
  throw new Error(
    "Active MEMEFLOW index.html was not found. Expected the page containing " +
    "contextBanner, primaryState, executionPreview and mobile-nav."
  );
}

function stripCurrent(s){
  const esc = x => x.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  s = s.replace(new RegExp("\\s*"+esc(BEGIN_STYLE)+"[\\s\\S]*?"+esc(END_STYLE),"g"),"");
  s = s.replace(new RegExp("\\s*"+esc(BEGIN_SCRIPT)+"[\\s\\S]*?"+esc(END_SCRIPT),"g"),"");
  return s;
}

const target = locateTarget();
let html = fs.readFileSync(target,"utf8");
if(!html.includes("</head>") || !html.includes("</body>")) {
  throw new Error("Unexpected HTML structure. No changes were made.");
}

const stateDir = path.join(path.dirname(target), ".memeflow-patches", "vision-2026-v2");
fs.mkdirSync(stateDir,{recursive:true});
const backup = path.join(stateDir, "index.before-vision-2026-v2.html");
if(!exists(backup)) fs.copyFileSync(target,backup);

html = stripCurrent(html);

const styleBlock = `${BEGIN_STYLE}
<style id="memeflow-vision-2026-v2">
${css}
</style>
${END_STYLE}`;

const scriptBlock = `${BEGIN_SCRIPT}
<script id="memeflow-vision-2026-v2-script">
${js}
</script>
${END_SCRIPT}`;

html = html.replace("</head>", `${styleBlock}\n</head>`);
html = html.replace("</body>", `${scriptBlock}\n</body>`);
fs.writeFileSync(target,html,"utf8");

const checks = {
  target,
  styleInjected:html.includes('id="memeflow-vision-2026-v2"'),
  scriptInjected:html.includes('id="memeflow-vision-2026-v2-script"'),
  activeAppSignature:
    html.includes('id="contextBanner"') &&
    html.includes('id="primaryState"') &&
    html.includes('id="executionPreview"'),
  sha256:sha(html),
  bytes:Buffer.byteLength(html)
};

fs.writeFileSync(path.join(stateDir,"install.json"), JSON.stringify({
  installedAt:new Date().toISOString(),
  ...checks,
  rollbackBackup:backup
},null,2)+"\n");

if(!checks.styleInjected || !checks.scriptInjected || !checks.activeAppSignature)
  throw new Error("Post-install verification failed.");

console.log("");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log(" MEMEFLOW VISION 2026 V2 — INSTALLED");
console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
console.log("Target:", target);
console.log("Inline CSS:", checks.styleInjected ? "OK" : "FAILED");
console.log("Inline JS :", checks.scriptInjected ? "OK" : "FAILED");
console.log("Page match:", checks.activeAppSignature ? "OK" : "FAILED");
console.log("Bytes:", checks.bytes);
console.log("");
console.log("This V2 is INLINE inside the ACTIVE index.html.");
console.log("It does not depend on an external CSS path.");
console.log("");
console.log("Restart Run in Replit, then hard refresh Safari.");
console.log("Temporary old-view check: add ?mfvision=off to the URL.");
console.log(`Rollback: node "${path.join(here,"revert.mjs")}"`);
console.log("");