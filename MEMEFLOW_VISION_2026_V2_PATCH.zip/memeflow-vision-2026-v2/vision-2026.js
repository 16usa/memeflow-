(() => {
  "use strict";

  const ROOT = document.documentElement;
  const CLASS = "mf-vision-2026";
  const MOBILE = matchMedia("(max-width: 820px)");
  const OFF = new URLSearchParams(location.search).get("mfvision") === "off";
  const anchors = new Map();
  const original = new WeakMap();
  let metricObserver = null;
  let nameObserver = null;

  const $ = (s, r=document) => r.querySelector(s);
  const $$ = (s, r=document) => [...r.querySelectorAll(s)];

  function remember(node, key, value) {
    if (!node) return;
    let data = original.get(node);
    if (!data) { data = {}; original.set(node, data); }
    if (!(key in data)) data[key] = value;
  }

  function markerFor(node) {
    if (!node?.id) return null;
    if (anchors.has(node.id)) return anchors.get(node.id);
    const marker = document.createComment(`mf-vision-anchor:${node.id}`);
    node.parentNode?.insertBefore(marker, node);
    anchors.set(node.id, marker);
    return marker;
  }

  function move(node, parent, before=null) {
    if (!node || !parent) return;
    markerFor(node);
    parent.insertBefore(node, before);
  }

  function restoreMoved() {
    for (const [id, marker] of anchors.entries()) {
      const node = document.getElementById(id);
      if (node && marker?.parentNode) marker.parentNode.insertBefore(node, marker.nextSibling);
    }
  }

  function walletIcon() {
    const a = $("#walletConnectTop");
    if (!a || a.classList.contains("mf-vision-wallet")) return;
    remember(a, "html", a.innerHTML);
    remember(a, "aria", a.getAttribute("aria-label"));
    a.classList.add("mf-vision-wallet");
    a.setAttribute("aria-label", "Wallet");
    a.setAttribute("title", "Wallet");
    a.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" aria-hidden="true"
        stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round">
        <path d="M4.2 6.7A2.7 2.7 0 0 1 6.9 4h9.8a2.7 2.7 0 0 1 2.7 2.7v10.6a2.7 2.7 0 0 1-2.7 2.7H6.9a2.7 2.7 0 0 1-2.7-2.7V6.7Z"/>
        <path d="M4.5 8.2h12.2a2.7 2.7 0 0 1 2.7 2.7v4.2a2.7 2.7 0 0 1-2.7 2.7H4.5"/>
        <path d="M15.2 11.3h4.2v3.4h-4.2a1.7 1.7 0 1 1 0-3.4Z"/>
        <circle cx="15.6" cy="13" r=".55" fill="currentColor" stroke="none"/>
      </svg>`;
    a.addEventListener("click", (e) => {
      if (!MOBILE.matches || !ROOT.classList.contains(CLASS)) return;
      e.preventDefault();
      e.stopPropagation();
      openSheet("wallet");
    }, true);
  }

  function addRadar() {
    const hero = $("#contextBanner");
    if (!hero || $(".mf-radar", hero)) return;
    const radar = document.createElement("div");
    radar.className = "mf-radar mf-vision-only";
    radar.setAttribute("aria-hidden", "true");
    radar.innerHTML = `
      <i class="mf-radar-ring" style="--s:104px"></i>
      <i class="mf-radar-ring" style="--s:74px"></i>
      <i class="mf-radar-ring" style="--s:46px"></i>
      <i class="mf-radar-core"></i>`;
    hero.appendChild(radar);
  }

  function addTokenAvatar() {
    const head = $(".primary-card .token-head");
    if (!head || $(".mf-token-avatar", head)) return;
    const av = document.createElement("div");
    av.className = "mf-token-avatar mf-vision-only";
    av.setAttribute("aria-hidden", "true");
    head.prepend(av);
    updateTokenAvatar();

    const name = $("#primaryName");
    if (name && !nameObserver) {
      nameObserver = new MutationObserver(updateTokenAvatar);
      nameObserver.observe(name, {childList:true, subtree:true, characterData:true});
    }
  }

  function updateTokenAvatar() {
    const av = $(".mf-token-avatar");
    const text = ($("#primaryName")?.textContent || "M").trim();
    const clean = text.replace(/[^A-Za-z0-9]/g, "");
    av && (av.textContent = (clean[0] || "M").toUpperCase());
  }

  function isEmptyMetric(text) {
    const v = String(text || "").replace(/\s+/g, " ").trim().toLowerCase();
    return !v || ["—","-","n/a","na","unknown","pending","waiting"].includes(v);
  }

  function updateMetrics() {
    const card = $(".primary-card");
    if (!card) return;
    const ids = ["primaryConfidence","primaryRisk","primaryRR"];
    let empty = 0;
    for (const id of ids) {
      const value = document.getElementById(id);
      const metric = value?.closest(".metric");
      if (!value || !metric) continue;
      const e = isEmptyMetric(value.textContent);
      metric.classList.toggle("mf-empty-metric", e);
      if (e) empty++;
    }
    card.classList.toggle("mf-all-empty-metrics", empty === ids.length);
  }

  function watchMetrics() {
    if (metricObserver) return;
    const nodes = ["primaryConfidence","primaryRisk","primaryRR"]
      .map(id => document.getElementById(id)).filter(Boolean);
    if (!nodes.length) return;
    metricObserver = new MutationObserver(updateMetrics);
    nodes.forEach(n => metricObserver.observe(n,{childList:true,subtree:true,characterData:true}));
    updateMetrics();
  }

  function openSheet(name) {
    $$(".mobile-sheet.open").forEach(s => s.classList.remove("open"));
    const target = document.getElementById(`sheet-${name}`);
    if (target) target.classList.add("open");
    $$(".mobile-nav button").forEach(b => b.classList.toggle("active", b.dataset.mfVisionSheet === name || b.dataset.sheet === name));
  }

  const icons = {
    home:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 10.5 12 3.7l8.5 6.8v9.2H14v-5.8h-4v5.8H3.5v-9.2Z"/></svg>`,
    candidates:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round"><circle cx="10.5" cy="10.5" r="6.5"/><path d="m15.5 15.5 5 5"/></svg>`,
    ai:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.8c.65 4.25 2.95 6.55 7.2 7.2-4.25.65-6.55 2.95-7.2 7.2-.65-4.25-2.95-6.55-7.2-7.2 4.25-.65 6.55-2.95 7.2-7.2Z"/><path d="M19 15.2c.3 1.9 1.3 2.9 3.2 3.2-1.9.3-2.9 1.3-3.2 3.2-.3-1.9-1.3-2.9-3.2-3.2 1.9-.3 2.9-1.3 3.2-3.2Z"/></svg>`,
    positions:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 8.5h16v11H4z"/><path d="M8.5 8.5V6.2A2.2 2.2 0 0 1 10.7 4h2.6a2.2 2.2 0 0 1 2.2 2.2v2.3"/><path d="M4 13h16"/></svg>`,
    more:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.7"><circle cx="7" cy="7" r="1.6"/><circle cx="17" cy="7" r="1.6"/><circle cx="7" cy="17" r="1.6"/><circle cx="17" cy="17" r="1.6"/></svg>`
  };

  function setNavButton(btn, icon, label, cls="") {
    if (!btn) return;
    if (!btn.dataset.mfVisionOriginal) {
      btn.dataset.mfVisionOriginal = btn.innerHTML;
      btn.dataset.mfVisionOriginalSheet = btn.dataset.sheet || "";
    }
    btn.className = cls + (btn.classList.contains("active") ? " active" : "");
    btn.innerHTML = `${icons[icon]}<span>${label}</span>`;
  }

  function redesignNav() {
    const nav = $(".mobile-nav");
    if (!nav || nav.dataset.mfVisionReady) return;
    const b = $$("button", nav);
    if (b.length < 5) return;

    setNavButton(b[0],"home","Home");
    setNavButton(b[1],"candidates","Candidates");

    setNavButton(b[2],"ai","MEMEFLOW AI","mf-ai-nav");
    b[2].dataset.mfVisionSheet = "inspector";
    b[2].dataset.sheet = "inspector";

    setNavButton(b[3],"positions","Positions","mf-positions-nav");
    b[3].dataset.mfVisionSheet = "positions";
    b[3].dataset.sheet = "positions";

    setNavButton(b[4],"more","More");
    b[4].dataset.mfVisionSheet = "more";

    b[2].addEventListener("click", e => {
      if (!ROOT.classList.contains(CLASS)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      openSheet("inspector");
    }, true);

    b[3].addEventListener("click", e => {
      if (!ROOT.classList.contains(CLASS)) return;
      e.preventDefault(); e.stopImmediatePropagation();
      openSheet("positions");
    }, true);

    nav.dataset.mfVisionReady = "1";
  }

  function addPrimaryActions() {
    const card = $(".primary-card");
    if (!card || $(".mf-primary-actions", card)) return;
    const box = document.createElement("div");
    box.className = "mf-primary-actions mf-vision-only";
    box.innerHTML = `
      <button type="button" class="mf-review-trade">↗&nbsp; Review trade</button>
      <button type="button" class="btn mf-view-analysis">▤&nbsp; View analysis</button>`;
    card.appendChild(box);

    $(".mf-review-trade", box).addEventListener("click", () => {
      $("#executionPreview")?.scrollIntoView({behavior:"smooth", block:"start"});
    });
    $(".mf-view-analysis", box).addEventListener("click", () => {
      if (MOBILE.matches) openSheet("inspector");
      else $("#decision-studio")?.scrollIntoView({behavior:"smooth",block:"start"});
    });
  }

  function addExecutionToggle() {
    const ex = $("#executionPreview");
    if (!ex || $(".mf-view-checks", ex)) return;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "mf-view-checks mf-vision-only";
    btn.textContent = "View all checks";
    const readiness = $(".execution-readiness", ex);
    ex.insertBefore(btn, readiness || null);
    btn.addEventListener("click", () => {
      const expanded = ex.classList.toggle("mf-expanded");
      btn.textContent = expanded ? "Hide detailed checks" : "View all checks";
    });
  }

  function findManualScan() {
    const main = $(".main");
    if (!main) return null;
    return $$("section,article", main).find(el => {
      if (el.id === "settings" || el.id === "billing" || el.id === "system") return false;
      const t = (el.textContent || "").replace(/\s+/g," ");
      return /Analyze any Solana token|MANUAL AI SCAN/i.test(t) && !!$("input", el);
    }) || null;
  }

  function ensureMoreContainer() {
    const sheet = $("#sheet-more");
    if (!sheet) return null;

    let jump = $(".mf-more-jumpbar", sheet);
    if (!jump) {
      jump = document.createElement("div");
      jump.className = "mf-more-jumpbar mf-vision-only";
      jump.innerHTML = `
        <button type="button" data-jump="wallet">Wallet</button>
        <button type="button" data-jump="system">System</button>
        <button type="button" data-jump="billing">Plan & billing</button>
        <button type="button" data-jump="settings">AI settings</button>`;
      const grid = $(":scope > .grid", sheet);
      if (grid) grid.after(jump); else $(".sheet-top",sheet)?.after(jump);

      jump.addEventListener("click", e => {
        const btn = e.target.closest("[data-jump]");
        if (!btn) return;
        const id = btn.dataset.jump;
        if (id === "wallet") return openSheet("wallet");
        document.getElementById(id)?.scrollIntoView({behavior:"smooth", block:"start"});
      });
    }

    let container = $(".mf-more-sections", sheet);
    if (!container) {
      container = document.createElement("div");
      container.className = "mf-more-sections";
      sheet.appendChild(container);
    }
    return container;
  }

  function mobileStructure() {
    if (!ROOT.classList.contains(CLASS) || !MOBILE.matches) return restoreMoved();

    const top = $(".topbar");
    const status = $("#connectionStrip");
    const hero = $("#contextBanner");
    const primary = $("#primaryState")?.closest(".panel");
    const execution = $("#executionPreview");

    if (primary) primary.classList.add("mf-primary-panel");

    if (top && status && top.nextElementSibling !== status) move(status, top.parentNode, top.nextSibling);
    if (hero && primary && hero.nextElementSibling !== primary) move(primary, hero.parentNode, hero.nextSibling);
    if (primary && execution && primary.nextElementSibling !== execution) move(execution, primary.parentNode, primary.nextSibling);

    const more = ensureMoreContainer();
    if (more) {
      const manual = findManualScan();
      if (manual && !manual.id) manual.id = "mf-manual-scan-source";
      if (manual) manual.classList.add("mf-manual-scan-source");
      [manual, $("#system"), $("#billing"), $("#settings")].filter(Boolean).forEach(n => move(n, more));
    }
  }

  function enable() {
    ROOT.classList.add(CLASS);
    ROOT.dataset.mfVision = "2026-v2";
    walletIcon();
    addRadar();
    addTokenAvatar();
    addPrimaryActions();
    addExecutionToggle();
    watchMetrics();
    redesignNav();
    mobileStructure();
  }

  function disable() {
    ROOT.classList.remove(CLASS);
    ROOT.dataset.mfVision = "off";
    restoreMoved();
  }

  window.MEMEFLOW_VISION_2026 = Object.freeze({
    enable,
    disable,
    status:() => ROOT.classList.contains(CLASS) ? "2026-v2" : "off"
  });

  function boot() {
    if (OFF) disable(); else enable();
    if (typeof MOBILE.addEventListener === "function") MOBILE.addEventListener("change", mobileStructure);
    else if (typeof MOBILE.addListener === "function") MOBILE.addListener(mobileStructure);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, {once:true});
  else boot();
})();