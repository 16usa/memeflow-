# MEMEFLOW VISION 2026 V2

Это уже не «лёгкий CSS-патч». V2 делает сильную перестройку мобильного Home под
референс-макет: компактная шапка, двухстрочный status strip, крупный mission hero с
AI-radar, центральная карточка Primary Candidate, компактный Pre-trade блок и новый
bottom dock с центральной MEMEFLOW AI кнопкой.

## Почему этот патч должен реально проявиться

V2 не подключает внешний CSS-файл к сайту. Installer берёт весь CSS + JS и вставляет
их **INLINE прямо в активный `memeflow-app/index.html`** после существующих стилей.
Так старые CSS-слои не могут просто оказаться «ниже» него, а отдельный static path не
может не загрузиться.

Installer также проверяет сигнатуры именно активной страницы:
`contextBanner`, `primaryState`, `executionPreview`, `mobile-nav`.

## Установка в Replit

Распакуй ZIP и загрузи папку `memeflow-vision-2026-v2` в корень проекта.

В Shell:

```bash
node memeflow-vision-2026-v2/install.mjs
```

После сообщения `INSTALLED`:

1. Stop / Run в Replit.
2. На iPhone обнови страницу. Если Safari держит старый документ — закрой вкладку и
   открой URL заново.

Проверка:

```bash
node memeflow-vision-2026-v2/verify.mjs
```

Должно быть:

```json
{
  "activePage": true,
  "visionStyle": true,
  "visionScript": true
}
```

## Быстро посмотреть старый вид без удаления

Добавь:

```text
?mfvision=off
```

## Полный откат этого патча

```bash
node memeflow-vision-2026-v2/revert.mjs
```

Откат удаляет только два блока V2 — inline CSS и inline JS. Торговую логику,
API, evaluator, wallet logic, billing, server settings и данные он не трогает.

## Что меняется на мобильном

- Header: PAPER MODE / FREE PLAN + чистая wallet icon.
- Connection strip: только Wallet + RPC.
- Mission hero: значительно крупнее и визуально ближе к макету.
- Добавляется декоративный AI radar (CSS, без тяжёлой картинки).
- Primary Candidate становится главным блоком.
- Пустые Confidence / Risk / Expected RR скрываются.
- Momentum превращается в отдельный green/cyan strip.
- Добавляются Review trade / View analysis как UI-навигация к существующим секциям.
- Pre-trade сворачивается до summary + readiness; `View all checks` раскрывает детали.
- Billing / System / Settings (и Manual Scan, если найден) переносятся в More.
- Нижняя навигация: Home / Candidates / MEMEFLOW AI / Positions / More.
- Wallet остаётся доступен через иконку в шапке и More.

## Важно

Патч не подменяет торговое решение и не рисует фальшивые live-метрики.
Он использует существующие DOM-узлы и ID, которые продолжает обновлять текущая логика.