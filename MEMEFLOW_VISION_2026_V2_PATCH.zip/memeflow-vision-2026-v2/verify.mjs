#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";
const cwd=process.cwd();
const candidates=[path.join(cwd,"memeflow-app","index.html"),path.join(cwd,"index.html")];
const target=candidates.find(p=>fs.existsSync(p));
if(!target) throw new Error("index.html not found");
const s=fs.readFileSync(target,"utf8");
const out={
  target,
  activePage:s.includes('id="contextBanner"')&&s.includes('id="primaryState"'),
  visionStyle:s.includes('id="memeflow-vision-2026-v2"'),
  visionScript:s.includes('id="memeflow-vision-2026-v2-script"'),
  bytes:Buffer.byteLength(s)
};
console.log(JSON.stringify(out,null,2));
if(!out.activePage||!out.visionStyle||!out.visionScript) process.exitCode=1;