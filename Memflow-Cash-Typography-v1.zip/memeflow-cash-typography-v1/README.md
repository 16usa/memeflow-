# Memflow Cash-style typography v1

Visual typography pass based on the supplied iPhone/Cash App screenshots.

- Native Apple system font stack on iPhone/iPad (`-apple-system`), no font files bundled.
- Larger clean role scale.
- Dark mode text: white / iOS neutral gray hierarchy.
- Light mode keeps an appropriate dark neutral hierarchy.
- Semantic colors (green/red/yellow/blue status text) remain owned by existing Memflow rules.
- No trading/data/backend logic changes.
