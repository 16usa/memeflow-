from pathlib import Path
import shutil

ROOT = Path('memeflow-app')
CSS_NAME = 'memeflow-cash-typography-v1.css'
SOURCE = Path('/tmp/memeflow-cash-typography-v1/memeflow-cash-typography-v1') / CSS_NAME
TARGET = ROOT / CSS_NAME
BACKUP_DIR = ROOT / '.cash-typography-v1-backup'

pages = [
    'index.html','system.html','system-tokens.html','trading.html','settings.html',
    'smart-vault.html','how-it-works.html','agent-performance.html',
    'owner-intelligence.html','x100.html','system-source.html'
]

if not ROOT.exists():
    raise SystemExit('Run this from the Memflow repository root; memeflow-app/ was not found.')

BACKUP_DIR.mkdir(exist_ok=True)
if not TARGET.exists():
    shutil.copy2(SOURCE, TARGET)
else:
    if not (BACKUP_DIR / CSS_NAME).exists():
        shutil.copy2(TARGET, BACKUP_DIR / CSS_NAME)
    shutil.copy2(SOURCE, TARGET)

link = '<link rel="stylesheet" href="/memeflow-cash-typography-v1.css?v=cash-typography-v1">'
for name in pages:
    p = ROOT / name
    if not p.exists():
        continue
    b = BACKUP_DIR / name
    if not b.exists():
        shutil.copy2(p, b)
    text = p.read_text(encoding='utf-8')
    # Remove a previous copy if the installer is re-run.
    lines = [line for line in text.splitlines() if 'memeflow-cash-typography-v1.css' not in line]
    text = '\n'.join(lines)
    if '</head>' not in text:
        raise SystemExit(f'Cannot find </head> in {p}')
    text = text.replace('</head>', f'  {link}\n</head>', 1)
    p.write_text(text + ('\n' if not text.endswith('\n') else ''), encoding='utf-8')
    print(f'patched {p}')

print('Cash-style typography asset installed.')
