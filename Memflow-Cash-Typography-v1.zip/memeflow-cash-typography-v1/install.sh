#!/usr/bin/env bash
set -euo pipefail

echo 'Installing Memflow Cash-style typography v1...'
python3 /tmp/memeflow-cash-typography-v1/memeflow-cash-typography-v1/apply_patch.py

set -x
node --check memeflow-app/memeflow-theme.js
node --check memeflow-app/memeflow-nav.js
git diff --check
set +x

echo
printf 'Typography patch checks passed.\n'
printf 'No server restart was performed.\n'

set -x
git add memeflow-app/memeflow-cash-typography-v1.css \
  memeflow-app/index.html memeflow-app/system.html memeflow-app/system-tokens.html \
  memeflow-app/trading.html memeflow-app/settings.html memeflow-app/smart-vault.html \
  memeflow-app/how-it-works.html memeflow-app/agent-performance.html \
  memeflow-app/owner-intelligence.html memeflow-app/x100.html memeflow-app/system-source.html 2>/dev/null || true
if ! git diff --cached --quiet; then
  git commit -m "Memflow: Cash-style typography and text hierarchy"
  git push
else
  echo 'No git changes to commit.'
fi
set +x

echo
printf 'Done. Restart the app manually from Replit when ready.\n'
