#!/usr/bin/env bash
set -euo pipefail
BACKUP='memeflow-app/.cash-typography-v1-backup'
if [ ! -d "$BACKUP" ]; then
  echo "Backup not found: $BACKUP"
  exit 1
fi
for f in index.html system.html system-tokens.html trading.html settings.html smart-vault.html how-it-works.html agent-performance.html owner-intelligence.html x100.html system-source.html; do
  if [ -f "$BACKUP/$f" ]; then cp "$BACKUP/$f" "memeflow-app/$f"; fi
done
if [ -f "$BACKUP/memeflow-cash-typography-v1.css" ]; then
  cp "$BACKUP/memeflow-cash-typography-v1.css" memeflow-app/memeflow-cash-typography-v1.css
else
  rm -f memeflow-app/memeflow-cash-typography-v1.css
fi

git add -A memeflow-app
if ! git diff --cached --quiet; then
  git commit -m "Rollback Memflow Cash-style typography"
  git push
fi

echo 'Rollback complete. Restart manually from Replit when ready.'
