# MEMEFLOW Final Isolated Market Chart

Uses Shadow DOM, so old CSS patches cannot conflict with the final chart.

Apply:

```bash
unzip -o MEMEFLOW_FINAL_ISOLATED_MARKET_CHART.zip
node scripts/install-final-market-chart.mjs
```

Then Stop → Run.

Rollback:

```bash
cp memeflow-app/index.html.before-final-shadow-chart memeflow-app/index.html
```
