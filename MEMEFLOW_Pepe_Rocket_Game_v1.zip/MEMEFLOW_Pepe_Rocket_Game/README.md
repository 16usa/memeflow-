# MEMEFLOW Pepe Rocket — PAPER GAME v1

A separate `/game` module for the existing `memeflow-app`. It is PAPER-only: no wallet signing and no real BUY/SELL is performed.

## Architecture

The game deliberately reuses the existing MEMEFLOW market pipeline instead of running a second scanner:

- Existing MEMEFLOW per-user decisions select only a current `BUY READY` candidate.
- Existing token state supplies the server-authoritative entry and live price.
- Existing `/api/chart/stream` SSE feed drives smooth browser animation.
- New `src/game-engine.mjs` owns the virtual balance, active round, multiplier, Auto Cash Out, Stop Loss, result and history on the server.
- The existing `publish(mint)` hot path gets one O(1) game hook, so Auto Cash Out / Stop Loss can settle even when the browser is not the source of truth.

## Round lifecycle

1. Player enters a paper stake and presses START.
2. Browser calls `POST /api/game/start` with one idempotency `requestId`.
3. If there is no valid `BUY READY` candidate with `priceSol`, the UI keeps searching and retries without reserving any balance.
4. When a candidate is available, the server reserves the paper stake and locks current `priceSol` as exactly `1.00×`.
5. Multiplier = latest server token `priceSol` / locked entry `priceSol`.
6. Browser subscribes to existing `/api/chart/stream?tokenAddress=<mint>` to animate the rocket immediately.
7. Server remains authoritative. It also checks the round on token publish events and `/api/game/status`.
8. Manual Cash Out, Auto Cash Out or Stop Loss settles once and credits the paper payout back to the server-side virtual balance.
9. Active PAPER sessions persist in the existing JSON store and rebuild their live-token index after a server restart.
10. Default maximum round duration is 20 minutes (`GAME_PAPER_MAX_ROUND_MS` can override it).

## New endpoints

- `GET /api/game/status`
- `POST /api/game/start`
- `POST /api/game/cashout`
- `POST /api/game/reset`
- `POST /api/game/history/clear`

## Files installed

- `memeflow-app/game.html`
- `memeflow-app/game.css`
- `memeflow-app/game.js`
- `memeflow-app/src/game-engine.mjs`

The installer also patches only these small integration points:

- adds `Game` after Mission Control in desktop navigation;
- adds `Game` to the mobile More sheet;
- maps `/game` to `game.html` in the existing static server;
- imports/creates `GameEngine`;
- adds the five `/api/game/*` routes;
- calls `game.onTokenUpdate()` from the existing `publish(mint)` path.

Before the first patch it creates:

- `index.html.before-pepe-rocket`
- `app-server.mjs.before-pepe-rocket`

The installer is marker-based and idempotent; running it twice does not duplicate the menu items/routes/hooks.

## Install

Place/extract this folder in the MEMEFLOW repository root and run:

```bash
node MEMEFLOW_Pepe_Rocket_Game/install-game.mjs
```

Then start MEMEFLOW normally (`npm start` from the workspace root) and open:

```text
/game
```

## Validation already included

`test-game-engine.mjs` validates:

- 1.50× Auto Cash Out;
- no double settlement on repeated market updates;
- Stop Loss settlement;
- persistence/recovery of an active round followed by manual Cash Out.

Run it with:

```bash
node MEMEFLOW_Pepe_Rocket_Game/test-game-engine.mjs
```

This is intentionally PAPER-only. Real-money execution should not be enabled until the game UX, server settlement behavior, slippage model, wallet signing path and regulatory treatment are separately validated.
