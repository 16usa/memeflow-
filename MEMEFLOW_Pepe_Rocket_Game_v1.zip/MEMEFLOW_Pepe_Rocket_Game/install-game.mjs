import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const cwd = process.cwd();
const appDir = [cwd, path.join(cwd, 'memeflow-app')].find((dir) => fs.existsSync(path.join(dir, 'index.html')) && fs.existsSync(path.join(dir, 'app-server.mjs')));
if (!appDir) { console.error('MEMEFLOW app directory not found. Run from repository root or memeflow-app.'); process.exit(1); }

const sourceDir = path.join(here, 'game-files');
for (const name of ['game.html', 'game.css', 'game.js']) fs.copyFileSync(path.join(sourceDir, name), path.join(appDir, name));
fs.mkdirSync(path.join(appDir, 'src'), { recursive: true });
fs.copyFileSync(path.join(sourceDir, 'game-engine.mjs'), path.join(appDir, 'src', 'game-engine.mjs'));

function backup(file) { const b = `${file}.before-pepe-rocket`; if (!fs.existsSync(b)) fs.copyFileSync(file, b); return b; }
function replaceRequired(source, needle, replacement, label) { if (!source.includes(needle)) throw new Error(`Installer could not find ${label}. No partial server patch was written.`); return source.replace(needle, replacement); }

const indexPath = path.join(appDir, 'index.html');
let html = fs.readFileSync(indexPath, 'utf8'); backup(indexPath);
if (!html.includes('MF_PEPE_ROCKET_DESKTOP_NAV')) {
  const needle = '<a class="active" href="#mission">Mission Control</a>';
  html = replaceRequired(html, needle, `${needle}<!-- MF_PEPE_ROCKET_DESKTOP_NAV --><a href="/game" onclick="window.location.assign('/game');return false">Game</a>`, 'desktop Mission Control navigation');
}
if (!html.includes('MF_PEPE_ROCKET_MOBILE_NAV')) {
  const needle = '<div class="grid"><button class="btn" id="openInspectorFromMore" type="button">Decision Inspector</button></div>';
  html = replaceRequired(html, needle, `<div class="grid"><!-- MF_PEPE_ROCKET_MOBILE_NAV --><a class="btn" href="/game" onclick="window.location.assign('/game');return false">Game</a><button class="btn" id="openInspectorFromMore" type="button">Decision Inspector</button></div>`, 'mobile More navigation');
}
fs.writeFileSync(indexPath, html);

const serverPath = path.join(appDir, 'app-server.mjs');
let server = fs.readFileSync(serverPath, 'utf8'); backup(serverPath);
if (!server.includes('MF_PEPE_ROCKET_GAME_IMPORT')) {
  const needle = "import {OpenAIIntelligence} from './src/openai-intelligence.mjs';import {PaperEngine} from './src/paper-engine.mjs';";
  server = replaceRequired(server, needle, `${needle}\nimport {GameEngine} from './src/game-engine.mjs'; // MF_PEPE_ROCKET_GAME_IMPORT`, 'PaperEngine import');
}
if (!server.includes('MF_PEPE_ROCKET_GAME_INSTANCE')) {
  const needle = 'const paper=new PaperEngine(store);';
  server = replaceRequired(server, needle, `${needle}\nconst game=new GameEngine(store); // MF_PEPE_ROCKET_GAME_INSTANCE`, 'PaperEngine instance');
}
if (!server.includes('MF_PEPE_ROCKET_GAME_ROUTE_ALIAS')) {
  const needle = "const p=url.pathname==='/'?'index.html':url.pathname.slice(1);const f=path.resolve(root,p);";
  server = replaceRequired(server, needle, "const p=url.pathname==='/'?'index.html':url.pathname==='/game'?'game.html':url.pathname.slice(1);const f=path.resolve(root,p); // MF_PEPE_ROCKET_GAME_ROUTE_ALIAS", 'static path resolver');
}
if (!server.includes('MF_PEPE_ROCKET_GAME_PUBLISH_HOOK')) {
  const needle = 'function publish(mint){\n  // Hot path: live Pump events can call publish many times per second.';
  const replacement = "function publish(mint){\n  // MF_PEPE_ROCKET_GAME_PUBLISH_HOOK: server-authoritative auto cashout / stop-loss follows the same live token updates.\n  try{game.onTokenUpdate(mint,store.state.tokens[mint])}catch(_){}\n  // Hot path: live Pump events can call publish many times per second.";
  server = replaceRequired(server, needle, replacement, 'publish(mint) hook');
}
if (!server.includes('MF_PEPE_ROCKET_GAME_API_ROUTES')) {
  const needle = " if(url.pathname==='/api/settings'&&req.method==='GET'){const settings=store.settings(u.id);";
  const routes = ` // MF_PEPE_ROCKET_GAME_API_ROUTES\n if(url.pathname==='/api/game/status'&&req.method==='GET')return json(res,200,game.status(u.id));\n if(url.pathname==='/api/game/start'&&req.method==='POST'){const r=game.start(u.id,await body(req));const code=r.ok?200:(r.code==='NO_CANDIDATE'?409:r.code==='ACTIVE_ROUND_EXISTS'||r.code==='ROUND_RESULT_PENDING'?409:400);return json(res,code,r);}\n if(url.pathname==='/api/game/cashout'&&req.method==='POST'){const r=game.cashout(u.id);return json(res,r.ok?200:409,r);}\n if(url.pathname==='/api/game/reset'&&req.method==='POST'){const r=game.reset(u.id);return json(res,r.ok?200:409,r);}\n if(url.pathname==='/api/game/history/clear'&&req.method==='POST')return json(res,200,game.clearHistory(u.id));\n\n`;
  server = replaceRequired(server, needle, routes + needle, 'settings route insertion point');
}
fs.writeFileSync(serverPath, server);

console.log(`Pepe Rocket PAPER GAME installed into: ${appDir}`);
console.log('Route: /game');
console.log('Server engine: src/game-engine.mjs');
console.log('Backups: index.html.before-pepe-rocket and app-server.mjs.before-pepe-rocket');
