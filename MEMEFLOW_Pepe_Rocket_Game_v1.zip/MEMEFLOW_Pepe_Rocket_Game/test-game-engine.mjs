import assert from 'node:assert/strict';
import { GameEngine } from './game-files/game-engine.mjs';

function storeFixture() {
  const state = { tokens: { MINT: { mint: 'MINT', name: 'Test Frog', symbol: 'FROG', priceSol: 1, lastPriceAt: Date.now(), holderCount: 120, top10Pct: 18, buyPressure: 1.8 } } };
  return { state, save() {}, decisions() { return [{ mint: 'MINT', state: 'BUY READY', score: 88, updatedAt: Date.now() }]; } };
}

{
  const store = storeFixture(); const game = new GameEngine(store, { startingBalance: 10000 });
  const start = game.start('u1', { bet: 100, autoCashout: 1.5, stopLoss: .75, requestId: 'A' });
  assert.equal(start.ok, true); assert.equal(start.balance, 9900); assert.equal(start.session.multiplier, 1);
  store.state.tokens.MINT.priceSol = 1.6; game.onTokenUpdate('MINT', store.state.tokens.MINT);
  const status = game.status('u1'); assert.equal(status.session.state, 'COMPLETE'); assert.equal(status.session.multiplier, 1.5); assert.equal(status.session.payout, 150); assert.equal(status.balance, 10050);
  game.onTokenUpdate('MINT', store.state.tokens.MINT); assert.equal(game.status('u1').balance, 10050);
}

{
  const store = storeFixture(); const game = new GameEngine(store, { startingBalance: 10000 });
  game.start('u2', { bet: 100, stopLoss: .8, requestId: 'B' }); store.state.tokens.MINT.priceSol = .72; game.onTokenUpdate('MINT', store.state.tokens.MINT);
  const status = game.status('u2'); assert.equal(status.session.reason, 'STOP_LOSS'); assert.equal(status.session.payout, 72); assert.equal(status.balance, 9972);
}

{
  const store = storeFixture(); let game = new GameEngine(store, { startingBalance: 10000 });
  game.start('u3', { bet: 200, requestId: 'C' }); store.state.tokens.MINT.priceSol = 1.25;
  game = new GameEngine(store, { startingBalance: 10000 }); const out = game.cashout('u3'); assert.equal(out.ok, true); assert.equal(out.session.payout, 250); assert.equal(out.balance, 10050);
}

console.log('game-engine tests: PASS');
