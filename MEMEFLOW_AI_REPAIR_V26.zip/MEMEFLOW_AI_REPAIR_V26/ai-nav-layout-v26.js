/* MEMEFLOW AI REPAIR V26
   NON-DESTRUCTIVE layout repair.
   Depends on the known-stable V24 AI runtime for AI behavior.
   V26 only:
   - keeps the original Wallet bottom-nav node in the DOM (hidden, not deleted)
   - keeps phone/tablet AI centered
   - adds AI to desktop sidebar
   - hides the old Manual AI CTA visually without using it as the visible control
   - never rewrites the entire mobile nav
*/
(() => {
  'use strict';

  if (window.__MEMEFLOW_AI_REPAIR_V26__) return;
  window.__MEMEFLOW_AI_REPAIR_V26__ = true;

  const AI_SOURCE_ID = 'mf-ai-center-nav-v24';
  const HEADER_WALLET_ID = 'mf-header-wallet-v24';
  const DESKTOP_AI_ID = 'mf-ai-desktop-v26';
  const STYLE_ID = 'mf-ai-repair-v26-style';

  const qsa = (selector, root = document) => {
    try { return [...root.querySelectorAll(selector)]; }
    catch (_) { return []; }
  };

  const cleanText = el => (el?.textContent || '').replace(/\s+/g, ' ').trim();

  const css = `
    /* =============================================================
       V26 FINAL RESPONSIVE RULES
       ============================================================= */

    /* Original Wallet nav button STAYS in DOM for native bindings. */
    .mobile-nav>[data-sheet="wallet"]{
      display:none!important;
    }

    /* Phone: only the star, no wrapper/border/background. */
    body.mf-v26-phone #${AI_SOURCE_ID}{
      border:0!important;
      outline:0!important;
      background:transparent!important;
      box-shadow:none!important;
      border-radius:0!important;
    }
    body.mf-v26-phone #${AI_SOURCE_ID} .mf-ai-center-label{
      display:none!important;
    }

    /* Tablet: same center position, with a small AI label. */
    body.mf-v26-tablet #${AI_SOURCE_ID}{
      border:0!important;
      outline:0!important;
      background:transparent!important;
      box-shadow:none!important;
      border-radius:0!important;
    }
    body.mf-v26-tablet #${AI_SOURCE_ID} .mf-ai-center-label{
      display:block!important;
      font-size:10px!important;
      line-height:1!important;
      letter-spacing:.06em!important;
      color:#a9b7c7!important;
    }

    /* Touch tablet, including iPad landscape: compact navigation only. */
    body.mf-v26-tablet{
      padding-bottom:calc(86px + env(safe-area-inset-bottom))!important;
    }
    body.mf-v26-tablet .app{
      display:block!important;
    }
    body.mf-v26-tablet .sidebar{
      display:none!important;
    }
    body.mf-v26-tablet .main{
      width:100%!important;
      max-width:none!important;
      padding-bottom:calc(104px + env(safe-area-inset-bottom))!important;
    }
    body.mf-v26-tablet .mobile-nav{
      display:grid!important;
      grid-template-columns:repeat(5,minmax(0,1fr))!important;
      position:fixed!important;
      left:12px!important;
      right:12px!important;
      bottom:calc(10px + env(safe-area-inset-bottom))!important;
      z-index:70!important;
    }
    body.mf-v26-tablet #${HEADER_WALLET_ID}{
      display:grid!important;
    }

    /* Real desktop: no bottom phone/tablet bar. */
    body.mf-v26-desktop .mobile-nav{
      display:none!important;
    }
    body.mf-v26-desktop #${HEADER_WALLET_ID}{
      display:none!important;
    }
    body.mf-v26-desktop .sidebar{
      display:block!important;
    }

    #${DESKTOP_AI_ID}{
      cursor:pointer;
    }
    #${DESKTOP_AI_ID} .mf-v26-star{
      display:inline-block;
      margin-right:7px;
      color:#72e5ff;
      text-shadow:0 0 10px rgba(84,221,255,.20);
    }

    /* Old CTA is visually absent from MANUAL AI SCAN, but no dependency is broken. */
    .mf-v26-hide-manual-ai{
      display:none!important;
      visibility:hidden!important;
      pointer-events:none!important;
    }
  `;

  function ensureStyle() {
    let style = document.getElementById(STYLE_ID);
    if (!style) {
      style = document.createElement('style');
      style.id = STYLE_ID;
      document.head.appendChild(style);
    }
    style.textContent = css;
  }

  function isCoarseTouch() {
    return !!(
      window.matchMedia?.('(pointer: coarse)').matches ||
      navigator.maxTouchPoints > 0
    );
  }

  function applyMode() {
    const width = window.innerWidth || document.documentElement.clientWidth || 0;
    const coarse = isCoarseTouch();

    const phone = width <= 600;
    const tablet = !phone && width <= 1366 && coarse;
    const desktop = !phone && !tablet && width >= 1025;

    document.body?.classList.toggle('mf-v26-phone', phone);
    document.body?.classList.toggle('mf-v26-tablet', tablet);
    document.body?.classList.toggle('mf-v26-desktop', desktop);

    /* 601–1024 without coarse pointer is still compact responsive layout. */
    if (!phone && !tablet && width <= 1024) {
      document.body?.classList.remove('mf-v26-desktop');
    }
  }

  function findMainSidebarNav() {
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) return null;
    return (
      sidebar.querySelector('nav[aria-label="Main navigation"]') ||
      sidebar.querySelector('.nav')
    );
  }

  function ensureDesktopAi() {
    const nav = findMainSidebarNav();
    if (!nav) return false;

    let link = document.getElementById(DESKTOP_AI_ID);
    if (!link) {
      link = document.createElement('a');
      link.id = DESKTOP_AI_ID;
      link.href = '#ai-assistant';
      link.innerHTML = '<span class="mf-v26-star" aria-hidden="true">✦</span><span>AI</span>';

      link.addEventListener('click', event => {
        event.preventDefault();
        event.stopPropagation();

        const source = document.getElementById(AI_SOURCE_ID);
        if (source) {
          source.click();
          return;
        }

        /* Safe fallback: the V24 source may mount a few ms later. */
        setTimeout(() => document.getElementById(AI_SOURCE_ID)?.click(), 120);
      });
    }

    if (link.parentElement !== nav) {
      const wallet = nav.querySelector('a[href="#wallet"]');
      const positions = nav.querySelector('a[href="#positions"]');
      const anchor = wallet || positions;

      if (anchor?.nextSibling) nav.insertBefore(link, anchor.nextSibling);
      else nav.appendChild(link);
    }

    return true;
  }

  function hideManualAssistantCta() {
    /* Keep the node if another script depends on it; only remove it visually. */
    const legacy = document.getElementById('mfManualAiButton');
    if (legacy) legacy.classList.add('mf-v26-hide-manual-ai');

    const candidates = qsa('button,a,[role="button"]');
    for (const el of candidates) {
      if (el.id === AI_SOURCE_ID || el.id === DESKTOP_AI_ID) continue;
      if (el.closest('#sheet-ai-direct-v24')) continue;

      const label = cleanText(el).replace(/[✦★✧]/g, '').trim().toLowerCase();
      if (label !== 'open ai assistant') continue;

      /* Restrict this to the Manual AI Scan area whenever possible. */
      const area = el.closest('section,article,.panel,.card,[class*="manual"],[id*="manual"]');
      const areaText = cleanText(area).toLowerCase();

      if (
        areaText.includes('manual ai scan') ||
        areaText.includes('analyze any solana token') ||
        el.id === 'mfManualAiButton'
      ) {
        el.classList.add('mf-v26-hide-manual-ai');
        el.setAttribute('aria-hidden', 'true');
        el.tabIndex = -1;
      }
    }
  }

  function keepOriginalWalletNode() {
    /* Important: DO NOT delete this node. Native code may have bound to it. */
    const wallet = document.querySelector('.mobile-nav [data-sheet="wallet"]');
    if (!wallet) return false;
    wallet.hidden = false;
    wallet.style.removeProperty('display');
    return true;
  }

  function installPass() {
    applyMode();
    keepOriginalWalletNode();
    ensureDesktopAi();
    hideManualAssistantCta();
  }

  function install() {
    ensureStyle();
    installPass();

    /* Bounded retries only. */
    [80, 250, 800, 1800, 4000, 7500].forEach(ms => {
      setTimeout(installPass, ms);
    });

    let resizeTimer = 0;
    addEventListener('resize', () => {
      clearTimeout(resizeTimer);
      resizeTimer = setTimeout(installPass, 120);
    }, { passive:true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', install, { once:true });
  } else {
    install();
  }
})();
