UPLOAD ZIP TO ~/workspace, THEN:
rm -rf /tmp/pepev34 && mkdir -p /tmp/pepev34
unzip -o PEPE_ROCKET_V34_STAGE2.zip -d /tmp/pepev34
bash /tmp/pepev34/install-v34-stage2.sh
