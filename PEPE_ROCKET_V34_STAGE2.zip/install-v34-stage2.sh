#!/usr/bin/env bash
set -euo pipefail
cd ~/workspace
BRANCH="$(git branch --show-current)"
if [ "$BRANCH" != "agent/fix-navigation-and-errors" ]; then echo "WRONG BRANCH: $BRANCH"; exit 1; fi
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="$HERE/payload/memeflow-app"
mkdir -p memeflow-app/_backup/v34-stage2
cp -f memeflow-app/character-real-test-v16.js memeflow-app/_backup/v34-stage2/character-real-test-v16.before-v34.js || true
cp -f memeflow-app/character-real-test-v16.html memeflow-app/_backup/v34-stage2/character-real-test-v16.before-v34.html || true
mkdir -p memeflow-app/game-assets/rocket-v34
cp -R "$SRC/game-assets/rocket-v34/." memeflow-app/game-assets/rocket-v34/
cp -f "$SRC/pepe-face-controller.js" memeflow-app/pepe-face-controller.js
cp -f "$SRC/rocket-ride-v34.js" memeflow-app/rocket-ride-v34.js
cp -f "$SRC/character-real-test-v16.js" memeflow-app/character-real-test-v16.js
cp -f "$SRC/character-real-test-v16.html" memeflow-app/character-real-test-v16.html
node --check memeflow-app/pepe-face-controller.js
node --check memeflow-app/rocket-ride-v34.js
node --check memeflow-app/character-real-test-v16.js
git diff --check -- memeflow-app/pepe-face-controller.js memeflow-app/rocket-ride-v34.js memeflow-app/character-real-test-v16.js memeflow-app/character-real-test-v16.html
git add memeflow-app/game-assets/rocket-v34 memeflow-app/pepe-face-controller.js memeflow-app/rocket-ride-v34.js memeflow-app/character-real-test-v16.js memeflow-app/character-real-test-v16.html memeflow-app/_backup/v34-stage2
if git diff --cached --quiet; then echo "V34 Stage 2 already installed"; else git commit -m "Add Pepe Rocket Ride V34 live porthole face"; git push origin agent/fix-navigation-and-errors; fi
echo "V34 STAGE 2 INSTALLED OK"
