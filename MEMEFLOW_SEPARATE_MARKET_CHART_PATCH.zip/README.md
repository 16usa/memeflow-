# MEMEFLOW — Separate Market Chart Patch

This patch moves the existing `#marketChart` out of **AI Decision Studio** and places it in a separate standalone module directly before **Pre-trade execution checks**.

It does not create a second chart and does not change chart IDs, polling, subscriptions, intervals, live updates, markers, or event listeners.

## Apply in Replit

Open the Replit Shell from the repository root and run:

```bash
node scripts/separate-market-chart.mjs
```

Then restart the application:

```bash
npm start
```

## Roll back

The patch automatically creates:

```text
memeflow-app/index.html.before-market-chart-module
```

To restore:

```bash
cp memeflow-app/index.html.before-market-chart-module memeflow-app/index.html
```

## Validation

The installer stops and restores the original file if it finds more than one `#marketChart` or cannot locate the expected MEMEFLOW markup.
