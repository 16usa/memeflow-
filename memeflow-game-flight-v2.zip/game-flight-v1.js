import * as THREE from '/vendor/three.module.js';
import { createPepeRealRigV16 } from '/character-real-rig-v16.js?v=32800';

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const stage=document.getElementById('stage');
const stateEl=document.getElementById('state');
const subStateEl=document.getElementById('subState');
const multEl=document.getElementById('multiplier');
const pnlEl=document.getElementById('pnl');
const targetInput=document.getElementById('target');
const stopInput=document.getElementById('stop');
const targetLabel=document.getElementById('targetLabel');
const stopLabel=document.getElementById('stopLabel');
const stopLine=document.getElementById('stopLine');
const result=document.getElementById('result');
const resultTitle=document.getElementById('resultTitle');
const resultText=document.getElementById('resultText');

const scene=new THREE.Scene();
const camera=new THREE.OrthographicCamera(-4,4,2.2,-2.2,.1,100);
camera.position.set(0,0,10);
const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));
renderer.setClearColor(0x000000,0);
stage.appendChild(renderer.domElement);

const world=new THREE.Group();
scene.add(world);
const bgFar=new THREE.Group(),bgMid=new THREE.Group(),fxLayer=new THREE.Group(),characterAnchor=new THREE.Group();
world.add(bgFar,bgMid,fxLayer,characterAnchor);

const fitGroup=new THREE.Group();
characterAnchor.add(fitGroup);
const pepe=createPepeRealRigV16({parent:fitGroup});

const runtime={
  state:'loading',entryPrice:1,price:1,multiplier:1,pnlPct:0,
  target:5,stopLoss:null,startedAt:0,stateAt:performance.now(),pending:null,
  y:0,vy:0,worldX:0,shake:0,demo:null,demoT:0,finished:false
};

function makeStarField(group,count,z,size,opacity){
  const geo=new THREE.BufferGeometry();
  const pos=[];
  for(let i=0;i<count;i++)pos.push((Math.random()-.5)*18,(Math.random()-.5)*7,z);
  geo.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));
  const mat=new THREE.PointsMaterial({color:0xd8edff,size,transparent:true,opacity,depthWrite:false});
  const pts=new THREE.Points(geo,mat);group.add(pts);return pts;
}
const farStars=makeStarField(bgFar,150,-2,.018,.42);
const midStars=makeStarField(bgMid,80,-1,.03,.72);

const trailPoints=[];
const trailGeo=new THREE.BufferGeometry();
const trailMat=new THREE.LineBasicMaterial({color:0x58d8ff,transparent:true,opacity:.42,depthWrite:false});
const trailLine=new THREE.Line(trailGeo,trailMat);trailLine.frustumCulled=false;fxLayer.add(trailLine);

const flameGroup=new THREE.Group();characterAnchor.add(flameGroup);
function makeFlame(color,xScale,opacity){
  const geo=new THREE.ConeGeometry(.12,.72,12);geo.rotateZ(Math.PI/2);geo.translate(-.36,0,0);
  const mat=new THREE.MeshBasicMaterial({color,transparent:true,opacity,depthWrite:false,blending:THREE.AdditiveBlending});
  const mesh=new THREE.Mesh(geo,mat);mesh.scale.set(xScale,1,1);flameGroup.add(mesh);return mesh;
}
const flameOuter=makeFlame(0x3ecbff,1.3,.6);
const flameInner=makeFlame(0xe9fbff,.72,.95);
flameGroup.position.set(-1.05,-.28,.2);

const parachute=new THREE.Group();characterAnchor.add(parachute);parachute.visible=false;
const canopyMat=new THREE.MeshBasicMaterial({color:0xe8eef2,transparent:true,opacity:.96,side:THREE.DoubleSide,depthWrite:false});
const canopy=new THREE.Mesh(new THREE.CircleGeometry(.75,40,0,Math.PI),canopyMat);canopy.rotation.z=Math.PI;canopy.position.y=1.36;parachute.add(canopy);
const ropeMat=new THREE.LineBasicMaterial({color:0xcfd9df,transparent:true,opacity:.9});
for(const x of [-.56,.56]){const g=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,.3,.1),new THREE.Vector3(x,1.22,.1)]);parachute.add(new THREE.Line(g,ropeMat));}
parachute.scale.setScalar(.001);

function fitCharacter(){
  fitGroup.position.set(0,0,0);fitGroup.scale.setScalar(1);pepe.root.position.set(0,0,0);pepe.root.rotation.set(0,0,0);pepe.root.updateMatrixWorld(true);
  const box=new THREE.Box3().setFromObject(fitGroup);if(box.isEmpty())return;
  const size=new THREE.Vector3(),center=new THREE.Vector3();box.getSize(size);box.getCenter(center);
  const mobile=window.innerWidth<=600;
  const maxW=mobile?1.05:1.45;
  const maxH=mobile?1.62:2.05;
  const s=clamp(Math.min(maxW/Math.max(size.x,.001),maxH/Math.max(size.y,.001)),.16,.82);
  fitGroup.scale.setScalar(s);fitGroup.position.set(-center.x*s,-center.y*s,0);fitGroup.updateMatrixWorld(true);
  flameGroup.scale.setScalar(s*.86);parachute.scale.setScalar(.001);
}

function resize(){
  const r=stage.getBoundingClientRect(),w=Math.max(1,Math.round(r.width)),h=Math.max(1,Math.round(r.height));
  renderer.setSize(w,h,false);const halfH=2.2,aspect=w/h;camera.left=-halfH*aspect;camera.right=halfH*aspect;camera.top=halfH;camera.bottom=-halfH;camera.updateProjectionMatrix();
  fitCharacter();
}
new ResizeObserver(resize).observe(stage);addEventListener('resize',resize);visualViewport?.addEventListener('resize',resize);

function readConfig(){
  runtime.target=clamp(Number(targetInput.value)||5,1.05,100);
  const raw=stopInput.value.trim();runtime.stopLoss=raw===''?null:clamp(Math.abs(Number(raw)||0),.1,99);
  targetLabel.textContent=`TARGET ${runtime.target.toFixed(2)}x`;
  stopLabel.textContent=runtime.stopLoss==null?'NO STOP-LOSS':`STOP −${runtime.stopLoss}%`;
  stopLine.style.display=runtime.stopLoss==null?'none':'block';
}
function setHud(title,sub){stateEl.textContent=title;subStateEl.textContent=sub;}
function enter(next){
  runtime.state=next;runtime.stateAt=performance.now();
  if(next==='launch'){setHud('IGNITION',`Target ${runtime.target.toFixed(2)}x${runtime.stopLoss==null?' · No stop-loss':` · Stop −${runtime.stopLoss}%`}`);}
  if(next==='flying')setHud('LIVE','Price controls vertical flight');
  if(next==='stopDeploy')setHud('STOP LOSS','Emergency parachute');
  if(next==='parachuting')setHud('STOPPED','Protected exit');
  if(next==='targetHit'){setHud(`${runtime.target.toFixed(2)}x TARGET HIT`,'Maximum thrust');runtime.shake=.12;}
  if(next==='victory')setHud('TARGET COMPLETE','Moon exit');
  if(next==='cashOut')setHud('CASH OUT','Controlled exit');
  if(next==='crash')setHud('NO STOP · LOSS','Engine failure · uncontrolled fall');
  if(next==='reconnecting')setHud('RECONNECTING…','Flight frozen · no loss event');
  if(next==='cancelled')setHud('ROUND CANCELLED','Neutral exit');
}
function queueOutcome(next){
  if(runtime.state==='launch'&&performance.now()-runtime.startedAt<340){runtime.pending=next;return;}enter(next);
}
function startRound(demo=null){
  readConfig();runtime.entryPrice=1;runtime.price=1;runtime.multiplier=1;runtime.pnlPct=0;runtime.y=0;runtime.vy=0;runtime.worldX=0;runtime.pending=null;runtime.startedAt=performance.now();runtime.finished=false;runtime.demo=demo;runtime.demoT=0;trailPoints.length=0;result.classList.remove('show');parachute.visible=false;parachute.scale.setScalar(.001);flameGroup.visible=true;characterAnchor.position.set(camera.left+(camera.right-camera.left)*(window.innerWidth<=600?.28:.34),-.05,0);characterAnchor.rotation.z=0;pepe.root.rotation.z=0;enter('launch');
}
function onPrice(mult){
  if(!['launch','flying','reconnecting'].includes(runtime.state))return;
  runtime.multiplier=Math.max(.01,Number(mult)||1);runtime.pnlPct=(runtime.multiplier-1)*100;runtime.price=runtime.entryPrice*runtime.multiplier;
  if(runtime.multiplier>=runtime.target)queueOutcome('targetHit');
  else if(runtime.stopLoss!=null&&runtime.pnlPct<=-runtime.stopLoss)queueOutcome('stopDeploy');
}
window.MemeFlowGame={
  start:(cfg={})=>{if(cfg.targetMultiplier!=null)targetInput.value=cfg.targetMultiplier;if(cfg.stopLossPct==null)stopInput.value='';else if(cfg.stopLossPct!==undefined)stopInput.value=cfg.stopLossPct;startRound(null)},
  priceTick:({multiplier,price,pnlPct}={})=>{if(multiplier!=null)return onPrice(multiplier);if(price!=null)return onPrice(Number(price)/runtime.entryPrice);if(pnlPct!=null)return onPrice(1+Number(pnlPct)/100)},
  targetHit:()=>queueOutcome('targetHit'),stopLossHit:()=>queueOutcome('stopDeploy'),cashOut:()=>queueOutcome('cashOut'),roundCrash:()=>queueOutcome('crash'),
  feedLost:()=>enter('reconnecting'),feedRestored:()=>runtime.state==='reconnecting'&&enter('flying'),cancel:()=>queueOutcome('cancelled'),getState:()=>({...runtime})
};

function priceToY(){
  const positive=Math.log(Math.max(1,runtime.multiplier))/Math.log(Math.max(1.05,runtime.target));
  if(runtime.multiplier>=1)return clamp(positive*(window.innerWidth<=600?.95:1.25),0,window.innerWidth<=600?1.05:1.35);
  const lossScale=runtime.stopLoss!=null?Math.abs(Math.log(Math.max(.01,1-runtime.stopLoss/100))):Math.log(2.4);
  return -clamp(Math.abs(Math.log(Math.max(.02,runtime.multiplier)))/Math.max(.01,lossScale)*(window.innerWidth<=600?.9:1.15),0,window.innerWidth<=600?1.15:1.5);
}
function updateTrail(){
  trailPoints.push(new THREE.Vector3(characterAnchor.position.x-.75,characterAnchor.position.y,0));if(trailPoints.length>100)trailPoints.shift();
  const pts=trailPoints.map((p,i)=>new THREE.Vector3(p.x-(trailPoints.length-1-i)*.026,p.y,0));trailGeo.setFromPoints(pts);
}
function demoStep(dt){
  if(!runtime.demo||!['launch','flying'].includes(runtime.state))return;runtime.demoT+=dt;const t=runtime.demoT;let m=1;
  if(runtime.demo==='flight')m=1+Math.sin(t*.85)*.22+Math.sin(t*2.3)*.04;
  if(runtime.demo==='stop'){if(runtime.stopLoss==null){runtime.stopLoss=18;stopInput.value='18';readConfig();}m=1-Math.min(.35,t*.12)+Math.sin(t*3.7)*.015;}
  if(runtime.demo==='crash'){runtime.stopLoss=null;stopInput.value='';readConfig();m=1-Math.min(.88,t*.17);if(t>4.7)queueOutcome('crash');}
  if(runtime.demo==='cash'){m=1+Math.min(.7,t*.16)+Math.sin(t*2.8)*.02;if(t>3.6)queueOutcome('cashOut');}
  if(runtime.demo==='win'){m=1+(runtime.target-1)*clamp((t-.7)/4.4,0,1)+Math.sin(t*3)*.025;if(t>5.2)m=runtime.target;}
  onPrice(m);
}
function finish(title,text){if(runtime.finished)return;runtime.finished=true;resultTitle.textContent=title;resultText.textContent=text;result.classList.add('show');}

const clock=new THREE.Clock();let t=0;
function frame(){
  requestAnimationFrame(frame);const dt=Math.min(clock.getDelta(),.05);t+=dt;demoStep(dt);const age=(performance.now()-runtime.stateAt)/1000;
  farStars.position.x=-(runtime.worldX*.035)%3;midStars.position.x=-(runtime.worldX*.08)%3;runtime.worldX+=dt*(runtime.state==='reconnecting'?.08:1.0);
  const anchorX=camera.left+(camera.right-camera.left)*(window.innerWidth<=600?.28:.34);characterAnchor.position.x=anchorX;
  if(runtime.state==='launch'){
    characterAnchor.position.y=lerp(-.12,0,clamp(age/.42,0,1));pepe.setMarket({direction:0,speed:.75,thrust:.88});
    if(age>=.42){if(runtime.pending){const n=runtime.pending;runtime.pending=null;enter(n);}else enter('flying');}
  }else if(runtime.state==='flying'){
    const targetY=priceToY(),a=1-Math.exp(-dt*5.5);runtime.vy=lerp(runtime.vy,(targetY-runtime.y)*3.2,a);runtime.y+=runtime.vy*dt;characterAnchor.position.y=runtime.y;
    const direction=clamp(runtime.vy*2.5,-1,1);pepe.setMarket({direction,speed:clamp(.25+Math.abs(runtime.vy)*.8,.2,1),thrust:clamp(.3+Math.max(0,runtime.vy)*.7,.18,1)});
    characterAnchor.rotation.z=lerp(characterAnchor.rotation.z,clamp(runtime.vy*.14,-.18,.18),a);updateTrail();
  }else if(runtime.state==='reconnecting'){
    characterAnchor.position.y=runtime.y+Math.sin(t*2)*.025;pepe.setMarket({direction:0,speed:.08,thrust:.16});
  }else if(runtime.state==='stopDeploy'){
    pepe.setMarket({direction:-1,speed:.03,thrust:0});flameGroup.visible=false;parachute.visible=true;const s=clamp(age/.3,0,1);parachute.scale.setScalar(s);characterAnchor.position.y-=dt*.12;if(age>.32)enter('parachuting');
  }else if(runtime.state==='parachuting'){
    characterAnchor.position.y-=dt*.72;characterAnchor.rotation.z=Math.sin(t*2.4)*.025;pepe.setMarket({direction:-1,speed:.03,thrust:0});if(characterAnchor.position.y<camera.bottom-1.2)finish('STOP LOSS','Parachute exit · position closed at stop.');
  }else if(runtime.state==='targetHit'){
    pepe.setMarket({direction:1,speed:1,thrust:1});characterAnchor.rotation.z=lerp(characterAnchor.rotation.z,-.45,1-Math.exp(-dt*9));flameGroup.visible=true;flameGroup.scale.x=1.8;if(age>.28)enter('victory');
  }else if(runtime.state==='victory'){
    characterAnchor.position.y+=dt*(1.5+age*.9);pepe.setMarket({direction:1,speed:1,thrust:1});runtime.shake=Math.max(0,runtime.shake-dt*.18);if(characterAnchor.position.y>camera.top+1.5)finish('TARGET HIT',`${runtime.target.toFixed(2)}x reached · victory boost.`);
  }else if(runtime.state==='cashOut'){
    characterAnchor.position.x+=dt*1.7;characterAnchor.position.y+=dt*.38;pepe.setMarket({direction:1,speed:.7,thrust:.7});if(age>1.2)finish('CASH OUT',`${runtime.multiplier.toFixed(2)}x · controlled exit.`);
  }else if(runtime.state==='crash'){
    flameGroup.visible=false;parachute.visible=false;characterAnchor.position.y-=dt*(.55+age*.72);characterAnchor.rotation.z+=dt*(2.4+age);pepe.setMarket({direction:-1,speed:.02,thrust:0});if(characterAnchor.position.y<camera.bottom-1.3)finish('ROUND LOST','No stop-loss · uncontrolled fall after terminal loss event.');
  }else if(runtime.state==='cancelled'){
    characterAnchor.position.x+=dt*.9;characterAnchor.position.y+=dt*.08;pepe.setMarket({direction:0,speed:.2,thrust:.2});if(age>1.3)finish('CANCELLED','Neutral exit · no win/loss animation.');
  }
  if(runtime.shake>0){camera.position.x=(Math.random()-.5)*runtime.shake;camera.position.y=(Math.random()-.5)*runtime.shake*.45;}else{camera.position.x=0;camera.position.y=0;}
  const boost=['targetHit','victory'].includes(runtime.state)?1.5:1;flameOuter.scale.x=boost*(1+Math.sin(t*28)*.08);flameInner.scale.x=boost*(1+Math.sin(t*32)*.06);
  pepe.update(t,dt);
  multEl.textContent=`${runtime.multiplier.toFixed(2)}x`;pnlEl.textContent=`${runtime.pnlPct>=0?'+':''}${runtime.pnlPct.toFixed(1)}%`;pnlEl.style.color=runtime.pnlPct>=0?'#68e5ad':'#ff7183';
  renderer.render(scene,camera);
}

pepe.ready.then(()=>{runtime.state='ready';readConfig();resize();fitCharacter();setHud('READY','Choose target and press START');frame();}).catch(err=>{console.error('[GAME FLIGHT]',err);setHud('LOAD ERROR','Pepe rig failed to load');});

document.getElementById('start').onclick=()=>startRound(null);
document.getElementById('again').onclick=()=>{result.classList.remove('show');startRound(null)};
document.querySelectorAll('[data-demo]').forEach(b=>b.onclick=()=>startRound(b.dataset.demo));
targetInput.addEventListener('change',readConfig);stopInput.addEventListener('change',readConfig);
