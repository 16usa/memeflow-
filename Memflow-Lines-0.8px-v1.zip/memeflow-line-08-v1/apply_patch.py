from pathlib import Path
import re

TARGET = Path('memeflow-app/memeflow-x-canonical-v186.css')
if not TARGET.exists():
    raise SystemExit(f'Target not found: {TARGET}')

text = TARGET.read_text(encoding='utf-8')
backup = TARGET.with_suffix(TARGET.suffix + '.bak.memeflow_line08_v1')
if not backup.exists():
    backup.write_text(text, encoding='utf-8')

start = '/* MEMEFLOW_DARK_LINE_08_V1_START */'
end = '/* MEMEFLOW_DARK_LINE_08_V1_END */'
if start in text and end in text:
    text = re.sub(re.escape(start) + r'.*?' + re.escape(end), '', text, flags=re.S)

block = r'''

/* MEMEFLOW_DARK_LINE_08_V1_START */
/* Dark UI structural frames + dividers: 1px -> 0.8px. Light theme unchanged. */
html:not([data-theme="light"]){
  --mf-structure-hairline:.8px !important;
  --mf-x-dark-hairline:.8px !important;
  --mf-x-line-width:.8px !important;
}

html:not([data-theme="light"]) body :where(
  .panel,
  .glass:not(.viewport-wrap),
  .mf-infra,
  .activity-panel,
  .flow-hero,
  .flow-toolbar,
  .pagination,
  .summary-card,
  .token-list,
  .token-row,
  .flow-token,
  .token-card,
  .token-card-expanded,
  .scanner-card,
  .metric,
  .metric-card,
  .candidate-filter,
  .positions-list,
  .approval-list,
  .trade-history,
  .selected-metrics,
  .strategy-summary-panel,
  .strategy-summary-list,
  .strategy-summary-row,
  .wallet-card,
  .wallet-security,
  .wallet-stat,
  .wallet-session-note,
  .wallet-rule,
  .subscription-metric,
  .plan-card,
  .live-lock,
  .system-health-summary > div,
  .data-row,
  .settings-summary > div,
  .settings-context,
  .settings-group,
  .mode-option label,
  .profile-option label,
  .setting-field input,
  .setting-field select,
  .toggle-row,
  .execution-readiness,
  .primary-blocker,
  .signal-explainer,
  .execution-check-list,
  .wallet-note,
  .wallet-network,
  .wallet-option,
  .mobile-wallet-card,
  .explain-step,
  .production-empty,
  .mf293-settings-panel,
  .mf293-settings-group,
  .mf293-field,
  .mf-theme-appearance,
  .mf-theme-segmented,
  .mf-vault-card,
  .mf-vault-status-panel,
  .mf-vault-row,
  .mf-vault-stat,
  .mf-vault-action,
  .mf-vault-note,
  .mf-hiw-status-card,
  .mf-hiw-map-shell,
  .mf-hiw-map-detail,
  .mf-hiw-node,
  .mf-hiw-step,
  .mf-hiw-control-card,
  .mf-hiw-money,
  .mf-hiw-money-flow > div,
  .mf-hiw-faq details,
  .mf-hiw-cta,
  .ap-source,
  .ap-panel,
  .ap-kpis article,
  .ap-summary div,
  .oi-panel,
  .oi-stat,
  .oi-notice,
  .oi-decision,
  .oi-row,
  .mf-paper-position,
  .mf-paper-proposal,
  .mf-paper-status,
  .mf-paper-grid > div,
  .mfpg-card,
  input,
  select,
  textarea,
  .tool-btn,
  .ghost-btn,
  .refresh-info button,
  .pagination button,
  .strategy-summary-panel .strategy-edit-link,
  .mf293-settings-head-actions button,
  .mf293-secondary,
  .mf-hiw-btn-ghost,
  .ap-refresh,
  .oi-btn.ghost,
  .inspector-foot button
){
  border-width:.8px !important;
}

/* Existing one-sided separators keep their side/style; only thickness changes. */
html:not([data-theme="light"]) body :where(
  hr,
  .panel-head,
  .chart-head,
  .candidate-filter,
  .timeframes,
  .indicator-bar,
  .selected-metrics,
  .strategy-summary-foot,
  .details,
  .tx-details,
  .doc-section,
  .mf293-settings-head,
  .mf293-settings-meta,
  .mf293-settings-footer,
  .mf-hiw-status-head,
  .mf-hiw-map-detail,
  .mf-nav-drawer,
  .mf-nav-drawer-head,
  .mf-nav-link,
  .mf-nav-foot,
  .stat-row,
  .principles,
  .allocation-list,
  .flow-stack,
  .faq-list,
  details,
  footer,
  [class*="divider"],
  [class*="separator"]
){
  border-width:.8px !important;
}

html:not([data-theme="light"]) body.mf-page-trading.mf-trading-terminal
:where(.candidate,.position-row,.trade-row.trade-log-row)::after{
  height:.8px !important;
}

html:not([data-theme="light"]) body.mf-page-system .viewport-wrap{
  border-width:.8px !important;
}

html:not([data-theme="light"]) body :where(
  .wallet-btn,
  .btn.primary,
  .mf293-primary,
  .mf-hiw-btn-primary,
  .mf-vault-btn-primary,
  .oi-btn.primary
){
  border-width:.8px !important;
}
/* MEMEFLOW_DARK_LINE_08_V1_END */
'''

TARGET.write_text(text.rstrip() + block + '\n', encoding='utf-8')
print('Applied 0.8px dark structural line patch.')
