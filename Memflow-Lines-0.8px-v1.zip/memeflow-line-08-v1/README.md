# Memflow 0.8px Lines v1

Dark theme only.

Reduces structural module frames and divider lines from 1px to 0.8px. It does not change layout, colors, typography, trading logic, scanning logic, or the light theme.
