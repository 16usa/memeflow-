#!/usr/bin/env bash
set -euo pipefail
TARGET='memeflow-app/memeflow-x-canonical-v186.css'
BACKUP='memeflow-app/memeflow-x-canonical-v186.css.bak.memeflow_line08_v1'

if [ ! -f "$BACKUP" ]; then
  echo "Backup not found: $BACKUP"
  exit 1
fi
cp "$BACKUP" "$TARGET"
git diff --check
git add "$TARGET"
if ! git diff --cached --quiet; then
  git commit -m "Rollback Memflow 0.8px line patch"
  git push
else
  echo 'No git changes to commit.'
fi
echo 'Rollback complete. Restart manually when ready.'
