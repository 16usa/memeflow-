#!/usr/bin/env bash
set -euo pipefail

echo 'Installing Memflow 0.8px line patch v1...'
python3 /tmp/memeflow-line-08-v1/memeflow-line-08-v1/apply_patch.py

echo '+ git diff --check'
git diff --check

echo 'Patch checks passed.'
echo 'No server restart was performed.'

git add memeflow-app/memeflow-x-canonical-v186.css
if ! git diff --cached --quiet; then
  git commit -m "Memflow: reduce dark frames and dividers to 0.8px"
  git push
else
  echo 'No git changes to commit.'
fi

echo 'Done. Restart the app manually from the Replit console when ready.'
