#!/usr/bin/env bash
set -euo pipefail
if [[ -d memeflow-app && -f memeflow-app/live-bootstrap.mjs ]]; then cd memeflow-app; fi
node --check src/insightx-wallet-intelligence.mjs
node --check memeflow-insightx-v1.js
node --check live-bootstrap.mjs
node tests/insightx-wallet-intelligence-v1.mjs
node tests/insightx-ui-v1.mjs
echo "TARGETED VERIFICATION: PASS"
