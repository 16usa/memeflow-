MEMEFLOW InsightX Wallet Intelligence V1
========================================

What this patch does
- Keeps MEMEFLOW Solana RPC holders and evaluate() as canonical truth.
- Adds InsightX as a fail-open, read-only shadow intelligence layer.
- Adds official InsightX REST aggregation for clusters, holder distribution,
  bundlers, insiders/dev, and snipers.
- Adds bounded in-memory cache + in-flight deduplication.
- Keeps INSIGHTX_API_KEY server-side.
- Adds a small window/panel icon immediately beside token names in Token Flow.
- Clicking it opens a responsive Atlas Live modal/bottom sheet with summary metrics.
- Does NOT alter canonical Score, State, entry gates, or existing wallet-risk penalty.
- Optional visible-card shadow prefetch is OFF by default to protect API quota.

Install from the repository/workspace root:
  bash /path/to/MEMEFLOW-InsightX-Wallet-Intelligence-v1/install.sh

Required Replit Secrets:
  INSIGHTX_API_KEY=<your InsightX API key>
  INSIGHTX_ATLAS_EMBED_ID=<your InsightX production embed id>

Optional:
  INSIGHTX_ENABLED=true
  INSIGHTX_EXTENDED_METRICS=true
  INSIGHTX_SHADOW_PREFETCH=false
  INSIGHTX_CACHE_TTL_MS=60000
  INSIGHTX_REQUEST_TIMEOUT_MS=5000

Verify:
  bash /path/to/MEMEFLOW-InsightX-Wallet-Intelligence-v1/verify.sh

Rollback:
  bash /path/to/MEMEFLOW-InsightX-Wallet-Intelligence-v1/rollback.sh

The installer makes a timestamped backup under:
  memeflow-app/.memeflow-backups/insightx-wallet-intelligence-v1-YYYYMMDD-HHMMSS

After installation, restart the existing MEMEFLOW workflow/process. Do not start a second server process.
