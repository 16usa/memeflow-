#!/usr/bin/env python3
from __future__ import annotations
import json, shutil, sys
from pathlib import Path

def find_app(start: Path)->Path:
    for base in (start,start/'memeflow-app'):
        if (base/'live-bootstrap.mjs').is_file(): return base.resolve()
    cur=start.resolve()
    for _ in range(4):
        if (cur/'memeflow-app/live-bootstrap.mjs').is_file(): return (cur/'memeflow-app').resolve()
        if (cur/'live-bootstrap.mjs').is_file(): return cur
        cur=cur.parent
    raise SystemExit('Could not locate MEMEFLOW app root.')

def main():
    app=find_app(Path.cwd())
    marker=app/'.memeflow-insightx-v1-last-backup'
    if not marker.exists(): raise SystemExit('No InsightX V1 backup marker found.')
    backup=Path(marker.read_text(encoding='utf-8').strip())
    manifest_path=backup/'manifest.json'
    if not manifest_path.exists(): raise SystemExit(f'Backup manifest missing: {manifest_path}')
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    for rel,meta in manifest['files'].items():
        dst=app/rel
        if meta.get('existed'):
            src=backup/'files'/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)
        elif dst.exists():
            if dst.is_dir(): shutil.rmtree(dst)
            else: dst.unlink()
    marker.unlink(missing_ok=True)
    print('ROLLBACK: PASS')
    print('Restored from:',backup)

if __name__=='__main__': main()
