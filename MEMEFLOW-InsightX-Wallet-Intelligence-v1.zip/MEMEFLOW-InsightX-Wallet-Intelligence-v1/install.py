#!/usr/bin/env python3
from __future__ import annotations
import json, os, shutil, subprocess, sys, time
from pathlib import Path

PATCH_ID='MEMEFLOW_INSIGHTX_WALLET_INTELLIGENCE_V1'
HERE=Path(__file__).resolve().parent
FILES=HERE/'files'

def find_app_root(start: Path) -> Path:
    candidates=[start, start/'memeflow-app']
    for base in candidates:
        if (base/'live-bootstrap.mjs').is_file() and (base/'system-tokens.html').is_file():
            return base.resolve()
    cur=start.resolve()
    for _ in range(4):
        if (cur/'memeflow-app/live-bootstrap.mjs').is_file():
            return (cur/'memeflow-app').resolve()
        if (cur/'live-bootstrap.mjs').is_file() and (cur/'system-tokens.html').is_file():
            return cur
        if cur.parent==cur: break
        cur=cur.parent
    raise SystemExit('ERROR: Could not locate MEMEFLOW app root (live-bootstrap.mjs + system-tokens.html).')

def replace_once(text: str, anchor: str, replacement: str, label: str) -> str:
    count=text.count(anchor)
    if count!=1:
        raise RuntimeError(f'{label}: expected exactly one anchor, found {count}')
    return text.replace(anchor,replacement,1)

def backup_paths(app: Path, backup: Path, rels: list[str]):
    manifest={'patch_id':PATCH_ID,'app_root':str(app),'created_at':int(time.time()),'files':{}}
    for rel in rels:
        src=app/rel
        entry={'existed':src.exists()}
        manifest['files'][rel]=entry
        if src.exists():
            dst=backup/'files'/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)
    backup.mkdir(parents=True,exist_ok=True)
    (backup/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return manifest

def restore(app: Path, backup: Path, manifest: dict):
    for rel,meta in manifest['files'].items():
        dst=app/rel
        if meta.get('existed'):
            src=backup/'files'/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)
        elif dst.exists():
            if dst.is_dir(): shutil.rmtree(dst)
            else: dst.unlink()

def run(cmd, cwd):
    print('+',' '.join(cmd))
    subprocess.run(cmd,cwd=cwd,check=True)

def main():
    app=find_app_root(Path.cwd())
    print('MEMEFLOW app:',app)

    touched=[
        'live-bootstrap.mjs','system-tokens.html',
        'src/insightx-wallet-intelligence.mjs',
        'memeflow-insightx-v1.js','memeflow-insightx-v1.css',
        'tests/insightx-wallet-intelligence-v1.mjs','tests/insightx-ui-v1.mjs',
        'docs/INSIGHTX_WALLET_INTELLIGENCE_V1.md'
    ]
    stamp=time.strftime('%Y%m%d-%H%M%S')
    backup=app/'.memeflow-backups'/f'insightx-wallet-intelligence-v1-{stamp}'
    manifest=backup_paths(app,backup,touched)

    try:
        bootstrap=(app/'live-bootstrap.mjs').read_text(encoding='utf-8')
        if PATCH_ID not in bootstrap:
            import_anchor="import {readFile} from 'node:fs/promises';"
            bootstrap=replace_once(
                bootstrap,
                import_anchor,
                import_anchor+"\nimport {createInsightXWalletIntelligenceV1} from './src/insightx-wallet-intelligence.mjs'; // "+PATCH_ID,
                'live-bootstrap import'
            )
            base58_anchor="const BASE58=/^[1-9A-HJ-NP-Za-km-z]{32,44}$/;"
            bootstrap=replace_once(
                bootstrap,
                base58_anchor,
                base58_anchor+"\nconst __mfInsightXWalletIntelligenceV1=createInsightXWalletIntelligenceV1(); // "+PATCH_ID,
                'live-bootstrap service'
            )
            route_anchor="    const pathname=pathOf(req);"
            route_block=r'''    const pathname=pathOf(req);

    // MEMEFLOW_INSIGHTX_WALLET_INTELLIGENCE_V1
    // Supplemental/read-only. This wrapper never mutates canonical token data,
    // Score, State, holder RPC truth, or entry admission.
    if(req.method==='GET'&&pathname==='/api/insightx/config'){
      return json(res,200,__mfInsightXWalletIntelligenceV1.publicConfig());
    }
    if(req.method==='GET'&&pathname==='/api/insightx/wallet-intelligence'){
      let requestUrl;
      try{requestUrl=new URL(req.url,'http://local')}catch{return json(res,400,{ok:false,status:'INVALID_URL'})}
      const mint=String(requestUrl.searchParams.get('mint')||'').trim();
      if(!BASE58.test(mint))return json(res,400,{ok:false,status:'INVALID_MINT',message:'Valid Solana token mint is required.'});
      try{
        const payload=await __mfInsightXWalletIntelligenceV1.get(mint,{
          force:requestUrl.searchParams.get('refresh')==='1',
          compact:requestUrl.searchParams.get('compact')==='1'
        });
        return json(res,200,payload);
      }catch(error){
        return json(res,200,{
          ok:false,
          status:'INTEGRATION_ERROR',
          provider:'InsightX',
          mode:'shadow',
          scoreAuthority:false,
          mint,
          atlasUrl:__mfInsightXWalletIntelligenceV1.atlasUrl(mint),
          message:String(error?.message||error).slice(0,180)
        });
      }
    }
    // /MEMEFLOW_INSIGHTX_WALLET_INTELLIGENCE_V1'''
            bootstrap=replace_once(bootstrap,route_anchor,route_block,'live-bootstrap route')
            (app/'live-bootstrap.mjs').write_text(bootstrap,encoding='utf-8')
        else:
            print('live-bootstrap: integration marker already present; leaving existing integration unchanged')

        html=(app/'system-tokens.html').read_text(encoding='utf-8')
        css_tag='''\n<!-- MEMEFLOW_INSIGHTX_WALLET_INTELLIGENCE_UI_V1 -->\n<link rel="stylesheet" href="/memeflow-insightx-v1.css?v=insightx-wallet-intelligence-v1-20260913">\n'''
        js_tag='''\n<!-- MEMEFLOW_INSIGHTX_WALLET_INTELLIGENCE_UI_V1 -->\n<script src="/memeflow-insightx-v1.js?v=insightx-wallet-intelligence-v1-20260913" defer></script>\n'''
        if 'memeflow-insightx-v1.css' not in html:
            html=replace_once(html,'</head>',css_tag+'</head>','system-tokens css hook')
        if 'memeflow-insightx-v1.js' not in html:
            html=replace_once(html,'</body>',js_tag+'</body>','system-tokens js hook')
        (app/'system-tokens.html').write_text(html,encoding='utf-8')

        for rel in [
            'src/insightx-wallet-intelligence.mjs',
            'memeflow-insightx-v1.js','memeflow-insightx-v1.css',
            'tests/insightx-wallet-intelligence-v1.mjs','tests/insightx-ui-v1.mjs',
            'docs/INSIGHTX_WALLET_INTELLIGENCE_V1.md'
        ]:
            src=FILES/rel
            dst=app/rel
            dst.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,dst)

        last=app/'.memeflow-insightx-v1-last-backup'
        last.write_text(str(backup),encoding='utf-8')

        run(['node','--check','src/insightx-wallet-intelligence.mjs'],app)
        run(['node','--check','memeflow-insightx-v1.js'],app)
        run(['node','--check','live-bootstrap.mjs'],app)
        run(['node','tests/insightx-wallet-intelligence-v1.mjs'],app)
        run(['node','tests/insightx-ui-v1.mjs'],app)
        if (app.parent/'.git').exists() or (app/'.git').exists():
            repo=app.parent if (app.parent/'.git').exists() else app
            subprocess.run(['git','diff','--check'],cwd=repo,check=True)

        print('\nINSTALLATION VERIFICATION: PASS')
        print('Backup:',backup)
        print('Next: set INSIGHTX_API_KEY and INSIGHTX_ATLAS_EMBED_ID in Replit Secrets, then restart MEMEFLOW.')
    except Exception as exc:
        print('\nERROR:',exc,file=sys.stderr)
        print('Restoring backup automatically...',file=sys.stderr)
        restore(app,backup,manifest)
        raise

if __name__=='__main__':
    main()
