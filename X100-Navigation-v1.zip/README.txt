X100 Navigation v1

Adds exactly one item to the existing MEMEFLOW navigation drawer:

X100 Network
Architecture, tokenomics and economic model
/x100.html

Run from the existing project directory:
  bash install.sh

The installer only edits the existing memeflow-app/memeflow-nav.js file.
