#!/usr/bin/env python3
from pathlib import Path
import sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
nav = root / 'memeflow-app' / 'memeflow-nav.js'

if not nav.is_file():
    raise SystemExit(f'ERROR: expected existing file: {nav}')

text = nav.read_text(encoding='utf-8')

needle = "href: '/x100.html'"
if needle in text:
    if text.count(needle) != 1:
        raise SystemExit('ERROR: X100 navigation entry appears more than once')
    print('X100 navigation installation verification: PASS (already installed)')
    raise SystemExit(0)

anchor = """    // MEMEFLOW_PUBLIC_AGENT_PERFORMANCE_V1_NAV\n    {\n      href: '/agent-performance.html',\n      title: 'Agent Performance',\n      sub: 'Public platform results and outcome analytics'\n    }\n"""

entry = """    // MEMEFLOW_X100_NETWORK_NAV_V1\n    {\n      href: '/x100.html',\n      title: 'X100 Network',\n      sub: 'Architecture, tokenomics and economic model'\n    },\n"""

if anchor not in text:
    raise SystemExit('ERROR: navigation anchor not found; no file was changed')

updated = text.replace(anchor, entry + anchor, 1)

if updated.count(needle) != 1:
    raise SystemExit('ERROR: verification failed before write; no file was changed')

nav.write_text(updated, encoding='utf-8')

check = nav.read_text(encoding='utf-8')
required = [
    "href: '/x100.html'",
    "title: 'X100 Network'",
    "sub: 'Architecture, tokenomics and economic model'",
]
if not all(item in check for item in required) or check.count(needle) != 1:
    raise SystemExit('ERROR: X100 navigation installation verification failed')

print('X100 navigation installation verification: PASS')
