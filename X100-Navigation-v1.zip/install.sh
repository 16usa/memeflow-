#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$PWD}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -d "$ROOT/memeflow-app" ]]; then
  echo "ERROR: memeflow-app was not found in: $ROOT" >&2
  exit 1
fi

python3 "$SCRIPT_DIR/patch_nav.py" "$ROOT"
