# MEMEFLOW Premium Candlestick Market Chart

This patch upgrades the already-separated Market Chart to the requested trading-app layout while preserving MEMEFLOW's own visual system.

## What it adds

- Token/memecoin image
- Token name and metadata header
- Large live price block
- Professional green/red candlesticks
- Right-side price scale
- Current-price dotted line
- Existing intervals: `1s / 1m / 5m / 15m / 1h / All`
- Responsive mobile layout
- Existing backend, token switching, polling and chart data remain unchanged

The candlesticks are generated from the existing live price-series points. The patch does not create a second market-data request.

## Apply in Replit

Do **not** install the earlier small mobile hotfix. This patch already includes that cleanup.

Upload the ZIP to the project root, then run:

```bash
unzip -o MEMEFLOW_PREMIUM_CANDLESTICK_CHART_PATCH.zip
node scripts/premium-candlestick-chart.mjs
```

After `SUCCESS`, press **Stop → Run** in Replit.

## Roll back

```bash
cp memeflow-app/index.html.before-premium-candlestick-chart memeflow-app/index.html
```
