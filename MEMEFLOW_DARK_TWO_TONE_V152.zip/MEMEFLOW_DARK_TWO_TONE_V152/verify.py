#!/usr/bin/env python3
from __future__ import annotations

import re
import subprocess
import sys
from pathlib import Path

PATCH = "MEMEFLOW_DARK_TWO_TONE_V152"
APP = Path("memeflow-app")
CSS_REL = APP / "memeflow-dark-x-surface-v131.css"
PAGES = [
    APP / "system.html",
    APP / "system-tokens.html",
    APP / "trading.html",
    APP / "smart-vault.html",
    APP / "settings.html",
    APP / "how-it-works.html",
    APP / "agent-performance.html",
]
CACHE_TAG = "dark-two-tone-v152-20260919"
MARKER = "MEMEFLOW_DARK_TWO_TONE_SURFACE_V152"


def root() -> Path:
    try:
        return Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], text=True).strip())
    except Exception:
        print(f"[{PATCH}] FAIL: not inside the existing Git workspace", file=sys.stderr)
        raise SystemExit(1)


def check(condition: bool, message: str, failures: list[str]) -> None:
    if condition:
        print(f"PASS  {message}")
    else:
        print(f"FAIL  {message}")
        failures.append(message)


def main() -> None:
    repo = root()
    failures: list[str] = []
    css = (repo / CSS_REL).read_text(encoding="utf-8")

    check("--mf-x-dark-canvas: #101113;" in css, "base dark surface is #101113", failures)
    check("--mf-x-dark-inset: #181f27;" in css, "elevated dark surface is #181F27", failures)
    check("--mf-x-dark-canvas: #000000;" not in css, "black is removed from the canonical dark canvas token", failures)
    check("--mf-dark-surface-1: var(--mf-x-dark-canvas) !important;" in css, "surface-1 follows base tone", failures)
    check("--mf-dark-surface-2: var(--mf-x-dark-inset) !important;" in css, "surface-2 follows elevated tone", failures)
    check(MARKER in css and f"{MARKER}_END" in css, "late root/boot anti-black override is present", failures)

    exact_link = f'href="/memeflow-dark-x-surface-v131.css?v={CACHE_TAG}"'
    for rel in PAGES:
        html = (repo / rel).read_text(encoding="utf-8")
        check(html.count(exact_link) == 1, f"{rel.name}: cache-busted dark authority link", failures)
        dark_i = html.find(exact_link)
        qa_i = html.find("memeflow-final-visual-qa-v65.css")
        check(qa_i >= 0 and dark_i > qa_i, f"{rel.name}: dark authority loads after V65 canvas layer", failures)

    diff = subprocess.run(
        ["git", "diff", "--check", "--", str(CSS_REL), *[str(p) for p in PAGES]],
        cwd=repo,
        text=True,
        capture_output=True,
    )
    check(diff.returncode == 0, "git diff --check passes", failures)
    if diff.stdout.strip() or diff.stderr.strip():
        print((diff.stdout + diff.stderr).strip())

    if failures:
        print(f"\n[{PATCH}] VERIFY FAILED: {len(failures)} check(s)", file=sys.stderr)
        raise SystemExit(1)
    print(f"\n[{PATCH}] VERIFY PASS — no restart was performed.")


if __name__ == "__main__":
    main()
