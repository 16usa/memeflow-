#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
python3 "$HERE/apply.py"
python3 "$HERE/verify.py"
echo
echo "MEMEFLOW_DARK_TWO_TONE_V152 installed and verified."
echo "Server was NOT restarted. Restart it manually from the Replit console when you are ready."
