#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import re
import shutil
import subprocess
import sys
from pathlib import Path

PATCH = "MEMEFLOW_DARK_TWO_TONE_V152"
APP = Path("memeflow-app")
CSS_REL = APP / "memeflow-dark-x-surface-v131.css"
PAGES = [
    APP / "system.html",
    APP / "system-tokens.html",
    APP / "trading.html",
    APP / "smart-vault.html",
    APP / "settings.html",
    APP / "how-it-works.html",
    APP / "agent-performance.html",
]
MANAGED = [CSS_REL, *PAGES]
CACHE_TAG = "dark-two-tone-v152-20260919"
MARKER = "MEMEFLOW_DARK_TWO_TONE_SURFACE_V152"


def fail(message: str, code: int = 1) -> None:
    print(f"[{PATCH}] ERROR: {message}", file=sys.stderr)
    raise SystemExit(code)


def git_root() -> Path:
    try:
        out = subprocess.check_output(
            ["git", "rev-parse", "--show-toplevel"],
            text=True,
            stderr=subprocess.STDOUT,
        ).strip()
    except subprocess.CalledProcessError as exc:
        fail(f"Run this from the existing MemeFlow Git workspace. {exc.output.strip()}")
    return Path(out)


def ensure_clean_managed_files(root: Path) -> None:
    args = ["git", "status", "--porcelain", "--", *[str(p) for p in MANAGED]]
    dirty = subprocess.check_output(args, cwd=root, text=True).strip()
    if dirty:
        fail(
            "Patch-managed files have local changes. Nothing was overwritten. "
            "Push/stash those changes first, then run the patch again.\n" + dirty,
            2,
        )


def make_backup(root: Path) -> Path:
    stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = root / ".memeflow-backups" / f"dark-two-tone-v152-{stamp}"
    for rel in MANAGED:
        src = root / rel
        if not src.is_file():
            fail(f"Missing required file: {rel}")
        dst = backup / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
    (root / ".memeflow-dark-two-tone-v152-last-backup").write_text(
        str(backup.relative_to(root)) + "\n", encoding="utf-8"
    )
    return backup


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        fail(f"Expected exactly one {label}; found {count}. Source changed, so patch stopped safely.")
    return text.replace(old, new, 1)


def patch_css(root: Path) -> None:
    path = root / CSS_REL
    css = path.read_text(encoding="utf-8")

    if MARKER in css:
        print(f"[{PATCH}] CSS marker already present; keeping existing V152 block.")
        return

    css = replace_once(
        css,
        "--mf-x-dark-canvas: #000000;",
        "--mf-x-dark-canvas: #101113;",
        "current dark canvas token",
    )
    css = replace_once(
        css,
        "--mf-x-dark-inset: #101113;",
        "--mf-x-dark-inset: #181f27;",
        "current dark inset token",
    )

    # Keep the source-of-truth comments aligned with the new two-tone contract.
    comment_replacements = {
        "     Canvas / large modules   #000000": "     Canvas / large modules   #101113",
        "     Neutral inset / control  #101113": "     Neutral inset / control  #181F27",
        "   Large structural modules no longer use the old #0C1117 fill. They sit on\n   the black canvas and are separated by one restrained X-style 1px outline.":
            "   True black is intentionally removed from the app surface hierarchy.\n   Large structural modules use #101113; elevated/inset surfaces use #181F27.",
        "/* Keep every audited page on the true black canvas. */":
            "/* Keep every audited page on the non-black #101113 base surface. */",
        "   Black fill + existing radius + one subtle X outline.":
            "   #101113 fill + existing radius + one subtle X outline.",
        "  /* Replace the old lightest dark neutral (#181F27) with the approved X tone. */":
            "  /* Elevated / inset neutral: the second and only other dark surface tone. */",
        "     canvas / large modules  #000000\n     third neutral           #101113":
            "     canvas / large modules  #101113\n     inset / control          #181F27",
    }
    for old, new in comment_replacements.items():
        if old in css:
            css = css.replace(old, new, 1)

    css += f"""

/* ==========================================================================
   {MARKER}

   Final DARK neutral surface authority.

   User-approved two-tone hierarchy:
     base / large modules     #101113
     elevated / inset         #181F27
     outline / divider        #2F3336

   True black is not used as the page/module canvas. This late block also
   overrides the earlier V135 root/boot #000000 fallback so Safari overscroll
   and the boot surface cannot flash black. Light mode, semantic status colors,
   layout, radii, 3D/WebGL scene content and application logic are untouched.
   ========================================================================== */

html[data-theme="dark"],
html[data-theme="dark"] body {{
  background-color: var(--mf-x-dark-canvas) !important;
  background-image: none !important;
}}

html[data-theme="dark"] body .boot {{
  background: var(--mf-x-dark-canvas) !important;
  background-image: none !important;
}}

/* {MARKER}_END */
"""
    path.write_text(css, encoding="utf-8")


def bust_cache(root: Path) -> None:
    pattern = re.compile(r'href="/memeflow-dark-x-surface-v131\.css(?:\?v=[^"]*)?"')
    replacement = f'href="/memeflow-dark-x-surface-v131.css?v={CACHE_TAG}"'
    for rel in PAGES:
        path = root / rel
        html = path.read_text(encoding="utf-8")
        html2, count = pattern.subn(replacement, html)
        if count != 1:
            fail(f"Expected one dark authority stylesheet link in {rel}; found {count}.")
        path.write_text(html2, encoding="utf-8")


def main() -> None:
    root = git_root()
    ensure_clean_managed_files(root)
    backup = make_backup(root)
    patch_css(root)
    bust_cache(root)
    print(f"[{PATCH}] Backup: {backup.relative_to(root)}")
    print(f"[{PATCH}] Applied. No server/process restart was executed.")


if __name__ == "__main__":
    main()
