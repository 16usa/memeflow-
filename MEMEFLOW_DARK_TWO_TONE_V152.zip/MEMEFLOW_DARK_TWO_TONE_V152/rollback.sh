#!/usr/bin/env bash
set -euo pipefail
ROOT="$(git rev-parse --show-toplevel)"
MARKER="$ROOT/.memeflow-dark-two-tone-v152-last-backup"
if [[ ! -f "$MARKER" ]]; then
  echo "No V152 backup marker found: $MARKER" >&2
  exit 1
fi
REL="$(tr -d '\r\n' < "$MARKER")"
BACKUP="$ROOT/$REL"
[[ -d "$BACKUP" ]] || { echo "Backup directory not found: $BACKUP" >&2; exit 1; }
FILES=(
  memeflow-app/memeflow-dark-x-surface-v131.css
  memeflow-app/system.html
  memeflow-app/system-tokens.html
  memeflow-app/trading.html
  memeflow-app/smart-vault.html
  memeflow-app/settings.html
  memeflow-app/how-it-works.html
  memeflow-app/agent-performance.html
)
for f in "${FILES[@]}"; do
  [[ -f "$BACKUP/$f" ]] || { echo "Missing backup file: $BACKUP/$f" >&2; exit 1; }
  cp -p "$BACKUP/$f" "$ROOT/$f"
done
echo "V152 files restored from $REL"
echo "Server was NOT restarted."
