(() => {
  'use strict';
  if (window.__MEMEFLOW_AI_STANDALONE_V51__) return;
  window.__MEMEFLOW_AI_STANDALONE_V51__ = true;

  const $ = (s, root=document) => root.querySelector(s);
  const $$ = (s, root=document) => [...root.querySelectorAll(s)];
  const state = {
    busy: false,
    auto: false,
    scan: null,
    api: { configured: null, model: 'OpenAI', quota: 'unknown' }
  };

  const fmt = {
    pct(v){ return Number.isFinite(Number(v)) ? `${Number(v).toFixed(1)}%` : '—'; },
    ratio(v){ return Number.isFinite(Number(v)) ? `${Number(v).toFixed(2)}×` : '—'; },
    usd(v){
      const n=Number(v);
      if(!Number.isFinite(n)) return '—';
      if(Math.abs(n)>=1e9) return `$${(n/1e9).toFixed(2)}B`;
      if(Math.abs(n)>=1e6) return `$${(n/1e6).toFixed(2)}M`;
      if(Math.abs(n)>=1e3) return `$${(n/1e3).toFixed(1)}K`;
      if(Math.abs(n)>=1) return `$${n.toFixed(2)}`;
      return `$${n.toPrecision(3)}`;
    },
    sol(v){
      const n=Number(v);
      if(!Number.isFinite(n)) return '—';
      if(Math.abs(n)>=1e6) return `${(n/1e6).toFixed(2)}M SOL`;
      if(Math.abs(n)>=1e3) return `${(n/1e3).toFixed(1)}K SOL`;
      return `${n.toFixed(n<1?4:2)} SOL`;
    },
    compact(v){
      const n=Number(v);
      if(!Number.isFinite(n)) return '—';
      if(Math.abs(n)>=1e9) return `${(n/1e9).toFixed(1)}B`;
      if(Math.abs(n)>=1e6) return `${(n/1e6).toFixed(1)}M`;
      if(Math.abs(n)>=1e3) return `${(n/1e3).toFixed(1)}K`;
      return String(Math.round(n));
    }
  };

  function shortMint(v=''){
    const s=String(v||'').trim();
    return s.length>16 ? `${s.slice(0,7)}…${s.slice(-5)}` : s;
  }

  function cleanLegacy(){
    [
      '#sheet-ai-direct-v24','#ai-direct-v24','#openai-assistant-modal',
      '#memeflow-ai-overlay','#mf-ai-floating-button','#aiFloatingButton','#openAiFloatingButton'
    ].forEach(sel => $(sel)?.remove());

    $$('[data-legacy-openai="true"],[data-mf-ai-runtime="legacy"],.ai-floating-button,.openai-floating-button')
      .forEach(el => el.remove());

    // Remove only orphaned small fixed "AI" buttons outside the native nav/sheet.
    $$('button').forEach(btn => {
      if (btn.closest('.mobile-nav') || btn.closest('#sheet-ai')) return;
      if ((btn.textContent||'').trim() !== 'AI') return;
      const cs=getComputedStyle(btn),r=btn.getBoundingClientRect();
      if((cs.position==='fixed'||cs.position==='absolute')&&r.width<=140&&r.height<=140) btn.remove();
    });
  }

  function installStyles(){
    $('#mf-ai-v51-style')?.remove();
    const style=document.createElement('style');
    style.id='mf-ai-v51-style';
    style.textContent=`
      #sheet-ai{background:#070a0f}
      #sheet-ai .sheet-top{margin-bottom:7px!important}
      #sheet-ai .sheet-top h2{font-size:18px!important;letter-spacing:-.025em}

      #sheet-ai .mf49-shell{
        max-width:780px;
        margin:0 auto;
        display:grid;
        grid-template-rows:auto auto auto auto;
        gap:8px;
        min-height:0;
        height:auto;
      }

      #sheet-ai .mf49-card{
        border:1px solid var(--line,#1c2a38);
        background:linear-gradient(180deg,rgba(14,24,35,.97),rgba(8,15,23,.985));
        border-radius:14px;
      }

      #sheet-ai .mf49-control{padding:10px}
      #sheet-ai .mf49-topline{
        display:flex;align-items:center;justify-content:space-between;gap:8px;
        margin-bottom:8px
      }
      #sheet-ai .mf49-kicker{
        color:var(--cyan,#54ddff);font-size:8px;font-weight:900;
        letter-spacing:.14em;text-transform:uppercase;white-space:nowrap
      }
      #sheet-ai .mf49-chips{display:flex;align-items:center;gap:5px;min-width:0}
      #sheet-ai .mf49-chip{
        display:inline-flex;align-items:center;gap:5px;min-height:27px;
        padding:5px 8px;border:1px solid var(--line,#1c2a38);border-radius:999px;
        background:rgba(255,255,255,.018);font-size:8px;color:#aeb9c7;white-space:nowrap
      }
      #sheet-ai button.mf49-chip{cursor:pointer;font:inherit}
      #sheet-ai .mf49-chip b{color:#dce5ee;max-width:110px;overflow:hidden;text-overflow:ellipsis}
      #sheet-ai .mf49-chip.good{color:var(--green,#51e7a8);border-color:rgba(81,231,168,.35)}
      #sheet-ai .mf49-chip.warn{color:var(--yellow,#f6c75f);border-color:rgba(246,199,95,.35)}
      #sheet-ai .mf49-chip.bad{color:var(--red,#ff6576);border-color:rgba(255,101,118,.38)}

      #sheet-ai .mf49-scan-row{
        display:grid;grid-template-columns:minmax(0,1fr) 112px;gap:7px;align-items:stretch
      }
      #sheet-ai .mf49-input{
        width:100%;min-width:0;height:44px;border:1px solid var(--line2,#2a3b4b);
        border-radius:11px;background:#09111a;color:var(--text,#f3f7fb);
        padding:0 11px;font:inherit;font-size:16px;outline:none
      }
      #sheet-ai .mf49-input:focus,#sheet-ai .mf49-question:focus{
        border-color:rgba(84,221,255,.55);box-shadow:0 0 0 3px rgba(84,221,255,.07)
      }
      #sheet-ai .mf49-input::placeholder,#sheet-ai .mf49-question::placeholder{color:#768598}

      #sheet-ai .mf49-btn{
        min-height:40px;border:1px solid var(--line2,#2a3b4b);border-radius:11px;
        background:#111a24;color:#eaf0f6;font:inherit;font-size:10px;font-weight:850;
        cursor:pointer;padding:7px 9px
      }
      #sheet-ai .mf49-btn.primary{
        background:var(--cyan,#54ddff);border-color:var(--cyan,#54ddff);color:#031017
      }
      #sheet-ai .mf49-btn.active{
        color:var(--green,#51e7a8);border-color:rgba(81,231,168,.48);
        background:rgba(81,231,168,.07)
      }
      #sheet-ai .mf49-btn:disabled{opacity:.5;cursor:not-allowed}

      #sheet-ai .mf49-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px}

      #sheet-ai .mf49-result{
        min-height:116px;
        height:auto;
        max-height:min(44dvh,430px);
        padding:10px 11px;
        display:grid;
        grid-template-rows:auto auto auto auto;
        gap:7px;
        overflow:hidden
      }
      #sheet-ai .mf49-result-head{
        display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center
      }
      #sheet-ai .mf49-token-name{
        min-width:0;font-size:13px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis
      }
      #sheet-ai .mf49-token-sub{
        color:var(--muted,#8e9daf);font-size:8px;margin-top:2px;
        white-space:nowrap;overflow:hidden;text-overflow:ellipsis
      }
      #sheet-ai .mf49-verdict{
        display:inline-flex;align-items:center;gap:7px;justify-content:flex-end;
        font-size:10px;font-weight:900;white-space:nowrap
      }
      #sheet-ai .mf49-verdict .score{
        display:inline-grid;place-items:center;min-width:33px;height:27px;padding:0 7px;
        border:1px solid var(--line,#1c2a38);border-radius:9px;color:#fff
      }
      #sheet-ai .mf49-verdict.buy{color:var(--green,#51e7a8)}
      #sheet-ai .mf49-verdict.watch,#sheet-ai .mf49-verdict.wait{color:var(--yellow,#f6c75f)}
      #sheet-ai .mf49-verdict.block{color:var(--red,#ff6576)}

      #sheet-ai .mf49-metrics{
        display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:5px
      }
      #sheet-ai .mf49-metric{
        min-width:0;border:1px solid var(--line,#1c2a38);border-radius:9px;
        background:rgba(255,255,255,.016);padding:7px 8px
      }
      #sheet-ai .mf49-metric small{
        display:block;color:var(--muted,#8e9daf);font-size:7px;letter-spacing:.07em;text-transform:uppercase
      }
      #sheet-ai .mf49-metric b{
        display:block;margin-top:3px;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis
      }

      #sheet-ai .mf49-reason{
        border-left:2px solid var(--yellow,#f6c75f);
        padding:6px 8px;background:rgba(246,199,95,.045);border-radius:0 8px 8px 0;
        font-size:9px;line-height:1.35;color:#cbd5df;min-width:0
      }
      #sheet-ai .mf49-reason.buy{border-left-color:var(--green,#51e7a8);background:rgba(81,231,168,.045)}
      #sheet-ai .mf49-reason.block{border-left-color:var(--red,#ff6576);background:rgba(255,101,118,.045)}

      #sheet-ai .mf49-detail{
        min-height:0;
        height:auto;
        max-height:min(28dvh,260px);
        overflow:auto;
        overscroll-behavior:contain;
        color:#9dabbc;
        font-size:9px;
        line-height:1.45;
        padding-right:2px
      }
      #sheet-ai .mf49-detail strong{color:#dbe4ed}
      #sheet-ai .mf49-empty{
        display:block;
        text-align:center;
        color:var(--muted,#8e9daf);
        min-height:0;
        border:1px dashed var(--line,#1c2a38);
        border-radius:10px;
        padding:12px 14px;
      }
      #sheet-ai .mf49-ai-note{
        margin-top:6px;padding-top:6px;border-top:1px solid var(--line,#1c2a38);
        color:#c2ccd7;white-space:pre-wrap
      }
      #sheet-ai .mf49-ai-note.error{color:#ff8996}

      #sheet-ai .mf49-ask{padding:8px}
      #sheet-ai .mf49-ask-row{
        display:grid;grid-template-columns:minmax(0,1fr) 74px;gap:7px;align-items:stretch
      }
      #sheet-ai .mf49-question{
        width:100%;min-width:0;height:46px;resize:none;border:1px solid var(--line2,#2a3b4b);
        border-radius:10px;background:#09111a;color:var(--text,#f3f7fb);
        padding:8px 10px;font:inherit;font-size:16px;line-height:1.25;outline:none
      }

      @media(max-width:820px){
        #sheet-ai{
          overflow:auto!important;
          overscroll-behavior:contain!important;
          -webkit-overflow-scrolling:touch;
          padding-bottom:calc(84px + env(safe-area-inset-bottom,0px))!important
        }
        #sheet-ai .mf49-shell{
          height:auto;
          max-height:none;
          overflow:visible
        }
        #sheet-ai .mf49-result{
          min-height:108px;
          max-height:min(42dvh,360px)
        }
        #sheet-ai .mf49-detail{
          max-height:min(25dvh,220px)
        }
      }

      @media(max-width:430px){
        #sheet-ai .mf49-control{padding:9px}
        #sheet-ai .mf49-topline{margin-bottom:7px}
        #sheet-ai .mf49-chip{padding:5px 7px}
        #sheet-ai .mf49-chip.model{display:none}
        #sheet-ai .mf49-scan-row{grid-template-columns:minmax(0,1fr) 94px;gap:6px}
        #sheet-ai .mf49-input{height:42px;font-size:16px}
        #sheet-ai .mf49-btn{min-height:38px;padding:6px 7px}
        #sheet-ai .mf49-result{padding:8px 9px;gap:6px}
        #sheet-ai .mf49-metric{padding:6px 7px}
        #sheet-ai .mf49-question{height:43px;font-size:16px}
        #sheet-ai .mf49-ask{padding:7px}
      }



      /* ===== V51 compact MEMEFLOW-native OpenAI UI ===== */
      #sheet-ai .mf51-sheet-top{
        margin-bottom:8px!important;
      }
      #sheet-ai .mf51-sheet-top h2{
        font-size:18px!important;
        letter-spacing:-.025em;
      }

      #sheet-ai .mf51-shell{
        gap:7px!important;
      }

      #sheet-ai .mf51-control,
      #sheet-ai .mf51-result,
      #sheet-ai .mf51-ask{
        border:1px solid rgba(41,57,74,.76)!important;
        background:linear-gradient(180deg,rgba(14,20,28,.96),rgba(8,12,17,.98))!important;
        border-radius:14px!important;
        box-shadow:none!important;
      }

      #sheet-ai .mf51-control{
        padding:9px!important;
      }

      #sheet-ai .mf51-status-row{
        display:flex;
        align-items:center;
        gap:7px;
        min-height:25px;
        margin-bottom:7px;
      }

      #sheet-ai .mf51-ai-status{
        appearance:none;
        display:inline-flex;
        align-items:center;
        gap:6px;
        min-height:25px;
        padding:4px 8px;
        border:1px solid var(--line,#1d2936);
        border-radius:999px;
        background:rgba(7,11,16,.72);
        color:#9aa7b6;
        font:inherit;
        font-size:8.5px;
        font-weight:850;
        letter-spacing:.035em;
        white-space:nowrap;
        cursor:pointer;
      }
      #sheet-ai .mf51-ai-status i{
        width:6px;height:6px;border-radius:50%;
        background:var(--yellow,#f6c75f);
        box-shadow:0 0 8px rgba(246,199,95,.45);
        flex:0 0 auto;
      }
      #sheet-ai .mf51-ai-status.good{
        color:#b9c6d2;
        border-color:rgba(81,231,168,.25);
      }
      #sheet-ai .mf51-ai-status.good i{
        background:var(--green,#51e7a8);
        box-shadow:0 0 9px rgba(81,231,168,.55);
      }
      #sheet-ai .mf51-ai-status.bad{
        color:#c5a5aa;
        border-color:rgba(255,101,118,.28);
      }
      #sheet-ai .mf51-ai-status.bad i{
        background:var(--red,#ff6576);
        box-shadow:0 0 8px rgba(255,101,118,.45);
      }

      #sheet-ai .mf51-mode{
        display:inline-flex;
        align-items:center;
        gap:5px;
        min-height:25px;
        padding:4px 8px;
        border:1px solid var(--line,#1d2936);
        border-radius:999px;
        color:#6f7c8c;
        font-size:7.5px;
        letter-spacing:.07em;
        white-space:nowrap;
      }
      #sheet-ai .mf51-mode b{
        color:#b8c3cf;
        font-size:8.5px;
        letter-spacing:.03em;
      }
      #sheet-ai .mf51-model{display:none!important}

      #sheet-ai .mf51-scan-row{
        grid-template-columns:minmax(0,1fr) 104px!important;
        gap:7px!important;
      }
      #sheet-ai .mf51-input{
        height:42px!important;
        min-height:42px!important;
        padding:0 10px!important;
        border-radius:10px!important;
        border-color:var(--line2,#29394a)!important;
        background:#081019!important;
        font-size:16px!important; /* prevents iOS focus zoom */
      }
      #sheet-ai .mf51-input::placeholder{
        color:#738195!important;
        font-size:11px!important;
        opacity:1;
      }

      #sheet-ai .mf51-primary{
        min-height:42px!important;
        height:42px!important;
        border-radius:10px!important;
        font-size:10px!important;
        font-weight:900!important;
        letter-spacing:0!important;
      }

      #sheet-ai .mf51-actions{
        gap:7px!important;
      }
      #sheet-ai .mf51-actions .mf49-btn{
        min-height:36px!important;
        height:36px!important;
        border-radius:10px!important;
        background:#101720!important;
        border-color:var(--line2,#29394a)!important;
        font-size:9.5px!important;
      }
      #sheet-ai .mf51-actions .mf49-btn.active{
        color:var(--green,#51e7a8)!important;
        border-color:rgba(81,231,168,.34)!important;
        background:rgba(81,231,168,.055)!important;
      }

      #sheet-ai .mf51-result{
        min-height:76px!important;
        height:auto!important;
        max-height:min(38dvh,330px)!important;
        padding:9px!important;
      }
      #sheet-ai .mf51-empty{
        border:0!important;
        padding:10px 6px!important;
        text-align:left!important;
        color:#748295!important;
        font-size:9px!important;
        line-height:1.45!important;
      }
      #sheet-ai .mf51-detail{
        font-size:9px!important;
        max-height:min(22dvh,190px)!important;
      }

      #sheet-ai .mf51-ask{
        padding:7px!important;
      }
      #sheet-ai .mf51-ask-row{
        grid-template-columns:minmax(0,1fr) 74px!important;
        gap:7px!important;
        align-items:end!important;
      }
      #sheet-ai .mf51-question{
        min-height:42px!important;
        height:42px;
        max-height:78px!important;
        padding:10px!important;
        border-radius:10px!important;
        border-color:var(--line2,#29394a)!important;
        background:#081019!important;
        font-size:16px!important; /* prevents iOS focus zoom */
        line-height:1.25!important;
        overflow-y:auto!important;
      }
      #sheet-ai .mf51-question::placeholder{
        color:#738195!important;
        font-size:11px!important;
        line-height:1.2!important;
        opacity:1;
      }

      @media(max-width:430px){
        #sheet-ai .mf51-scan-row{
          grid-template-columns:minmax(0,1fr) 92px!important;
          gap:6px!important;
        }
        #sheet-ai .mf51-primary{
          font-size:9px!important;
          padding:5px 7px!important;
        }
        #sheet-ai .mf51-ask-row{
          grid-template-columns:minmax(0,1fr) 66px!important;
          gap:6px!important;
        }
        #sheet-ai .mf51-ai-status{
          font-size:8px!important;
          padding:4px 7px!important;
        }
        #sheet-ai .mf51-mode{
          margin-left:auto;
        }
      }


            /* V50: iOS focus stability + compact adaptive result */
      #sheet-ai input,
      #sheet-ai textarea,
      #sheet-ai select{
        font-size:16px!important;
        -webkit-text-size-adjust:100%;
      }
      #sheet-ai .mf49-result{
        transition:max-height .18s ease,border-color .18s ease;
      }
      @supports (-webkit-touch-callout:none){
        #sheet-ai .mf49-input,
        #sheet-ai .mf49-question{
          font-size:16px!important;
          transform:none!important;
          zoom:1!important;
        }
      }

      @media(max-height:740px) and (max-width:820px){
        #sheet-ai .sheet-top{margin-bottom:4px!important}
        #sheet-ai .mf49-shell{
          height:auto;
          max-height:none;
          gap:6px
        }
        #sheet-ai .mf49-kicker{display:none}
        #sheet-ai .mf49-topline{margin-bottom:5px}
        #sheet-ai .mf49-control{padding:7px 8px}
        #sheet-ai .mf49-chip{min-height:24px;padding:4px 7px}
        #sheet-ai .mf49-input{height:38px;font-size:16px}
        #sheet-ai .mf49-btn{min-height:34px}
        #sheet-ai .mf49-result{padding:7px 8px}
        #sheet-ai .mf49-metric{padding:5px 6px}
        #sheet-ai .mf49-ask{padding:6px}
        #sheet-ai .mf49-question{height:38px;padding:6px 8px;font-size:16px}
      }

      #sheet-ai .mf51-input::placeholder,
      #sheet-ai .mf51-question::placeholder{
        font-size:11px!important;
        color:#738195!important;
        opacity:1!important;
      }

    `;
    document.head.appendChild(style);
  }

  function ensureSheet(){
    let sheet=$('#sheet-ai');
    if(!sheet){
      sheet=document.createElement('div');
      sheet.id='sheet-ai';
      sheet.className='mobile-sheet';
      const more=$('#sheet-more');
      if(more?.parentNode) more.parentNode.insertBefore(sheet,more);
      else document.body.appendChild(sheet);
    }

    // Critical V51 fix: do NOT rebuild the sheet on every open.
    // V49/V50 openSheet() called ensureSheet(), which rewrote innerHTML and destroyed
    // the click handlers that had been attached during install().
    if(sheet.dataset.mf51Built==='1') return sheet;

    sheet.innerHTML=`
      <div class="sheet-top mf51-sheet-top">
        <h2>MEMEFLOW OpenAI</h2>
        <button class="close-sheet" id="mf49Close" type="button" aria-label="Close MEMEFLOW OpenAI">×</button>
      </div>

      <div class="mf49-shell mf51-shell">
        <section class="mf49-card mf49-control mf51-control">
          <div class="mf51-status-row">
            <button class="mf51-ai-status warn" id="mf49ApiChip" type="button" aria-label="Check AI status">
              <i aria-hidden="true"></i><span id="mf49Api">CHECKING</span>
            </button>
            <span class="mf51-mode">MODE <b id="mf49Mode">MANUAL</b></span>
            <span id="mf49Model" class="mf51-model" aria-hidden="true">OpenAI</span>
          </div>

          <div class="mf49-scan-row mf51-scan-row">
            <input class="mf49-input mf51-input" id="mf49TokenInput" type="text"
              inputmode="text" autocomplete="off" autocapitalize="off" spellcheck="false"
              placeholder="Mint, Pump.fun or DexScreener link" />
            <button class="mf49-btn primary mf51-primary" id="mf49Scan" type="button">Analyze</button>
          </div>
        </section>

        <div class="mf49-actions mf51-actions">
          <button class="mf49-btn" id="mf49Auto" type="button" aria-pressed="false">Auto AI</button>
          <button class="mf49-btn" id="mf49Strategy" type="button">Strategy</button>
        </div>

        <section class="mf49-card mf49-result mf51-result" id="mf49ResultBox" aria-live="polite">
          <div id="mf49ResultHead" class="mf49-result-head" hidden>
            <div>
              <div class="mf49-token-name" id="mf49TokenName">Token</div>
              <div class="mf49-token-sub" id="mf49TokenSub">—</div>
            </div>
            <div class="mf49-verdict wait" id="mf49Verdict">
              <span id="mf49State">WAITING</span><span class="score" id="mf49Score">—</span>
            </div>
          </div>

          <div class="mf49-metrics" id="mf49Metrics" hidden>
            <div class="mf49-metric"><small>Market cap</small><b id="mf49Mc">—</b></div>
            <div class="mf49-metric"><small>Liquidity</small><b id="mf49Liq">—</b></div>
            <div class="mf49-metric"><small>Holders</small><b id="mf49Holders">—</b></div>
            <div class="mf49-metric"><small>Top 10</small><b id="mf49Top10">—</b></div>
            <div class="mf49-metric"><small>Buy pressure</small><b id="mf49Buy">—</b></div>
            <div class="mf49-metric"><small>Developer</small><b id="mf49Dev">—</b></div>
          </div>

          <div class="mf49-reason" id="mf49Reason" hidden></div>

          <div class="mf49-detail mf51-detail" id="mf49Detail">
            <div class="mf49-empty mf51-empty">Token analysis will appear here.</div>
          </div>
        </section>

        <section class="mf49-card mf49-ask mf51-ask">
          <div class="mf49-ask-row mf51-ask-row">
            <textarea class="mf49-question mf51-question" id="mf49Question" rows="1"
              autocomplete="off" autocapitalize="sentences"
              placeholder="Ask AI about the scanned token…"></textarea>
            <button class="mf49-btn primary mf51-primary" id="mf49Ask" type="button">Ask</button>
          </div>
        </section>
      </div>
    `;
    sheet.dataset.mf51Built='1';
    return sheet;
  }

  function ensureCenterButton(){
    const nav=$('.mobile-nav');
    if(!nav) return null;
    let ai=$('#mf-ai-center-nav-v24');
    if(!ai){
      ai=document.createElement('button');
      ai.id='mf-ai-center-nav-v24';
      const positions=$('[data-sheet="positions"]',nav);
      nav.insertBefore(ai,positions||null);
    }
    ai.type='button';
    ai.dataset.sheet='ai';
    ai.setAttribute('aria-label','MEMEFLOW OpenAI');
    ai.innerHTML='<span class="mf-ai-center-star" aria-hidden="true">✦</span><span class="mf-ai-center-label">AI</span>';
    return ai;
  }

  function setApi(text,kind='warn'){
    const chip=$('#mf49ApiChip'),label=$('#mf49Api');
    const raw=String(text||'').toUpperCase();
    let display=raw;
    if(raw==='KEY FOUND'||raw==='READY') display='AI READY';
    if(raw==='NO KEY') display='AI OFFLINE';
    if(raw==='UNAVAILABLE'||raw==='API ERROR') display='AI ERROR';
    if(raw==='NO CREDITS') display='NO CREDITS';
    if(raw==='CHECKING') display='CHECKING';

    if(label) label.textContent=display;
    if(chip){
      chip.classList.remove('good','warn','bad');
      chip.classList.add(kind);
    }
  }

  function setBusy(on,label=''){
    state.busy=on;
    ['mf49Scan','mf49Ask','mf49Strategy'].forEach(id=>{
      const el=$('#'+id); if(el) el.disabled=on;
    });
    if(label && $('#mf49Detail') && !state.scan){
      $('#mf49Detail').innerHTML=`<div class="mf49-empty">${label}</div>`;
    }
  }

  async function fetchJson(url,options={}){
    const controller=new AbortController();
    const timeout=setTimeout(()=>controller.abort(),20000);
    try{
      const r=await fetch(url,{
        credentials:'include',
        cache:'no-store',
        ...options,
        signal:options.signal||controller.signal,
        headers:{accept:'application/json',...(options.headers||{})}
      });
      const data=await r.json().catch(()=>({}));
      if(!r.ok){
        const message=data.message||data.error||`HTTP ${r.status}`;
        const e=new Error(message);
        e.status=r.status;
        e.payload=data;
        throw e;
      }
      return data;
    }catch(e){
      if(e?.name==='AbortError'){
        const timeoutError=new Error('Request timed out. Check RPC/server status and try again.');
        timeoutError.status=408;
        throw timeoutError;
      }
      throw e;
    }finally{
      clearTimeout(timeout);
    }
  }

  async function post(url,body){
    return fetchJson(url,{
      method:'POST',
      headers:{'content-type':'application/json'},
      body:JSON.stringify(body)
    });
  }

  async function checkApi(show=false){
    setApi('CHECKING','warn');
    try{
      const s=await fetchJson('/api/openai/status');
      state.api.configured=Boolean(s.configured);
      state.api.model=s.model||'OpenAI';
      $('#mf49Model').textContent=state.api.model;
      if(s.configured){
        setApi(state.api.quota==='ok'?'READY':'KEY FOUND','good');
        if(show) setNarrative(`OpenAI key is configured. Model: ${state.api.model}. Token scanning itself does not require OpenAI credits.`);
      }else{
        setApi('NO KEY','bad');
        if(show) setNarrative('OPENAI_API_KEY is not configured in Replit Secrets.',true);
      }
      return s;
    }catch(e){
      setApi('UNAVAILABLE','bad');
      if(show) setNarrative(e.message,true);
      return null;
    }
  }

  function classifyAiError(message=''){
    const m=String(message||'');
    if(/no credits|insufficient_quota|quota|billing/i.test(m)) return 'NO CREDITS';
    if(/OPENAI_API_KEY|not configured|missing.*key/i.test(m)) return 'NO KEY';
    if(/timeout|timed out/i.test(m)) return 'TIMEOUT';
    return 'API ERROR';
  }

  function setNarrative(text,isError=false){
    const detail=$('#mf49Detail');
    if(!detail) return;
    let note=$('#mf49AiNote');
    if(!note){
      note=document.createElement('div');
      note.id='mf49AiNote';
      note.className='mf49-ai-note';
      detail.appendChild(note);
    }
    note.classList.toggle('error',Boolean(isError));
    note.textContent=String(text||'');
  }

  function handleAiError(e){
    const kind=classifyAiError(e?.message||e);
    if(kind==='NO CREDITS'){
      state.api.quota='empty';
      setApi('NO CREDITS','bad');
      setNarrative('OpenAI API credits are exhausted. The token scan above still works independently; add API credits only for AI narrative/questions.',true);
      return;
    }
    if(kind==='NO KEY'){
      setApi('NO KEY','bad');
      setNarrative('OPENAI_API_KEY is not configured. The independent token scan still works without it.',true);
      return;
    }
    setApi(kind,'bad');
    setNarrative(e?.message||String(e),true);
  }

  function verdictClass(v=''){
    const s=String(v).toUpperCase();
    if(s.includes('BUY')) return 'buy';
    if(s.includes('BLOCK')) return 'block';
    if(s.includes('WATCH')) return 'watch';
    return 'wait';
  }

  function renderScan(scan){
    state.scan=scan;
    const ev=scan.evaluation||{},m=scan.market||{},on=scan.onchain||{};
    $('#mf49ResultHead').hidden=false;
    $('#mf49Metrics').hidden=false;
    $('#mf49Reason').hidden=false;

    $('#mf49TokenName').textContent =
      [scan.symbol,scan.name].filter(Boolean).join(' · ') || shortMint(scan.mint) || 'Solana token';

    const price = Number.isFinite(Number(m.priceUsd)) ? fmt.usd(m.priceUsd)
      : Number.isFinite(Number(m.priceSol)) ? fmt.sol(m.priceSol) : 'Price —';

    $('#mf49TokenSub').textContent=`${shortMint(scan.mint)} · ${price}`;

    const v=$('#mf49Verdict');
    v.className=`mf49-verdict ${verdictClass(ev.state)}`;
    $('#mf49State').textContent=ev.state||'WAITING';
    $('#mf49Score').textContent=Number.isFinite(Number(ev.score))?String(ev.score):'—';

    $('#mf49Mc').textContent=Number.isFinite(Number(m.marketCapUsd))?fmt.usd(m.marketCapUsd):
      Number.isFinite(Number(m.marketCapSol))?fmt.sol(m.marketCapSol):'—';
    $('#mf49Liq').textContent=Number.isFinite(Number(m.liquidityUsd))?fmt.usd(m.liquidityUsd):
      Number.isFinite(Number(m.liquiditySol))?fmt.sol(m.liquiditySol):'—';
    $('#mf49Holders').textContent=on.holderCountDisplay ?? '—';
    $('#mf49Top10').textContent=fmt.pct(on.top10Pct);
    $('#mf49Buy').textContent=fmt.ratio(m.buyPressure);
    $('#mf49Dev').textContent=fmt.pct(on.developerPct);

    const reason=$('#mf49Reason');
    reason.className=`mf49-reason ${verdictClass(ev.state)}`;
    reason.textContent=ev.primaryReason||'Evaluation complete.';

    const detail=$('#mf49Detail');
    const warnings=(scan.warnings||[]).slice(0,3);
    const pieces=[
      `<strong>Confidence ${Number.isFinite(Number(ev.confidence))?ev.confidence:'—'}%</strong>`,
      `5m volume ${fmt.usd(m.volume5mUsd)}`,
      `5m tx ${fmt.compact(m.buys5m)} buys / ${fmt.compact(m.sells5m)} sells`,
      `Source ${(scan.sources||[]).join(' + ')||'available data'}`
    ];
    if(warnings.length) pieces.push(`Notes ${warnings.join(' · ')}`);
    detail.innerHTML=`<div>${pieces.join(' &nbsp;•&nbsp; ')}</div>`;

    try{ localStorage.setItem('mf49:lastToken',scan.mint||$('#mf49TokenInput').value.trim()); }catch{}
  }

  function renderScanError(message){
    state.scan=null;
    $('#mf49ResultHead').hidden=true;
    $('#mf49Metrics').hidden=true;
    $('#mf49Reason').hidden=true;
    $('#mf49Detail').innerHTML=`<div class="mf49-empty">${String(message||'Token scan failed.')}</div>`;
  }

  async function scanToken(){
    if(state.busy) return;
    const input=$('#mf49TokenInput')?.value?.trim()||'';
    if(!input){ renderScanError('Paste a mint, Pump.fun link or DexScreener link first.'); return; }

    setBusy(true,'Scanning Solana token…');
    const btn=$('#mf49Scan'),old=btn?.textContent;
    if(btn) btn.textContent='Scanning…';

    try{
      const data=await post('/api/ai/standalone-scan',{input});
      renderScan(data.scan);
      if(state.auto) await narrateScan();
    }catch(e){
      if(e?.status===404){
        renderScanError('Scanner backend is not active. Restart the Replit server after installing V51.');
      }else{
        renderScanError(e.message);
      }
    }finally{
      setBusy(false);
      if(btn) btn.textContent=old||'Analyze token';
    }
  }

  function aiContext(){
    return {
      standaloneScan: state.scan,
      product: {
        readOnly:true,
        independentScanner:true,
        candidateFeedUntouched:true,
        manualAiScanUntouched:true,
        autoAi:state.auto
      }
    };
  }

  async function narrateScan(){
    if(!state.scan) return;
    try{
      const d=await post('/api/openai/ask',{
        prompt:'Summarize this independent MEMEFLOW token scan. Give the decision, strongest evidence, main risks/blockers, and one next safe action. Be concise.',
        context:aiContext()
      });
      state.api.quota='ok';
      setApi('READY','good');
      setNarrative(d.text||'AI analysis completed.');
    }catch(e){ handleAiError(e); }
  }

  async function ask(){
    if(state.busy) return;
    const q=$('#mf49Question')?.value?.trim()||'';
    if(!q){ setNarrative('Type a question first.',true); return; }

    setBusy(true);
    const btn=$('#mf49Ask'),old=btn?.textContent;
    if(btn) btn.textContent='…';
    try{
      const d=await post('/api/openai/ask',{prompt:q,context:aiContext()});
      state.api.quota='ok';
      setApi('READY','good');
      setNarrative(d.text||'No response.');
    }catch(e){ handleAiError(e); }
    finally{
      setBusy(false);
      if(btn) btn.textContent=old||'Ask';
    }
  }

  async function strategy(){
    if(state.busy) return;
    setBusy(true);
    try{
      const settings=await fetchJson('/api/settings').catch(()=>({settings:null}));
      const d=await post('/api/openai/ask',{
        prompt:'Explain the active MEMEFLOW strategy for this independently scanned token. Focus on score gates, holders, Top 10, developer holdings, buy pressure, capital/risk limits and why the evaluator returned its current state.',
        context:{...aiContext(),settings:settings.settings||null}
      });
      state.api.quota='ok';
      setApi('READY','good');
      setNarrative(d.text||'No response.');
    }catch(e){ handleAiError(e); }
    finally{ setBusy(false); }
  }

  function openSheet(){
    const sheet=ensureSheet();
    $$('.mobile-sheet.open').forEach(x=>{if(x!==sheet)x.classList.remove('open')});
    sheet.classList.add('open');
    document.body.style.overflow='hidden';
    $$('.mobile-nav [data-sheet]').forEach(btn=>btn.classList.toggle('active',btn.dataset.sheet==='ai'));
    cleanLegacy();
    checkApi(false);

    const input=$('#mf49TokenInput');
    if(input&&!input.value){
      try{ input.value=localStorage.getItem('mf49:lastToken')||''; }catch{}
    }
  }

  function closeSheet(){
    $('#sheet-ai')?.classList.remove('open');
    document.body.style.overflow='';
    $$('.mobile-nav [data-sheet]').forEach(btn=>btn.classList.toggle('active',btn.dataset.sheet==='home'));
  }

  function toggleAuto(button){
    state.auto=!state.auto;
    button?.classList.toggle('active',state.auto);
    button?.setAttribute('aria-pressed',String(state.auto));
    const mode=$('#mf49Mode');
    if(mode) mode.textContent=state.auto?'AUTO':'MANUAL';
    if(state.auto&&state.scan) narrateScan();
  }

  function autoGrowQuestion(el){
    if(!el) return;
    el.style.height='auto';
    const next=Math.max(42,Math.min(el.scrollHeight,78));
    el.style.height=`${next}px`;
  }

  function bind(){
    const ai=ensureCenterButton();

    // Keep the center nav click in capture phase so legacy handlers cannot open an old modal.
    if(ai && ai.dataset.mf51Bound!=='1'){
      ai.dataset.mf51Bound='1';
      ai.addEventListener('click',e=>{
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
        openSheet();
      },true);
    }

    // Delegated handlers survive any DOM refresh and prevent the V49/V50 "dead buttons" bug.
    if(window.__MEMEFLOW_AI_V51_EVENTS__) return;
    window.__MEMEFLOW_AI_V51_EVENTS__=true;

    document.addEventListener('click',e=>{
      const target=e.target?.closest?.(
        '#mf49Close,#mf49ApiChip,#mf49Scan,#mf49Ask,#mf49Strategy,#mf49Auto'
      );
      if(!target) return;

      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      if(target.id==='mf49Close') return closeSheet();
      if(target.id==='mf49ApiChip') return checkApi(true);
      if(target.id==='mf49Scan') return scanToken();
      if(target.id==='mf49Ask') return ask();
      if(target.id==='mf49Strategy') return strategy();
      if(target.id==='mf49Auto') return toggleAuto(target);
    },true);

    document.addEventListener('keydown',e=>{
      if(e.target?.id==='mf49TokenInput'&&e.key==='Enter'){
        e.preventDefault();
        scanToken();
        return;
      }
      if(e.target?.id==='mf49Question'&&e.key==='Enter'&&(e.metaKey||e.ctrlKey)){
        e.preventDefault();
        ask();
        return;
      }
      if(e.key==='Escape'&&$('#sheet-ai')?.classList.contains('open')) closeSheet();
    },true);

    document.addEventListener('input',e=>{
      if(e.target?.id==='mf49Question') autoGrowQuestion(e.target);
    },true);
  }

  function install(){
    cleanLegacy();
    installStyles();
    ensureSheet();
    ensureCenterButton();
    bind();
    [120,500,1400].forEach(ms=>setTimeout(cleanLegacy,ms));
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',install,{once:true});
  else install();
})();
