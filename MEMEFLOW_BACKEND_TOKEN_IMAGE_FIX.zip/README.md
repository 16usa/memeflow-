# MEMEFLOW Backend Token Image Fix

This patch fixes the actual image source instead of searching frontend fields blindly.

It updates:

- `memeflow-app/src/enrich.mjs`
  - reads the Pump.fun metadata URI already stored during token discovery;
  - supports HTTP, IPFS and Arweave metadata;
  - extracts `image`, `image_url`, `logo`, `icon`, or the first metadata file;
  - stores canonical `imageUrl` on the token;
  - uses a timeout and response-size limit.

- `memeflow-app/app-server.mjs`
  - adds `imageUrl`, `image`, `logoUrl`, `uri`, and `metadataUri` to every candidate payload.

The isolated Market Chart already knows how to display `imageUrl`.

## Apply in Replit

```bash
unzip -o MEMEFLOW_BACKEND_TOKEN_IMAGE_FIX.zip
node scripts/install-backend-token-image.mjs
```

Then press **Stop → Run**.

Newly discovered tokens should receive images automatically. Existing tokens receive images when they are enriched again.

## Rollback

```bash
cp memeflow-app/src/enrich.mjs.before-token-image-backend memeflow-app/src/enrich.mjs
cp memeflow-app/app-server.mjs.before-token-image-backend memeflow-app/app-server.mjs
```
