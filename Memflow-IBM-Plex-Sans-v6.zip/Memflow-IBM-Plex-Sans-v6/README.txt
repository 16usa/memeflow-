MEMFLOW — IBM Plex Sans full typography cleanup v6
===================================================

THIS VERSION IS MADE FOR A DIRTY REPLIT WORKTREE
------------------------------------------------
The previous v5 stopped because Memflow already contained modified/untracked
work. v6 handles that safely:

1. Creates a checkpoint commit of the current Memflow source state.
2. Pushes that checkpoint first.
3. Does NOT commit runtime/history data under memeflow-app/data/.
4. Audits every Memflow HTML/CSS file for competing text fonts.
5. Removes old text Google Fonts imports and stale text font definitions.
6. Normalizes text font-family declarations to IBM Plex Sans.
7. Preserves icon fonts (Font Awesome, Material Icons, etc.).
8. Runs an AFTER audit; typography commit is not made unless conflicts = 0.
9. Creates the typography commit and pushes it.
10. Keeps a hash-verified rollback snapshot.

UNCHANGED
---------
- current text colors
- current font sizes
- current font weights
- line heights
- spacing/layout
- semantic trading/status colors
- JS/backend behavior
- server/process state

INSTALL + CHECKPOINT + AUDIT + CLEANUP + PUSH
----------------------------------------------
unzip -o Memflow-IBM-Plex-Sans-v6.zip -d /tmp/mf-ibm-plex-v6
bash /tmp/mf-ibm-plex-v6/Memflow-IBM-Plex-Sans-v6/install_and_push.sh

MANUAL AUDIT
------------
bash /tmp/mf-ibm-plex-v6/Memflow-IBM-Plex-Sans-v6/audit.sh

SAFE ROLLBACK + COMMIT + PUSH
-----------------------------
bash /tmp/mf-ibm-plex-v6/Memflow-IBM-Plex-Sans-v6/rollback_and_push.sh

If later edits touched the same typography files, rollback stops safely.
Only if you intentionally want to overwrite those later edits:

bash /tmp/mf-ibm-plex-v6/Memflow-IBM-Plex-Sans-v6/rollback_and_push.sh --force

NO RESTART
----------
No script starts/stops/restarts/reloads/kills the server.
