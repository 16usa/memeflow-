#!/usr/bin/env bash
set -Eeuo pipefail

NO_PUSH=0
if [ "${1:-}" = "--no-push" ]; then
  NO_PUSH=1
elif [ -n "${1:-}" ]; then
  echo "Usage: $0 [--no-push]"
  exit 1
fi

APP="memeflow-app"
STATE_ROOT=".memeflow-backups"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
NORMALIZER="$SCRIPT_DIR/tools/normalize_fonts.py"
CANONICAL="$SCRIPT_DIR/memeflow-font-ibm-plex-sans-v6.css"
LATEST_FILE="$STATE_ROOT/ibm-plex-sans-clean-v6-LATEST"

[ -d "$APP" ] || {
  echo "ERROR: $APP not found."
  echo "Run this from the existing Memflow Replit workspace."
  exit 1
}

git rev-parse --is-inside-work-tree >/dev/null 2>&1 || {
  echo "ERROR: not inside a Git repository."
  exit 1
}

BRANCH="$(git symbolic-ref --quiet --short HEAD || true)"
[ -n "$BRANCH" ] || {
  echo "ERROR: detached HEAD."
  exit 1
}

ORIGIN="$(git remote get-url origin 2>/dev/null || true)"
if [ "$NO_PUSH" -eq 0 ] && [ -z "$ORIGIN" ]; then
  echo "ERROR: origin remote is missing."
  exit 1
fi

clear_stale_git_locks() {
  local lock busy
  for lock in ".git/index.lock" ".git/HEAD.lock" ".git/refs/heads/$BRANCH.lock"; do
    [ -e "$lock" ] || continue
    busy=0
    if command -v lsof >/dev/null 2>&1; then
      lsof "$lock" >/dev/null 2>&1 && busy=1 || true
    elif command -v fuser >/dev/null 2>&1; then
      fuser "$lock" >/dev/null 2>&1 && busy=1 || true
    fi
    if [ "$busy" -eq 1 ]; then
      echo "ERROR: active Git lock: $lock"
      exit 1
    fi
    rm -f -- "$lock"
    echo "Removed stale Git lock: $lock"
  done
}

clear_stale_git_locks

if [ "$NO_PUSH" -eq 0 ]; then
  git fetch origin "$BRANCH" --quiet
  if ! git merge-base --is-ancestor "origin/$BRANCH" HEAD; then
    echo "ERROR: origin/$BRANCH contains commits missing from local HEAD."
    echo "Nothing changed."
    exit 1
  fi
fi

echo "Branch : $BRANCH"
echo "Origin : ${ORIGIN:-<no-push mode>}"
echo
echo "=========================================="
echo "STEP 1 — CHECKPOINT CURRENT MEMFLOW STATE"
echo "=========================================="
echo "Existing Memflow work is preserved first."
echo "Runtime data under memeflow-app/data/ is NOT committed."

# Preserve the current app source state before typography cleanup.
# Exclude runtime/history data, but include current HTML/CSS/JS source files,
# including currently-untracked source files visible in the screenshots.
git add -A -- "$APP" ":(exclude)$APP/data/**"

if ! git diff --cached --quiet -- "$APP" ":(exclude)$APP/data/**"; then
  git diff --cached --check -- "$APP" ":(exclude)$APP/data/**"
  git commit --only \
    -m "Checkpoint current Memflow state before typography cleanup" \
    -- "$APP" ":(exclude)$APP/data/**"

  if [ "$NO_PUSH" -eq 0 ]; then
    git push origin "HEAD:$BRANCH"
  fi

  echo "Checkpoint commit: $(git rev-parse --short HEAD)"
else
  echo "No source checkpoint commit needed."
fi

echo
echo "Remaining intentionally-uncommitted app data:"
git status --short -- "$APP/data" 2>/dev/null || true

echo
echo "=========================================="
echo "STEP 2 — FULL TYPOGRAPHY AUDIT + CLEANUP"
echo "=========================================="

python3 "$NORMALIZER" \
  --app "$APP" \
  --state-root "$STATE_ROOT" \
  --canonical-source "$CANONICAL"

BACKUP="$(cat "$LATEST_FILE")"

# Canonical layer must be font-family only.
python3 - "$APP/memeflow-font-ibm-plex-sans-v6.css" <<'PY'
from pathlib import Path
import re, sys

s = Path(sys.argv[1]).read_text(encoding="utf-8")
no_comments = re.sub(r"/\*.*?\*/", "", s, flags=re.S)

for prop in (
    "color", "font-size", "font-weight", "line-height", "letter-spacing",
    "text-transform", "margin", "padding", "width", "height"
):
    if re.search(rf"(?m)^\s*{re.escape(prop)}\s*:", no_comments):
        raise SystemExit(
            f"ERROR: canonical font layer unexpectedly owns {prop}"
        )

print("Canonical layer safety: OK (font family only).")
PY

git diff --check -- "$APP" ":(exclude)$APP/data/**"

echo
echo "=========================================="
echo "STEP 3 — TYPOGRAPHY DIFF"
echo "=========================================="
git diff --stat -- "$APP" ":(exclude)$APP/data/**"

# Stage only source/app typography changes; runtime data remains untouched.
git add -A -- "$APP" ":(exclude)$APP/data/**"
git diff --cached --check -- "$APP" ":(exclude)$APP/data/**"

if git diff --cached --quiet -- "$APP" ":(exclude)$APP/data/**"; then
  echo "No typography changes to commit."
else
  git commit --only \
    -m "Unify Memflow typography on IBM Plex Sans" \
    -- "$APP" ":(exclude)$APP/data/**"
fi

if [ "$NO_PUSH" -eq 0 ]; then
  git push origin "HEAD:$BRANCH"
fi

echo
echo "=========================================="
echo "IBM PLEX SANS CLEANUP COMPLETE"
echo "=========================================="
echo "Conflicting text fonts : 0 (verified by AFTER audit)"
echo "Icon fonts             : preserved"
echo "Current text colors    : preserved"
echo "Current font sizes     : preserved"
echo "Current weights        : preserved"
echo "Current line heights   : preserved"
echo "Runtime data/          : not committed"
echo "Restart                : NOT performed"
echo "Backup                 : $BACKUP"
if [ "$NO_PUSH" -eq 0 ]; then
  echo "Push                   : origin/$BRANCH"
else
  echo "Push                   : skipped (--no-push)"
fi
echo "=========================================="
