#!/usr/bin/env bash
set -Eeuo pipefail
APP="memeflow-app"
[ -d "$APP" ] || { echo "ERROR: $APP not found."; exit 1; }

python3 - "$APP" <<'PY'
from pathlib import Path
import re, sys

app = Path(sys.argv[1])
icon = (
    "font awesome","fontawesome","material icons","material symbols",
    "bootstrap-icons","bootstrap icons","remixicon","boxicons",
    "icomoon","ionicons","themify","simple-line-icons","glyphicons"
)
fam = re.compile(r'(?i)font-family\s*:\s*([^;}{]+)(?:;|(?=}))')
google = re.compile(r'(?i)fonts\.googleapis\.com|fonts\.gstatic\.com')
conflicts=[]
icons=0

for p in sorted(app.rglob("*")):
    if not p.is_file() or p.suffix.lower() not in {".css",".html",".htm"}:
        continue
    s=p.read_text(encoding="utf-8",errors="ignore")
    for m in fam.finditer(s):
        v=m.group(1).strip()
        low=v.lower()
        if any(x in low for x in icon) or "--fa-" in low:
            icons+=1
        elif low in {"inherit","initial","unset","revert","revert-layer"}:
            pass
        elif "ibm plex sans" not in low and "var(--mf-font-family)" not in low:
            conflicts.append((str(p),"font-family",v))
    if google.search(s) and p.name != "memeflow-font-ibm-plex-sans-v6.css":
        conflicts.append((str(p),"external-font-import","Google Fonts reference"))

print("MEMFLOW TYPOGRAPHY AUDIT")
print("Conflicting text font rules:", len(conflicts))
print("Preserved icon font rules   :", icons)
for row in conflicts:
    print("CONFLICT:", *row)
raise SystemExit(1 if conflicts else 0)
PY
