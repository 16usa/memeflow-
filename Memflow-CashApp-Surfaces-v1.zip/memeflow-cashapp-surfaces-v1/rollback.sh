#!/usr/bin/env bash
set -euo pipefail
BACKUP='.memeflow-cashapp-surfaces-v1-backup'
if [ ! -d "$BACKUP" ]; then
  echo "Backup not found: $BACKUP"
  exit 1
fi

for name in index.html system.html system-tokens.html trading.html settings.html smart-vault.html how-it-works.html agent-performance.html owner-intelligence.html game.html; do
  if [ -f "$BACKUP/$name" ]; then
    cp "$BACKUP/$name" "memeflow-app/$name"
  fi
done

if [ -f "$BACKUP/memeflow-cashapp-surfaces-v1.css" ]; then
  cp "$BACKUP/memeflow-cashapp-surfaces-v1.css" memeflow-app/memeflow-cashapp-surfaces-v1.css
else
  rm -f memeflow-app/memeflow-cashapp-surfaces-v1.css
fi

git diff --check
FILES=(
  memeflow-app/memeflow-cashapp-surfaces-v1.css
  memeflow-app/index.html
  memeflow-app/system.html
  memeflow-app/system-tokens.html
  memeflow-app/trading.html
  memeflow-app/settings.html
  memeflow-app/smart-vault.html
  memeflow-app/how-it-works.html
  memeflow-app/agent-performance.html
  memeflow-app/owner-intelligence.html
  memeflow-app/game.html
)
set -x
git add -A -- "${FILES[@]}"
if ! git diff --cached --quiet; then
  git commit -m "Rollback MEMEFLOW Cash App surfaces v1"
  git push
else
  echo 'No git changes to commit.'
fi
set +x

echo 'Rollback complete. Restart the app manually from the Replit console when ready.'
