#!/usr/bin/env bash
set -euo pipefail

echo 'Installing MEMEFLOW Cash App surfaces v1...'
python3 /tmp/memeflow-cashapp-surfaces-v1/memeflow-cashapp-surfaces-v1/apply_patch.py

set -x
git diff --check
grep -q 'MEMEFLOW_CASHAPP_SURFACES_V1' memeflow-app/memeflow-cashapp-surfaces-v1.css
grep -q 'memeflow-cashapp-surfaces-v1.css' memeflow-app/index.html
grep -q 'memeflow-cashapp-surfaces-v1.css' memeflow-app/trading.html
set +x

echo
printf 'Patch checks passed.\n'
printf 'No server restart was performed.\n'

FILES=(
  memeflow-app/memeflow-cashapp-surfaces-v1.css
  memeflow-app/index.html
  memeflow-app/system.html
  memeflow-app/system-tokens.html
  memeflow-app/trading.html
  memeflow-app/settings.html
  memeflow-app/smart-vault.html
  memeflow-app/how-it-works.html
  memeflow-app/agent-performance.html
  memeflow-app/owner-intelligence.html
  memeflow-app/game.html
)
EXISTING=()
for f in "${FILES[@]}"; do [ -e "$f" ] && EXISTING+=("$f"); done

set -x
git add "${EXISTING[@]}"
if ! git diff --cached --quiet; then
  git commit -m "MEMEFLOW: Cash App dark surfaces and frameless cards"
  git push
else
  echo 'No git changes to commit.'
fi
set +x

echo
printf 'Done. Restart the app manually from the Replit console when ready.\n'
