from pathlib import Path
import shutil

ROOT = Path('memeflow-app')
CSS_NAME = 'memeflow-cashapp-surfaces-v1.css'
SOURCE = Path('/tmp/memeflow-cashapp-surfaces-v1/memeflow-cashapp-surfaces-v1') / CSS_NAME
TARGET = ROOT / CSS_NAME
BACKUP = Path('.memeflow-cashapp-surfaces-v1-backup')
PAGES = [
    'index.html',
    'system.html',
    'system-tokens.html',
    'trading.html',
    'settings.html',
    'smart-vault.html',
    'how-it-works.html',
    'agent-performance.html',
    'owner-intelligence.html',
    'game.html',
]
LINK = '<link rel="stylesheet" href="/memeflow-cashapp-surfaces-v1.css?v=memeflow-cashapp-surfaces-v1">'

if not ROOT.exists():
    raise SystemExit('memeflow-app folder not found. Run this from the existing Replit workspace root.')
if not SOURCE.exists():
    raise SystemExit(f'Patch CSS not found: {SOURCE}')

BACKUP.mkdir(exist_ok=True)
# Keep local backups out of git status without editing the project .gitignore.
exclude = Path('.git/info/exclude')
if exclude.exists():
    current = exclude.read_text(encoding='utf-8', errors='ignore')
    marker = '.memeflow-cashapp-surfaces-v1-backup/'
    if marker not in current:
        exclude.write_text(current.rstrip() + '\n' + marker + '\n', encoding='utf-8')

for name in PAGES:
    path = ROOT / name
    if not path.exists():
        continue
    backup = BACKUP / name
    if not backup.exists():
        shutil.copy2(path, backup)
    text = path.read_text(encoding='utf-8')
    if LINK in text:
        continue
    if '</head>' not in text:
        print(f'Warning: no </head> in {path}; skipped')
        continue
    text = text.replace('</head>', f'  {LINK}\n</head>', 1)
    path.write_text(text, encoding='utf-8')
    print(f'Injected stylesheet into {path}')

if TARGET.exists():
    backup_css = BACKUP / CSS_NAME
    if not backup_css.exists():
        shutil.copy2(TARGET, backup_css)
shutil.copy2(SOURCE, TARGET)
print(f'Installed {TARGET}')
