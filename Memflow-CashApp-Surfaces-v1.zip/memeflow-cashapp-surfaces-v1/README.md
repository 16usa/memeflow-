# MEMEFLOW Cash App Surfaces v1

Dark theme only.

- Main site and 3D background: `#000000`
- Card/module fill: `#1A1A1A`
- Main cards/modules: no visible border and no shadow
- Light theme: unchanged
- No automatic server restart

The patch adds one late-loading stylesheet to the main MEMEFLOW pages so existing application logic is untouched.
