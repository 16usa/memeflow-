MEMEFLOW MOBILE REDESIGN — установка в Replit

1. Открой папку memeflow-app в Replit.
2. Загрузи в неё три файла:
   - mobile-redesign.css
   - mobile-redesign.js
   - install-mobile-redesign.mjs
3. Открой Shell и выполни:
   node install-mobile-redesign.mjs
4. Перезапусти проект:
   npm start

Что меняется:
- компактная верхняя панель;
- Home становится короче;
- Primary Candidate и AI Decision уплотняются;
- Market Chart выглядит как отдельный модуль;
- Pre-trade checks становятся компактными;
- Billing, Settings и System убираются из длинного Home и открываются через More;
- исправляется нижний safe-area отступ iPhone;
- сервер, API, торговая логика и настройки не изменяются.

Откат:
- файл index.before-mobile-redesign.html создаётся автоматически;
- чтобы вернуть старую версию, переименуй его обратно в index.html.
