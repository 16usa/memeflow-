
(() => {
  'use strict';

  const $ = (s) => document.querySelector(s);
  const $$ = (s) => [...document.querySelectorAll(s)];

  function openMainSection(id) {
    $$('.mobile-sheet.open').forEach((sheet) => sheet.classList.remove('open'));
    document.body.style.overflow = '';

    const el = document.getElementById(id);
    if (!el) return;

    const previous = el.style.getPropertyValue('display');
    el.style.setProperty('display', 'block', 'important');
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });

    window.setTimeout(() => {
      if (previous) el.style.display = previous;
      else el.style.removeProperty('display');
    }, 500);
  }

  const more = $('#sheet-more .grid');
  if (more && !$('#mfMobileSettings')) {
    const items = [
      ['mfMobileBilling', 'Plans & Billing', 'billing'],
      ['mfMobileSettings', 'AI & Trading Settings', 'settings'],
      ['mfMobileSystem', 'System Health', 'system']
    ];

    items.forEach(([id, label, target]) => {
      const button = document.createElement('button');
      button.id = id;
      button.type = 'button';
      button.className = 'btn';
      button.textContent = label;
      button.addEventListener('click', () => openMainSection(target));
      more.appendChild(button);
    });
  }

  // Make chart behave like a dedicated module on mobile.
  const chart = $('#marketChart');
  if (chart) {
    chart.setAttribute('aria-label', 'Standalone mobile market chart module');
  }

  // Keep only one active sticky layer during sheet use.
  const observer = new MutationObserver(() => {
    const sheetOpen = Boolean($('.mobile-sheet.open'));
    document.body.classList.toggle('mf-sheet-open', sheetOpen);
  });

  $$('.mobile-sheet').forEach((sheet) => {
    observer.observe(sheet, { attributes: true, attributeFilter: ['class'] });
  });
})();
