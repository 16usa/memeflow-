
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const indexPath = path.join(root, 'index.html');
const cssPath = path.join(root, 'mobile-redesign.css');
const jsPath = path.join(root, 'mobile-redesign.js');

if (!fs.existsSync(indexPath)) {
  console.error('ERROR: index.html not found. Run this command inside the memeflow-app folder.');
  process.exit(1);
}

if (!fs.existsSync(cssPath) || !fs.existsSync(jsPath)) {
  console.error('ERROR: mobile-redesign.css or mobile-redesign.js is missing.');
  process.exit(1);
}

let html = fs.readFileSync(indexPath, 'utf8');
const backupPath = path.join(root, 'index.before-mobile-redesign.html');

if (!fs.existsSync(backupPath)) {
  fs.writeFileSync(backupPath, html);
}

html = html
  .replace(/\n?<link[^>]+data-mf-mobile-redesign[^>]*>\n?/g, '\n')
  .replace(/\n?<script[^>]+data-mf-mobile-redesign[^>]*><\/script>\n?/g, '\n');

const cssTag = '<link rel="stylesheet" href="./mobile-redesign.css?v=1" data-mf-mobile-redesign="true">';
const jsTag = '<script src="./mobile-redesign.js?v=1" defer data-mf-mobile-redesign="true"></script>';

if (!html.includes('</head>') || !html.includes('</body>')) {
  console.error('ERROR: index.html has an unexpected structure.');
  process.exit(1);
}

html = html.replace('</head>', `${cssTag}\n</head>`);
html = html.replace('</body>', `${jsTag}\n</body>`);

fs.writeFileSync(indexPath, html);
console.log('MEMEFLOW mobile redesign installed successfully.');
console.log('Backup:', backupPath);
console.log('Start the app with: npm start');
