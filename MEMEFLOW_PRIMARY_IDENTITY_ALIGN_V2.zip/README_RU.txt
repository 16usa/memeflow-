MEMEFLOW — PRIMARY CANDIDATE IDENTITY ALIGN V2

ЦЕЛЬ
1) AI SCORE НЕ ДВИГАТЬ.
2) Аватар токена подогнать по высоте к большому числу AI SCORE:
   верх аватара = верх #primaryScore;
   высота аватара = высота #primaryScore;
   следовательно низ тоже совпадает.
3) Маленькое второе название (#primaryMeta, например PUMPSHEEP)
   убрать из-под изображения и поставить в одну строку рядом с большим
   названием (#primaryName, например PumpSheep).

ПРОВЕРЕНО ПО GITHUB
Рабочая структура использует:
  #primary-candidate
  #primaryName
  #primaryMeta
  #primaryScore

УСТАНОВКА В REPLIT
1. Загрузить ZIP в КОРЕНЬ проекта.
2. Распаковать:
   unzip -o MEMEFLOW_PRIMARY_IDENTITY_ALIGN_V2.zip
3. Запустить:
   node install-primary-identity-align-v2.mjs
4. Stop -> Run в Replit.
5. Полностью обновить страницу на iPhone.

ВАЖНО
- Инсталлятор автоматически удаляет предыдущий блок
  MF_PATCH_PRIMARY_AVATAR_SCORE_HEIGHT, если он установлен.
- Manual AI Scan не меняется.
- AI Score не получает ни одного style/class/transform от этого патча.
- Торговая логика/API/evaluator/settings не меняются.

ОТКАТ
  node rollback-primary-identity-align-v2.mjs
