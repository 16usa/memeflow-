#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
from pathlib import Path

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--state-root", default=".memeflow-backups")
    ap.add_argument("--force", action="store_true")
    args = ap.parse_args()

    state_root = Path(args.state_root)
    latest = state_root / "ibm-plex-sans-clean-v5-LATEST"
    if not latest.exists():
        raise SystemExit("ERROR: no v5 rollback state found")

    backup = Path(latest.read_text(encoding="utf-8").strip())
    manifest_path = backup / "manifest.json"
    if not manifest_path.exists():
        raise SystemExit(f"ERROR: rollback manifest missing: {manifest_path}")

    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))

    conflicts = []
    for entry in manifest["files"]:
        p = Path(entry["path"])
        expected = entry.get("after_sha256")
        if expected is None:
            if p.exists():
                conflicts.append(f"{p}: exists but patch expected it removed")
            continue
        if not p.exists():
            conflicts.append(f"{p}: missing")
            continue
        current = sha256_file(p)
        if current != expected:
            conflicts.append(f"{p}: changed after typography install")

    if conflicts and not args.force:
        print("ROLLBACK STOPPED SAFELY.")
        print("These files changed after the IBM Plex Sans patch:")
        for c in conflicts:
            print("  -", c)
        print()
        print("Nothing was restored.")
        print("Use --force only if you intentionally want to overwrite those later changes.")
        raise SystemExit(2)

    restored = []
    for entry in manifest["files"]:
        p = Path(entry["path"])
        existed_before = entry.get("existed_before", False)
        src = backup / p

        if existed_before:
            if not src.exists():
                raise SystemExit(f"ERROR: backup file missing: {src}")
            p.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, p)
            restored.append(str(p))
            print("RESTORED", p)
        else:
            if p.exists():
                p.unlink()
                restored.append(str(p))
                print("REMOVED ", p)

    latest.unlink(missing_ok=True)
    (backup / "rollback_changed_files.txt").write_text(
        "\n".join(sorted(set(restored))) + "\n",
        encoding="utf-8",
    )

    print()
    print("Rollback complete.")
    print(f"Restored from: {backup}")

if __name__ == "__main__":
    main()
