#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

CANONICAL_FILE = "memeflow-font-ibm-plex-sans-v5.css"
OLD_PATCH_FILES = {
    "memeflow-kryphos-typography-v1.css",
    "memeflow-ibm-plex-sans-v1.css",
    "memeflow-font-ibm-plex-sans-v3.css",
    "memeflow-font-ibm-plex-sans-v4.css",
}
TEXT_EXTS = {".css", ".html", ".htm"}

CANONICAL_STACK = '"IBM Plex Sans",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif'

ICON_MARKERS = (
    "font awesome",
    "fontawesome",
    "material icons",
    "material symbols",
    "bootstrap-icons",
    "bootstrap icons",
    "remixicon",
    "boxicons",
    "icomoon",
    "ionicons",
    "themify",
    "simple-line-icons",
    "glyphicons",
)

GOOGLE_IMPORT_RE = re.compile(
    r'(?im)^[ \t]*@import\s+[^\n]*fonts\.googleapis\.com[^\n]*;[ \t]*\n?'
)
GOOGLE_LINK_RE = re.compile(
    r'(?is)<link\b[^>]*href=["\']https?://fonts\.(?:googleapis|gstatic)\.com/[^"\']*["\'][^>]*>\s*'
)
OLD_PATCH_LINK_RE = re.compile(
    r'(?is)<link\b[^>]*href=["\'][^"\']*(?:memeflow-kryphos-typography-v1\.css|memeflow-ibm-plex-sans-v1\.css)["\'][^>]*>\s*'
)
FONT_FAMILY_RE = re.compile(r'(?i)(font-family\s*:\s*)([^;}{]+)(;|(?=}))')
FONT_VAR_RE = re.compile(
    r'(?i)(--[a-z0-9_-]*(?:font-family|font-sans|font-ui|font-body|font-display|typeface)[a-z0-9_-]*\s*:\s*)([^;}{]+)(;|(?=}))'
)
FONT_FACE_RE = re.compile(r'(?is)@font-face\s*\{.*?\}')
CANONICAL_LINK_RE = re.compile(
    rf'(?is)<link\b[^>]*href=["\'][^"\']*{re.escape(CANONICAL_FILE)}["\'][^>]*>\s*'
)

def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())

def is_icon_value(value: str) -> bool:
    low = value.lower()
    return any(m in low for m in ICON_MARKERS) or "--fa-" in low

def is_inherit_value(value: str) -> bool:
    return value.strip().lower() in {"inherit", "initial", "unset", "revert", "revert-layer"}

def clean_font_face(match: re.Match) -> str:
    block = match.group(0)
    fam = re.search(r'(?i)font-family\s*:\s*([^;}{]+)', block)
    if fam and is_icon_value(fam.group(1)):
        return block
    # Remove non-icon @font-face definitions. They are no longer referenced
    # after normalization and keeping them only preserves stale typography.
    return ""

def replace_family(match: re.Match) -> str:
    prefix, value, suffix = match.groups()
    if is_icon_value(value) or is_inherit_value(value):
        return match.group(0)
    return f"{prefix}{CANONICAL_STACK}{suffix}"

def replace_font_var(match: re.Match) -> str:
    prefix, value, suffix = match.groups()
    if is_icon_value(value):
        return match.group(0)
    return f'{prefix}{CANONICAL_STACK}{suffix}'

def transform_css(text: str) -> str:
    text = GOOGLE_IMPORT_RE.sub("", text)
    text = FONT_FACE_RE.sub(clean_font_face, text)
    text = FONT_VAR_RE.sub(replace_font_var, text)
    text = FONT_FAMILY_RE.sub(replace_family, text)
    return text

def transform_html(text: str) -> str:
    text = GOOGLE_LINK_RE.sub("", text)
    text = OLD_PATCH_LINK_RE.sub("", text)
    text = CANONICAL_LINK_RE.sub("", text)
    text = FONT_VAR_RE.sub(replace_font_var, text)
    text = FONT_FAMILY_RE.sub(replace_family, text)

    link = f'<link rel="stylesheet" href="{CANONICAL_FILE}">'
    if re.search(r"</head>", text, flags=re.I):
        text = re.sub(r"</head>", link + "\n</head>", text, count=1, flags=re.I)
    else:
        raise RuntimeError("HTML file has no </head>")
    return text

def audit_file(path: Path, text: str, canonical_file: Path):
    conflicts = []
    icon_exceptions = 0

    if path.suffix.lower() == ".css":
        # Google Fonts are only allowed in the canonical layer.
        for m in GOOGLE_IMPORT_RE.finditer(text):
            if path != canonical_file:
                conflicts.append(("google-font-import", m.group(0).strip()))

    if path.suffix.lower() in {".html", ".htm"}:
        for m in GOOGLE_LINK_RE.finditer(text):
            conflicts.append(("google-font-link", m.group(0).strip()))

    for m in FONT_FAMILY_RE.finditer(text):
        value = m.group(2).strip()
        if is_icon_value(value):
            icon_exceptions += 1
            continue
        if is_inherit_value(value):
            continue
        low = value.lower().replace(" ", "")
        allowed = (
            '"ibmplexsans"' in low
            or "var(--mf-font-family)" in low
        )
        if not allowed:
            conflicts.append(("font-family", value))

    for m in FONT_VAR_RE.finditer(text):
        value = m.group(2).strip()
        if is_icon_value(value):
            icon_exceptions += 1
            continue
        low = value.lower().replace(" ", "")
        if '"ibmplexsans"' not in low and "var(--mf-font-family)" not in low:
            conflicts.append(("font-var", value))

    for m in FONT_FACE_RE.finditer(text):
        block = m.group(0)
        fam = re.search(r'(?i)font-family\s*:\s*([^;}{]+)', block)
        if fam and is_icon_value(fam.group(1)):
            icon_exceptions += 1
        else:
            conflicts.append(("font-face", fam.group(1).strip() if fam else "@font-face"))

    return conflicts, icon_exceptions

def collect(app: Path):
    files = []
    for p in app.rglob("*"):
        if not p.is_file():
            continue
        if p.suffix.lower() not in TEXT_EXTS:
            continue
        if any(part in {"node_modules", ".git", ".memeflow-backups"} for part in p.parts):
            continue
        files.append(p)
    return sorted(files)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--app", default="memeflow-app")
    ap.add_argument("--state-root", default=".memeflow-backups")
    ap.add_argument("--canonical-source", required=True)
    args = ap.parse_args()

    app = Path(args.app)
    if not app.is_dir():
        raise SystemExit(f"ERROR: {app} not found")

    state_root = Path(args.state_root)
    state_root.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = state_root / f"ibm-plex-sans-clean-v5-{stamp}"
    backup.mkdir(parents=True)
    latest = state_root / "ibm-plex-sans-clean-v5-LATEST"

    canonical_source = Path(args.canonical_source)
    canonical_target = app / CANONICAL_FILE

    files = collect(app)
    before_conflicts = []
    before_icon_exceptions = 0
    for p in files:
        text = p.read_text(encoding="utf-8", errors="ignore")
        c, icons = audit_file(p, text, canonical_target)
        before_conflicts.extend((str(p), kind, value) for kind, value in c)
        before_icon_exceptions += icons

    print("==========================================")
    print("TYPOGRAPHY AUDIT — BEFORE")
    print("==========================================")
    print(f"Scanned text files       : {len(files)}")
    print(f"Conflicting font rules   : {len(before_conflicts)}")
    print(f"Icon-font exceptions     : {before_icon_exceptions}")
    for p, kind, value in before_conflicts[:80]:
        print(f"  {p}: {kind}: {value[:180]}")
    if len(before_conflicts) > 80:
        print(f"  ... {len(before_conflicts)-80} more")
    print()

    manifest = {
        "patch": "Memflow IBM Plex Sans Cleanup v5",
        "backup": str(backup),
        "canonical_file": str(canonical_target),
        "files": [],
        "audit_before_conflicts": len(before_conflicts),
        "audit_before_icon_exceptions": before_icon_exceptions,
    }

    changed_paths = []

    # Transform current files in memory, then back up and write only if changed.
    for p in files:
        old = p.read_text(encoding="utf-8", errors="ignore")
        if p.name in OLD_PATCH_FILES:
            # Stale font-layer files are removed entirely below.
            continue
        try:
            if p.suffix.lower() == ".css":
                new = transform_css(old)
            else:
                new = transform_html(old)
        except RuntimeError as e:
            raise SystemExit(f"ERROR: {p}: {e}")

        if new != old:
            dst = backup / p
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
            before_hash = sha256_file(p)
            p.write_text(new, encoding="utf-8")
            after_hash = sha256_file(p)
            manifest["files"].append({
                "path": str(p),
                "existed_before": True,
                "before_sha256": before_hash,
                "after_sha256": after_hash,
            })
            changed_paths.append(str(p))

    # Remove stale font patch files if they exist.
    for name in OLD_PATCH_FILES:
        p = app / name
        if p.exists():
            dst = backup / p
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
            manifest["files"].append({
                "path": str(p),
                "existed_before": True,
                "before_sha256": sha256_file(p),
                "after_sha256": None,
                "removed_by_patch": True,
            })
            p.unlink()
            changed_paths.append(str(p))

    # Install/replace canonical CSS, backing up an older version if present.
    if canonical_target.exists():
        old_bytes = canonical_target.read_bytes()
        dst = backup / canonical_target
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(canonical_target, dst)
        existed_before = True
        before_hash = sha256_bytes(old_bytes)
    else:
        existed_before = False
        before_hash = None

    canonical_target.write_text(canonical_source.read_text(encoding="utf-8"), encoding="utf-8")
    after_hash = sha256_file(canonical_target)
    manifest["files"].append({
        "path": str(canonical_target),
        "existed_before": existed_before,
        "before_sha256": before_hash,
        "after_sha256": after_hash,
    })
    if str(canonical_target) not in changed_paths:
        changed_paths.append(str(canonical_target))

    # Recollect after adding canonical file and audit again.
    after_files = collect(app)
    after_conflicts = []
    after_icon_exceptions = 0
    for p in after_files:
        text = p.read_text(encoding="utf-8", errors="ignore")
        c, icons = audit_file(p, text, canonical_target)
        after_conflicts.extend((str(p), kind, value) for kind, value in c)
        after_icon_exceptions += icons

    # Canonical CSS's Google import is deliberately allowed.
    filtered = []
    for item in after_conflicts:
        p, kind, value = item
        if Path(p) == canonical_target and kind == "google-font-import":
            continue
        filtered.append(item)
    after_conflicts = filtered

    print("==========================================")
    print("TYPOGRAPHY AUDIT — AFTER")
    print("==========================================")
    print(f"Scanned text files       : {len(after_files)}")
    print(f"Conflicting font rules   : {len(after_conflicts)}")
    print(f"Icon-font exceptions     : {after_icon_exceptions}")
    if after_conflicts:
        for p, kind, value in after_conflicts[:100]:
            print(f"  CONFLICT {p}: {kind}: {value[:180]}")
        raise SystemExit("ERROR: typography cleanup incomplete; nothing should be committed")

    manifest["audit_after_conflicts"] = 0
    manifest["audit_after_icon_exceptions"] = after_icon_exceptions

    # Record actual after hashes for every touched path in case earlier entries
    # changed again during canonical insertion.
    for entry in manifest["files"]:
        p = Path(entry["path"])
        entry["after_sha256"] = sha256_file(p) if p.exists() else None

    manifest_path = backup / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    (backup / "changed_files.txt").write_text("\n".join(sorted(set(changed_paths))) + "\n", encoding="utf-8")
    latest.write_text(str(backup) + "\n", encoding="utf-8")

    print()
    print("RESULT")
    print("  Text font              : IBM Plex Sans")
    print("  Old text font conflicts: 0")
    print(f"  Icon font exceptions   : {after_icon_exceptions} (preserved intentionally)")
    print("  Text colors            : untouched by canonical layer")
    print("  Font sizes             : untouched by canonical layer")
    print("  Font weights           : untouched by canonical layer")
    print("  Line heights           : untouched by canonical layer")
    print(f"  Backup                 : {backup}")
    print(f"  Manifest               : {manifest_path}")

if __name__ == "__main__":
    main()
