#!/usr/bin/env bash
set -Eeuo pipefail

FORCE=0
NO_PUSH=0
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=1 ;;
    --no-push) NO_PUSH=1 ;;
    *) echo "Usage: $0 [--force] [--no-push]"; exit 1 ;;
  esac
done

APP="memeflow-app"
STATE_ROOT=".memeflow-backups"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
ROLLBACK="$SCRIPT_DIR/tools/rollback_fonts.py"
LATEST_FILE="$STATE_ROOT/ibm-plex-sans-clean-v5-LATEST"

git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "ERROR: not inside a Git repository."; exit 1; }
[ -f "$LATEST_FILE" ] || { echo "ERROR: no rollback state found."; exit 1; }

BRANCH="$(git symbolic-ref --quiet --short HEAD || true)"
[ -n "$BRANCH" ] || { echo "ERROR: detached HEAD."; exit 1; }

ORIGIN="$(git remote get-url origin 2>/dev/null || true)"
if [ "$NO_PUSH" -eq 0 ] && [ -z "$ORIGIN" ]; then
  echo "ERROR: origin remote is missing."
  exit 1
fi

ARGS=(--state-root "$STATE_ROOT")
[ "$FORCE" -eq 1 ] && ARGS+=(--force)

python3 "$ROLLBACK" "${ARGS[@]}"

git diff --check -- "$APP"
git add -A -- "$APP"
git diff --cached --check -- "$APP"

if git diff --cached --quiet -- "$APP"; then
  echo "No rollback changes to commit."
else
  git commit --only -m "Rollback IBM Plex Sans typography cleanup" -- "$APP"
fi

if [ "$NO_PUSH" -eq 0 ]; then
  git push origin "HEAD:$BRANCH"
fi

echo
echo "=========================================="
echo "TYPOGRAPHY ROLLBACK COMPLETE"
echo "=========================================="
echo "Restart : NOT performed"
if [ "$NO_PUSH" -eq 0 ]; then
  echo "Push    : origin/$BRANCH"
else
  echo "Push    : skipped (--no-push)"
fi
echo "=========================================="
