MEMFLOW — IBM Plex Sans full typography cleanup v5
===================================================

WHAT THIS VERSION DOES
----------------------
1. Audits every Memflow CSS/HTML file for competing text font families.
2. Removes old Google Fonts text imports and old text @font-face definitions.
3. Normalizes text font-family declarations to IBM Plex Sans.
4. Preserves icon fonts (Font Awesome, Material Icons, Bootstrap Icons, etc.).
5. Adds one canonical IBM Plex Sans stylesheet as the final layer.
6. Runs an AFTER audit and refuses to commit if any conflicting text font remains.
7. Commits and pushes only after the audit passes.
8. Creates a hash-verified rollback snapshot before changes.

WHAT IT DOES NOT CHANGE
-----------------------
- text colors
- font sizes
- font weights in UI rules
- line heights
- spacing/layout
- semantic trading/status colors
- JavaScript/backend logic
- running server/process state

INSTALL + VERIFY + COMMIT + PUSH
--------------------------------
unzip -o Memflow-IBM-Plex-Sans-v5.zip -d /tmp/mf-ibm-plex-v5
bash /tmp/mf-ibm-plex-v5/Memflow-IBM-Plex-Sans-v5/install_and_push.sh

MANUAL AUDIT
------------
bash /tmp/mf-ibm-plex-v5/Memflow-IBM-Plex-Sans-v5/audit.sh

SAFE ROLLBACK + COMMIT + PUSH
-----------------------------
bash /tmp/mf-ibm-plex-v5/Memflow-IBM-Plex-Sans-v5/rollback_and_push.sh

If later edits touched the same typography files, rollback stops safely.
Only if you intentionally want to overwrite those later edits:

bash /tmp/mf-ibm-plex-v5/Memflow-IBM-Plex-Sans-v5/rollback_and_push.sh --force

NO RESTART
----------
No script starts/stops/restarts/reloads/kills the server.
