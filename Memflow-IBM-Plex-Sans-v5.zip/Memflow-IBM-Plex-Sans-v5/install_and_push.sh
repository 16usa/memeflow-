#!/usr/bin/env bash
set -Eeuo pipefail

NO_PUSH=0
if [ "${1:-}" = "--no-push" ]; then
  NO_PUSH=1
elif [ -n "${1:-}" ]; then
  echo "Usage: $0 [--no-push]"
  exit 1
fi

APP="memeflow-app"
STATE_ROOT=".memeflow-backups"
SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
NORMALIZER="$SCRIPT_DIR/tools/normalize_fonts.py"
CANONICAL="$SCRIPT_DIR/memeflow-font-ibm-plex-sans-v5.css"

[ -d "$APP" ] || { echo "ERROR: $APP not found. Run from the existing Memflow workspace."; exit 1; }
git rev-parse --is-inside-work-tree >/dev/null 2>&1 || { echo "ERROR: not inside a Git repository."; exit 1; }

BRANCH="$(git symbolic-ref --quiet --short HEAD || true)"
[ -n "$BRANCH" ] || { echo "ERROR: detached HEAD."; exit 1; }

# Never mix this typography commit with already-dirty Memflow application files.
if [ -n "$(git status --porcelain -- "$APP")" ]; then
  echo "ERROR: memeflow-app already has uncommitted/staged changes."
  echo "Push or commit those existing Memflow changes first, then run this patch."
  git status --short -- "$APP"
  exit 1
fi

ORIGIN="$(git remote get-url origin 2>/dev/null || true)"
if [ "$NO_PUSH" -eq 0 ] && [ -z "$ORIGIN" ]; then
  echo "ERROR: origin remote is missing."
  exit 1
fi

echo "Branch : $BRANCH"
echo "Origin : ${ORIGIN:-<no-push mode>}"
echo
echo "Running full Memflow typography audit + cleanup..."

python3 "$NORMALIZER" \
  --app "$APP" \
  --state-root "$STATE_ROOT" \
  --canonical-source "$CANONICAL"

LATEST_FILE="$STATE_ROOT/ibm-plex-sans-clean-v5-LATEST"
BACKUP="$(cat "$LATEST_FILE")"

# Static safety: the canonical layer must not own colors or sizes.
python3 - "$APP/memeflow-font-ibm-plex-sans-v5.css" <<'PY'
from pathlib import Path
import re, sys
s = Path(sys.argv[1]).read_text(encoding="utf-8")
no_comments = re.sub(r"/\*.*?\*/", "", s, flags=re.S)
for prop in (
    "color", "font-size", "font-weight", "line-height", "letter-spacing",
    "text-transform", "margin", "padding", "width", "height"
):
    if re.search(rf"(?m)^\s*{re.escape(prop)}\s*:", no_comments):
        raise SystemExit(f"ERROR: canonical font layer unexpectedly owns {prop}")
print("Canonical layer safety: OK (font family only).")
PY

git diff --check -- "$APP"

echo
echo "=========================================="
echo "TYPOGRAPHY DIFF"
echo "=========================================="
git diff --stat -- "$APP"

git add -A -- "$APP"
git diff --cached --check -- "$APP"

if git diff --cached --quiet -- "$APP"; then
  echo "No typography changes to commit."
else
  git commit --only -m "Unify Memflow typography on IBM Plex Sans" -- "$APP"
fi

if [ "$NO_PUSH" -eq 0 ]; then
  git push origin "HEAD:$BRANCH"
fi

echo
echo "=========================================="
echo "IBM PLEX SANS CLEANUP COMPLETE"
echo "=========================================="
echo "Conflicting text fonts : 0 (verified)"
echo "Icon fonts             : preserved"
echo "Current text colors    : preserved"
echo "Current font sizes     : preserved"
echo "Restart                : NOT performed"
echo "Backup                 : $BACKUP"
if [ "$NO_PUSH" -eq 0 ]; then
  echo "Push                   : origin/$BRANCH"
else
  echo "Push                   : skipped (--no-push)"
fi
echo "=========================================="
